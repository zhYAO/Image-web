#!/usr/bin/env node
/**
 * Measures actual static-export files, not source import declarations.
 * Initial JS = unique script src + script preload/modulepreload URLs in each HTML.
 * "Not in initial HTML" is deliberately NOT called a proven lazy dependency:
 * it can include route-specific, runtime-discovered, or genuinely deferred code.
 * Browser timings, cache behavior, dynamic prefetches and Core Web Vitals are not measured.
 */
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, relative, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';

const root = resolve(import.meta.dirname, '..');
const imagePattern = /\.(?:avif|webp|png|jpe?g|gif|svg)$/i;
const bytes = (paths) => paths.reduce((sum, file) => sum + file.bytes, 0);
const gzipBytes = (paths) => paths.reduce((sum, file) => sum + file.gzipBytes, 0);
const kib = (value) => `${(value / 1024).toFixed(2)} KiB`;
function walk(path) {
  return readdirSync(path, { withFileTypes: true })
    .flatMap((entry) =>
      entry.isDirectory() ? walk(join(path, entry.name)) : [join(path, entry.name)],
    )
    .sort();
}
function attributes(tag) {
  return Object.fromEntries(
    [...tag.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g)].map((match) => [
      match[1].toLowerCase(),
      match[2] ?? match[3] ?? match[4],
    ]),
  );
}
function localUrl(value) {
  if (!value || /^(?:[a-z]+:|\/\/|#)/i.test(value)) return null;
  return '/' + value.split(/[?#]/)[0].replace(/^\/+/, '');
}
function measure(path, directory) {
  const content = readFileSync(path);
  return {
    path: '/' + relative(directory, path).replaceAll('\\', '/'),
    bytes: content.length,
    gzipBytes: gzipSync(content, { level: 9 }).length,
  };
}

export function analyzeExport(directory) {
  directory = resolve(directory);
  if (!existsSync(join(directory, 'index.html')))
    throw new Error(`No static export at ${directory}. Run npm run build first.`);
  const files = walk(directory);
  const inventory = new Map(
    files.map((file) => ['/' + relative(directory, file).replaceAll('\\', '/'), file]),
  );
  const missing = new Set();
  const resource = (url) => {
    const path = inventory.get(url);
    if (!path) {
      missing.add(url);
      return { path: url, bytes: 0, gzipBytes: 0, missing: true };
    }
    return measure(path, directory);
  };
  const routes = files
    .filter((file) => file.endsWith('.html'))
    .map((file) => {
      const html = readFileSync(file, 'utf8');
      const scriptUrls = new Set();
      const legacyScriptUrls = new Set();
      const cssUrls = new Set();
      const stylesheetHrefs = new Set();
      const imagePreloads = new Set();
      for (const tag of html.match(/<(?:script|link)\b[^>]*>/gi) ?? []) {
        const attr = attributes(tag);
        if (/^<script/i.test(tag) && localUrl(attr.src)) {
          // The emitted noModule polyfill is skipped by modern module browsers.
          if (/\bnomodule(?:\s|=|>)/i.test(tag)) legacyScriptUrls.add(localUrl(attr.src));
          else scriptUrls.add(localUrl(attr.src));
        }
        if (/^<link/i.test(tag)) {
          if (attr.rel === 'stylesheet' && attr.href) stylesheetHrefs.add(attr.href);
          const url = localUrl(attr.href);
          if (!url) continue;
          if (attr.rel === 'modulepreload' || (attr.rel === 'preload' && attr.as === 'script'))
            scriptUrls.add(url);
          if (attr.rel === 'stylesheet') cssUrls.add(url);
          if (attr.rel === 'preload' && attr.as === 'image') imagePreloads.add(url);
        }
      }
      const images = (html.match(/<img\b[^>]*>/gi) ?? []).map((tag) => {
        const attr = attributes(tag),
          url = localUrl(attr.src);
        return {
          src: attr.src,
          local: !!url,
          ...(url ? resource(url) : { bytes: null, gzipBytes: null }),
          loading: attr.loading || 'eager',
          decoding: attr.decoding || 'auto',
          fetchPriority: attr.fetchpriority || 'auto',
          width: Number(attr.width) || null,
          height: Number(attr.height) || null,
        };
      });
      const eagerImageUrls = new Set([
        ...imagePreloads,
        ...images
          .filter((image) => image.local && image.loading !== 'lazy')
          .map((image) => image.path),
      ]);
      const declaredImageUrls = new Set([
        ...imagePreloads,
        ...images.filter((image) => image.local).map((image) => image.path),
      ]);
      const scripts = [...scriptUrls].sort().map(resource);
      const legacyOnlyScripts = [...legacyScriptUrls].sort().map(resource);
      const css = [...cssUrls].sort().map(resource);
      const pagePath = '/' + relative(directory, file).replaceAll('\\', '/');
      return {
        route: pagePath.replace(/index\.html$/, ''),
        html: measure(file, directory),
        scripts,
        legacyOnlyScripts,
        css,
        initialStylesheetRequests: stylesheetHrefs.size,
        jsBytes: bytes(scripts),
        jsGzipBytes: gzipBytes(scripts),
        cssBytes: bytes(css),
        cssGzipBytes: gzipBytes(css),
        legacyOnlyJsBytes: bytes(legacyOnlyScripts),
        legacyOnlyJsGzipBytes: gzipBytes(legacyOnlyScripts),
        images,
        imagePreloads: [...imagePreloads],
        eagerImageBytes: bytes([...eagerImageUrls].map(resource)),
        allDeclaredImageBytes: bytes([...declaredImageUrls].map(resource)),
        imagesWithoutIntrinsicSize: images
          .filter((image) => !image.width || !image.height)
          .map((image) => image.src),
      };
    })
    .sort((a, b) => a.route.localeCompare(b.route));
  const javascript = files
    .filter((file) => file.endsWith('.js'))
    .map((file) => measure(file, directory));
  const asyncChunkReferences = [];
  for (const file of javascript) {
    const source = readFileSync(inventory.get(file.path), 'utf8');
    // Next 16 Turbopack async module loader, verified against emitted output.
    // This proves a separate async chunk edge, not when user code invokes it.
    for (const match of source.matchAll(/\.v\([\s\S]{0,100}?Promise\.all\(\[([^\]]+)\]/g)) {
      for (const quotedPath of match[1].matchAll(/["'](static\/chunks\/[^"']+\.js)["']/g)) {
        const to = '/_next/' + quotedPath[1];
        const target = javascript.find((candidate) => candidate.path === to);
        if (
          target &&
          !asyncChunkReferences.some((edge) => edge.from === file.path && edge.to === to)
        )
          asyncChunkReferences.push({ from: file.path, to, gzipBytes: target.gzipBytes });
      }
    }
  }
  const allInitial = new Set(
    routes.flatMap((route) =>
      [...route.scripts, ...route.legacyOnlyScripts].map((file) => file.path),
    ),
  );
  const routePageSets = routes
    .filter((route) => !/(?:404|_not-found|_global-error)/.test(route.route))
    .map((route) => new Set(route.scripts.map((file) => file.path)));
  const sharedInitialScripts = javascript.filter(
    (file) => routePageSets.length && routePageSets.every((set) => set.has(file.path)),
  );
  const assets = files
    .filter((file) => imagePattern.test(file))
    .map((file) => measure(file, directory));
  const hashGroups = new Map();
  for (const asset of assets) {
    const hash = createHash('sha256')
      .update(readFileSync(inventory.get(asset.path)))
      .digest('hex');
    hashGroups.set(hash, [...(hashGroups.get(hash) ?? []), asset]);
  }
  return {
    measurement:
      'Static exported file sizes. Initial JS excludes noModule-only legacy polyfills. Gzip level 9 per file; no network transfer or browser performance measurements.',
    generatedAt: new Date().toISOString(),
    outputDirectory: directory,
    routes,
    javascript,
    sharedInitialScripts,
    asyncChunkReferences,
    chunksNotInAnyInitialHtml: javascript.filter((file) => !allInitial.has(file.path)),
    assets: assets.sort((a, b) => b.bytes - a.bytes),
    duplicateAssets: [...hashGroups.entries()]
      .filter(([, group]) => group.length > 1)
      .map(([sha256, group]) => ({
        sha256,
        bytesPerCopy: group[0].bytes,
        redundantBytes: (group.length - 1) * group[0].bytes,
        copies: group.map((file) => file.path),
      })),
    missingLocalResources: [...missing],
  };
}

export function inspectBudget(report, budget) {
  const failures = report.missingLocalResources.map(
    (path) => `Missing emitted local resource: ${path}`,
  );
  for (const route of report.routes) {
    if (
      budget.maxInitialStylesheetRequests !== undefined &&
      route.initialStylesheetRequests > budget.maxInitialStylesheetRequests
    )
      failures.push(
        `${route.route} initial stylesheet requests ${route.initialStylesheetRequests} exceed ${budget.maxInitialStylesheetRequests}`,
      );
    if (
      budget.maxInitialHtmlGzipBytes !== undefined &&
      route.html.gzipBytes > budget.maxInitialHtmlGzipBytes
    )
      failures.push(
        `${route.route} initial HTML ${kib(route.html.gzipBytes)} exceeds ${kib(budget.maxInitialHtmlGzipBytes)}`,
      );
    const jsLimit = budget.routeInitialJsGzipBytes?.[route.route] ?? budget.maxInitialJsGzipBytes;
    if (jsLimit !== undefined && route.jsGzipBytes > jsLimit)
      failures.push(
        `${route.route} initial JavaScript ${kib(route.jsGzipBytes)} exceeds ${kib(jsLimit)}`,
      );
    const imageLimit = budget.routeEagerImageBytes?.[route.route] ?? budget.maxEagerImageBytes;
    if (imageLimit !== undefined && route.eagerImageBytes > imageLimit)
      failures.push(
        `${route.route} eager image declarations ${kib(route.eagerImageBytes)} exceed ${kib(imageLimit)}`,
      );
  }
  for (const asset of report.assets) {
    if (budget.maxSingleImageBytes !== undefined && asset.bytes > budget.maxSingleImageBytes)
      failures.push(
        `${asset.path} image ${kib(asset.bytes)} exceeds ${kib(budget.maxSingleImageBytes)}`,
      );
  }
  const duplicateBytes = report.duplicateAssets.reduce(
    (sum, group) => sum + group.redundantBytes,
    0,
  );
  if (budget.maxDuplicateAssetBytes !== undefined && duplicateBytes > budget.maxDuplicateAssetBytes)
    failures.push(
      `Duplicate image copies ${kib(duplicateBytes)} exceed ${kib(budget.maxDuplicateAssetBytes)}`,
    );
  return failures;
}

function printReport(report) {
  console.log(report.measurement);
  for (const route of report.routes)
    console.log(
      `${route.route.padEnd(27)} JS ${kib(route.jsGzipBytes).padStart(11)} gzip | CSS ${kib(route.cssGzipBytes).padStart(10)} gzip | HTML ${kib(route.html.gzipBytes).padStart(10)} gzip | eager imgs ${kib(route.eagerImageBytes).padStart(11)}`,
    );
  console.log(
    `noModule-only legacy polyfill excluded from modern JS totals: ${kib(Math.max(...report.routes.map((route) => route.legacyOnlyJsGzipBytes)))} gzip maximum per route`,
  );
  console.log(`Shared scripts across routes: ${sharedSummary(report.sharedInitialScripts)}`);
  console.log(
    `JavaScript files not in any initial HTML: ${sharedSummary(report.chunksNotInAnyInitialHtml)} (inspect runtime and source before classifying as deferred)`,
  );
  for (const file of report.chunksNotInAnyInitialHtml)
    console.log(`  ${file.path} ${kib(file.gzipBytes)} gzip`);
  console.log(
    `Verified emitted Turbopack async chunk edges: ${report.asyncChunkReferences.length} (invocation timing still requires source/browser review)`,
  );
  console.log(
    `Images: ${report.assets.length}; ${kib(bytes(report.assets))} total; largest ${report.assets[0]?.path ?? 'none'} ${kib(report.assets[0]?.bytes ?? 0)}`,
  );
  console.log(
    `Identical asset copies: ${report.duplicateAssets.length} groups, ${kib(report.duplicateAssets.reduce((sum, group) => sum + group.redundantBytes, 0))} redundant bytes`,
  );
  console.log(`Missing local resources: ${report.missingLocalResources.length}`);
}
function sharedSummary(files) {
  return `${files.length} files / ${kib(gzipBytes(files))} gzip`;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const args = process.argv.slice(2);
    const outputOption = args.indexOf('--out');
    const report = analyzeExport(
      outputOption < 0 ? join(root, 'out') : resolve(args[outputOption + 1]),
    );
    printReport(report);
    const jsonOption = args.indexOf('--json');
    if (jsonOption >= 0)
      writeFileSync(resolve(args[jsonOption + 1]), JSON.stringify(report, null, 2) + '\n');
    if (args.includes('--check')) {
      const budgetPath = join(root, 'performance-budget.json');
      if (!existsSync(budgetPath))
        throw new Error(
          'No baseline budget yet. Review a production build before setting performance-budget.json.',
        );
      const failures = inspectBudget(report, JSON.parse(readFileSync(budgetPath, 'utf8')));
      if (failures.length) {
        failures.forEach((message) => console.error(`FAIL: ${message}`));
        process.exitCode = 1;
      } else console.log('PASS: all measured bundle and image budgets.');
    }
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
