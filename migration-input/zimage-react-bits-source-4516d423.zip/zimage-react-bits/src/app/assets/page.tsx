import '@/components/assets/assets.css';
import { WorkspaceShell } from '@/components/workspace/WorkspaceShell';
import AssetLibrary from '@/components/assets/AssetLibrary';
export default function AssetsPage() {
  return (
    <WorkspaceShell title="资产库" active="assets">
      <AssetLibrary />
    </WorkspaceShell>
  );
}
