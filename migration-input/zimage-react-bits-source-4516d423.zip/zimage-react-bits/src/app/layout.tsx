import type { Metadata, Viewport } from 'next';
import { AppProvider } from '@/components/AppProvider';
import './globals.css';
import '@/styles/liquid-glass.css';

export const metadata: Metadata = {
  title: { default: 'ZImage · 让灵感成为画面', template: '%s · ZImage' },
  description: '让灵感成为画面。探索 ZImage 的商品视觉、创作工作台与资产库。',
  metadataBase: new URL('https://zimage-react-bits-preview.kylethree5.chatgpt.site'),
  robots: { index: false, follow: false },
  icons: { icon: '/assets/favicon.svg' },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  interactiveWidget: 'resizes-content',
  colorScheme: 'light dark',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>
        <AppProvider>{children}</AppProvider>
      </body>
    </html>
  );
}
