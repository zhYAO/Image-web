export default function Page() {
  // The persistent layout owns the cached catalogue. A real Page node lets
  // Next handle forward scrolling without overriding browser history restore.
  return <div className="cm-catalogue-route-anchor" data-catalogue-scroll-anchor aria-hidden />;
}
