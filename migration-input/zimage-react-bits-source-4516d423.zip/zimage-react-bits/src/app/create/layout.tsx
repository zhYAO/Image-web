import type { ReactNode } from 'react';
import { CommerceLayout } from '@/components/commerce/CommerceLayout';
export default function Layout({ children }: { children: ReactNode }) {
  return <CommerceLayout>{children}</CommerceLayout>;
}
