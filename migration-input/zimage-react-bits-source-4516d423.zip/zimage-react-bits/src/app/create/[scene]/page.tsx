import { notFound } from 'next/navigation';
import { scenes } from '@/components/commerce/commerce-data';
import { CommerceEditor } from '@/components/commerce/CommerceEditor';
export const dynamicParams = false;
export function generateStaticParams() {
  return scenes.map((scene) => ({ scene: scene.id }));
}
export default async function Page({ params }: { params: Promise<{ scene: string }> }) {
  const { scene: id } = await params;
  const scene = scenes.find((item) => item.id === id);
  if (!scene) notFound();
  return <CommerceEditor key={scene.id} scene={scene} />;
}
