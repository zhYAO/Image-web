import '@/components/identity/identity.css';
import AccountPage from '@/components/identity/AccountPage';
export default function Page() {
  return <AccountPage />;
}
