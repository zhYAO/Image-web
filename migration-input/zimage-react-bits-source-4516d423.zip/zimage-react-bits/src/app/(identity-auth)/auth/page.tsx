// The persistent auth layout owns the screen; public URLs stay unchanged.
export default function Page() {
  return null;
}
