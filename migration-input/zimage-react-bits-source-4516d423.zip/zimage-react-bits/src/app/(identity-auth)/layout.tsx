import type { ReactNode } from 'react';
import AuthRoute from '@/components/identity/AuthRoute';
import '@/components/identity/identity.css';

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <AuthRoute />
      {children}
    </>
  );
}
