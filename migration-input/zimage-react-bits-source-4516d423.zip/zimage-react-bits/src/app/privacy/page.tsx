import '@/components/identity/identity.css';
import LegalPage from '@/components/identity/LegalPage';
export default function Page() {
  return <LegalPage privacy />;
}
