'use client';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type Dispatch,
  type ReactNode,
  type SetStateAction,
} from 'react';
import { mockSessions } from '@/lib/demo-data';
import {
  DEFAULT_CHAT_MODEL,
  DEFAULT_IMAGE_MODEL,
  type ChatModelId,
  type ImageModelId,
} from '@/lib/model-catalog';
import { validateReference } from '@/lib/reference-validation';
import type {
  PreviewMessage,
  PreviewReference,
  PreviewSession,
  SessionCategory,
  WorkspaceMode,
} from '@/lib/preview-types';

interface PreviewContextValue {
  notify: (message: string) => void;
  mode: WorkspaceMode;
  setMode: Dispatch<SetStateAction<WorkspaceMode>>;
  chatDraft: string;
  setChatDraft: Dispatch<SetStateAction<string>>;
  imageDraft: string;
  setImageDraft: Dispatch<SetStateAction<string>>;
  chatModel: ChatModelId;
  setChatModel: Dispatch<SetStateAction<ChatModelId>>;
  imageModel: ImageModelId;
  setImageModel: Dispatch<SetStateAction<ImageModelId>>;
  references: PreviewReference[];
  addReferences: (files: Iterable<File> | ArrayLike<File>) => void;
  removeReference: (id: string) => void;
  clearReferences: () => void;
  sessions: PreviewSession[];
  activeSessionId: string | null;
  selectSession: (id: string | null) => void;
  createSession: (category?: SessionCategory) => string;
  renameSession: (id: string, title: string) => void;
  deleteSession: (id: string) => void;
  appendMessage: (id: string, message: PreviewMessage) => void;
  updateMessage: (id: string, messageId: string, patch: Partial<PreviewMessage>) => void;
}

type PreviewComposerValue = Pick<
  PreviewContextValue,
  | 'mode'
  | 'setMode'
  | 'chatDraft'
  | 'setChatDraft'
  | 'imageDraft'
  | 'setImageDraft'
  | 'chatModel'
  | 'setChatModel'
  | 'imageModel'
  | 'setImageModel'
  | 'references'
  | 'addReferences'
  | 'removeReference'
  | 'clearReferences'
>;
type PreviewSessionsValue = Pick<
  PreviewContextValue,
  | 'sessions'
  | 'activeSessionId'
  | 'selectSession'
  | 'createSession'
  | 'renameSession'
  | 'deleteSession'
  | 'appendMessage'
  | 'updateMessage'
>;
// Independent subscriptions keep typing in the composer from rendering the
// session sidebar, page shell, and notification-only controls again.
const ComposerContext = createContext<PreviewComposerValue | null>(null);
const SessionsContext = createContext<PreviewSessionsValue | null>(null);
const NotifyContext = createContext<PreviewContextValue['notify'] | null>(null);
let fallbackId = 0;
const createId = (prefix: string) =>
  `${prefix}-${typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${++fallbackId}`}`;

export function AppProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<WorkspaceMode>('chat');
  const [chatDraft, setChatDraft] = useState('');
  const [imageDraft, setImageDraft] = useState('');
  const [chatModel, setChatModel] = useState<ChatModelId>(DEFAULT_CHAT_MODEL);
  const [imageModel, setImageModel] = useState<ImageModelId>(DEFAULT_IMAGE_MODEL);
  const [references, setReferences] = useState<PreviewReference[]>([]);
  const referencesRef = useRef<PreviewReference[]>([]);
  const [sessions, setSessions] = useState<PreviewSession[]>(() =>
    mockSessions.map((session) => ({
      ...session,
      messages: session.messages.map((message) => ({ ...message })),
    })),
  );
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ id: number; message: string } | null>(null);
  const toastId = useRef(0);

  const notify = useCallback((message: string) => setToast({ id: ++toastId.current, message }), []);
  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(timeout);
  }, [toast]);

  useEffect(
    () => () => {
      for (const reference of referencesRef.current) URL.revokeObjectURL(reference.url);
    },
    [],
  );

  const addReferences = useCallback(
    (files: Iterable<File> | ArrayLike<File>) => {
      const next = [...referencesRef.current];
      const errors = new Set<string>();
      for (const file of Array.from(files)) {
        const error = validateReference(file, next.length);
        if (error) {
          errors.add(error);
          continue;
        }
        next.push({
          id: createId('reference'),
          name: file.name,
          url: URL.createObjectURL(file),
          size: file.size,
          type: file.type,
        });
      }
      referencesRef.current = next;
      setReferences(next);
      if (errors.size) notify([...errors].join(' '));
    },
    [notify],
  );

  const removeReference = useCallback((id: string) => {
    const current = referencesRef.current;
    const removed = current.find((reference) => reference.id === id);
    if (removed) URL.revokeObjectURL(removed.url);
    referencesRef.current = current.filter((reference) => reference.id !== id);
    setReferences(referencesRef.current);
  }, []);

  const clearReferences = useCallback(() => {
    for (const reference of referencesRef.current) URL.revokeObjectURL(reference.url);
    referencesRef.current = [];
    setReferences([]);
  }, []);

  const selectSession = useCallback((id: string | null) => setActiveSessionId(id), []);
  const createSession = useCallback((category: SessionCategory = 'general') => {
    const id = createId('preview');
    setSessions((current) => [{ id, title: '新的创作', category, messages: [] }, ...current]);
    setActiveSessionId(id);
    return id;
  }, []);
  const renameSession = useCallback((id: string, title: string) => {
    const normalized = title.trim().slice(0, 80);
    if (normalized)
      setSessions((current) =>
        current.map((session) => (session.id === id ? { ...session, title: normalized } : session)),
      );
  }, []);
  const deleteSession = useCallback((id: string) => {
    setSessions((current) => current.filter((session) => session.id !== id));
    setActiveSessionId((current) => (current === id ? null : current));
  }, []);
  const appendMessage = useCallback((id: string, message: PreviewMessage) => {
    const newMessage = { ...message, id: message.id ?? createId('message') };
    setSessions((current) =>
      current.map((session) =>
        session.id === id ? { ...session, messages: [...session.messages, newMessage] } : session,
      ),
    );
  }, []);

  const updateMessage = useCallback(
    (id: string, messageId: string, patch: Partial<PreviewMessage>) => {
      setSessions((current) =>
        current.map((session) =>
          session.id === id
            ? {
                ...session,
                messages: session.messages.map((message) =>
                  message.id === messageId ? { ...message, ...patch } : message,
                ),
              }
            : session,
        ),
      );
    },
    [],
  );

  const composer = useMemo(
    () => ({
      mode,
      setMode,
      chatDraft,
      setChatDraft,
      imageDraft,
      setImageDraft,
      chatModel,
      setChatModel,
      imageModel,
      setImageModel,
      references,
      addReferences,
      removeReference,
      clearReferences,
    }),
    [
      mode,
      chatDraft,
      imageDraft,
      chatModel,
      imageModel,
      references,
      addReferences,
      removeReference,
      clearReferences,
    ],
  );
  const sessionState = useMemo(
    () => ({
      sessions,
      activeSessionId,
      selectSession,
      createSession,
      renameSession,
      deleteSession,
      appendMessage,
      updateMessage,
    }),
    [
      sessions,
      activeSessionId,
      selectSession,
      createSession,
      renameSession,
      deleteSession,
      appendMessage,
      updateMessage,
    ],
  );

  return (
    <NotifyContext.Provider value={notify}>
      <SessionsContext.Provider value={sessionState}>
        <ComposerContext.Provider value={composer}>
          {children}
          <div className="preview-toast-region" aria-live="polite" aria-atomic="true">
            {toast && (
              <div className="preview-toast" role="status">
                <span>{toast.message}</span>
                <button type="button" aria-label="关闭提示" onClick={() => setToast(null)}>
                  ×
                </button>
              </div>
            )}
          </div>
        </ComposerContext.Provider>
      </SessionsContext.Provider>
    </NotifyContext.Provider>
  );
}

export function usePreviewComposer(): PreviewComposerValue {
  const context = useContext(ComposerContext);
  if (!context) throw new Error('usePreviewComposer must be used within AppProvider.');
  return context;
}

export function usePreviewSessions(): PreviewSessionsValue {
  const context = useContext(SessionsContext);
  if (!context) throw new Error('usePreviewSessions must be used within AppProvider.');
  return context;
}

export function usePreviewNotify(): PreviewContextValue['notify'] {
  const context = useContext(NotifyContext);
  if (!context) throw new Error('usePreviewNotify must be used within AppProvider.');
  return context;
}

/** Compatibility hook. Prefer a narrow hook in new components. */
export function usePreview(): PreviewContextValue {
  const composer = usePreviewComposer();
  const sessions = usePreviewSessions();
  const notify = usePreviewNotify();
  return useMemo(() => ({ ...composer, ...sessions, notify }), [composer, sessions, notify]);
}
