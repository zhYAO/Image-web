import type { Scene, SceneId } from './commerce-data';
import { DEFAULT_IMAGE_MODEL, type ImageModelId } from '@/lib/model-catalog';
import { MAX_REFERENCE_BYTES, REFERENCE_TYPES } from '@/lib/reference-validation';
export type Reference = {
  id: string;
  name: string;
  size: number;
  url: string;
  role: string;
  width: number;
  height: number;
  instruction?: string;
};
export type CommerceResult = {
  id: string;
  file: string;
  label: string;
  regenerating?: boolean;
  version: number;
};
export type EditorState = {
  stage: 'configure' | 'review';
  modelId: ImageModelId;
  view: 'examples' | 'results';
  description: string;
  references: Reference[];
  counts: { white: number; selling: number; scene: number; other: number };
  layouts: string[];
  modules: string[];
  copy: Record<string, string>;
  advanced: boolean;
  ratio: string;
  resolution: string;
  count: number;
  source: 'files' | 'url';
  cloneMode: 'style' | 'faithful';
  sceneTab: 'templates' | 'custom' | 'reference';
  template: string;
  instruction: string;
  sourceUrl: string;
  strategy: string;
  busy: boolean;
  progress: number;
  error: string;
  results: CommerceResult[];
  listing: Record<string, string>;
  apparel: Record<string, string>;
  apparelVersion: number;
  apparelSaved: boolean;
  sortNotice: string;
};
export function createEditorState(): EditorState {
  return {
    stage: 'configure',
    modelId: DEFAULT_IMAGE_MODEL,
    view: 'examples',
    description: '',
    references: [],
    counts: { white: 1, selling: 3, scene: 2, other: 1 },
    layouts: [],
    modules: ['品牌首屏', '核心卖点', '产品展示', '使用场景', '材质细节', '功能介绍'],
    copy: {},
    advanced: false,
    ratio: '1:1',
    resolution: '2K',
    count: 1,
    source: 'files',
    cloneMode: 'style',
    sceneTab: 'templates',
    template: 'soft-studio',
    instruction: '',
    sourceUrl: '',
    strategy: '',
    busy: false,
    progress: 0,
    error: '',
    results: [],
    listing: {},
    apparel: {},
    apparelVersion: 0,
    apparelSaved: false,
    sortNotice: '',
  };
}
export function totalImages(id: SceneId, state: EditorState) {
  return id === 'product-set'
    ? Object.values(state.counts).reduce((sum, count) => sum + count, 0)
    : id === 'detail'
      ? state.modules.length * (state.advanced ? 2 : 1)
      : id === 'clone'
        ? state.references.filter((ref) => ref.role === 'style').length
        : id === 'apparel-catalog'
          ? 10 + state.references.filter((ref) => ref.role === 'display').length
          : state.count;
}
export function reorderModules<T>(modules: T[], from: number, to: number): T[] {
  const next = [...modules];
  if (
    !Number.isInteger(from) ||
    !Number.isInteger(to) ||
    from < 0 ||
    to < 0 ||
    from >= next.length ||
    to >= next.length ||
    from === to
  )
    return next;
  next.splice(to, 0, next.splice(from, 1)[0]);
  return next;
}
export function updateCount(
  counts: EditorState['counts'],
  key: keyof EditorState['counts'],
  delta: number,
) {
  const total = Object.values(counts).reduce((sum, n) => sum + n, 0);
  if (counts[key] + delta < 0 || total + delta > 20) return counts;
  return { ...counts, [key]: counts[key] + delta };
}
export function buildResults(scene: Scene, state: EditorState): CommerceResult[] {
  const labels =
    scene.id === 'detail'
      ? state.modules
      : scene.id === 'product-set'
        ? Object.entries(state.counts).flatMap(([key, count]) =>
            Array.from(
              { length: count },
              () => ({ white: '白底图', selling: '卖点图', scene: '场景图', other: '其他' })[key],
            ),
          )
        : scene.id === 'clone'
          ? state.references.filter((ref) => ref.role === 'style').map((_, i) => `参考图 ${i + 1}`)
          : Array.from({ length: totalImages(scene.id, state) }, () =>
              scene.id === 'apparel-catalog' ? '服装排版' : '商品场景',
            );
  return labels.flatMap((label, i) =>
    Array.from({ length: scene.id === 'detail' && state.advanced ? 2 : 1 }, (_, n) => ({
      id: `${scene.id}-${i}-${n}`,
      file: scene.originals[(i + n) % scene.originals.length],
      label: label + (scene.id === 'detail' && state.advanced ? (n ? ' · 移动' : ' · 桌面') : ''),
      version: 1,
    })),
  );
}
export function uploadLimit(sceneId: SceneId, role: string) {
  return (role === 'style' && sceneId === 'clone') || role === 'display'
    ? 20
    : role.startsWith('main-') || role === 'logo'
      ? 1
      : 6;
}
export function validateUploadFiles(
  sceneId: SceneId,
  role: string,
  files: Pick<File, 'name' | 'size' | 'type'>[],
  refs: Reference[],
) {
  if (refs.filter((r) => r.role === role).length + files.length > uploadLimit(sceneId, role))
    return `此类图片最多 ${uploadLimit(sceneId, role)} 张。`;
  if (files.some((file) => file.size > MAX_REFERENCE_BYTES))
    return '请选择每张不超过 10 MB 的图片。';
  if (files.some((file) => file.size === 0)) return '这张图片是空文件，请重新选择。';
  const allowed: readonly string[] =
    sceneId === 'apparel-catalog'
      ? role === 'logo'
        ? ['image/png']
        : ['image/jpeg']
      : REFERENCE_TYPES;
  if (files.some((file) => !allowed.includes(file.type)))
    return sceneId === 'apparel-catalog'
      ? role === 'logo'
        ? 'Logo 需要 PNG 格式。'
        : '主图与展示照片需要 JPEG 格式。'
      : '仅支持 PNG、JPG 或 WebP 图片。';
  const seen = new Set(refs.map((ref) => `${ref.name}:${ref.size}`));
  for (const file of files) {
    const identity = `${file.name}:${file.size}`;
    if (seen.has(identity)) return '这张图片已添加，请勿重复上传。';
    seen.add(identity);
  }
  return '';
}
export function fitExampleContent(
  images: { width: number; height: number }[],
  availableWidth: number,
  availableHeight: number,
  { rotation = 0, extraWidth = 0, extraHeight = 0 } = {},
) {
  if (
    !images.length ||
    images.some(
      ({ width, height }) =>
        !Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0,
    )
  )
    return null;
  const width = Math.max(...images.map((image) => image.width)),
    height = images.reduce((sum, image) => sum + image.height, 0);
  const radians = (rotation * Math.PI) / 180,
    cos = Math.abs(Math.cos(radians)),
    sin = Math.abs(Math.sin(radians));
  const scale = Math.max(
    0,
    Math.min(
      1,
      (availableWidth - extraWidth * cos - extraHeight * sin) / (width * cos + height * sin),
      (availableHeight - extraWidth * sin - extraHeight * cos) / (width * sin + height * cos),
    ),
  );
  const frameWidth = width * scale + extraWidth,
    frameHeight = height * scale + extraHeight;
  return {
    frameWidth,
    frameHeight,
    rotatedWidth: frameWidth * cos + frameHeight * sin,
    rotatedHeight: frameWidth * sin + frameHeight * cos,
    scale,
    images: images.map((image) => ({ width: image.width * scale, height: image.height * scale })),
  };
}
export function draftConfiguration(state: EditorState) {
  return {
    ...state,
    references: [],
    results: [],
    busy: false,
    progress: 0,
    error: '',
    apparelSaved: false,
    view: 'examples' as const,
  };
}
