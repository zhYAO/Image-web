'use client';
import type { ImgHTMLAttributes } from 'react';
import { fallbackSource, imageSource, type Scene } from './commerce-data';
export function SceneImage({
  scene,
  file,
  alt = scene.name,
  ...props
}: { scene: Scene; file?: string } & ImgHTMLAttributes<HTMLImageElement>) {
  return (
    <img
      decoding="async"
      {...props}
      alt={alt}
      src={imageSource(scene, file)}
      onError={(event) => {
        const image = event.currentTarget;
        if (image.dataset.failed) return;
        image.dataset.failed = 'true';
        image.src = fallbackSource(scene);
      }}
    />
  );
}
export type ImageTarget = {
  src: string;
  alt: string;
  title: string;
  download?: string;
  dimensions?: string;
};
