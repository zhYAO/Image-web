'use client';
import type { Scene } from './commerce-data';
import { imageSource } from './commerce-data';
import type { CommerceResult } from './commerce-state';
import { SceneImage, type ImageTarget } from './CommerceImage';
export default function CommerceResults({
  scene,
  results,
  onRegenerate,
  onView,
}: {
  scene: Scene;
  results: CommerceResult[];
  onRegenerate: (id: string) => void;
  onView: (image: ImageTarget) => void;
}) {
  return (
    <div className={`cm-results-grid ${scene.id === 'detail' ? 'cm-detail-results' : ''}`}>
      {results.map((result, index) => (
        <article
          className="cm-result-card"
          data-result-id={result.id}
          key={result.id}
          aria-busy={Boolean(result.regenerating)}
        >
          <button
            type="button"
            className="cm-result-image"
            disabled={result.regenerating}
            aria-label={`查看${result.label}`}
            onClick={() =>
              onView({
                src: imageSource(scene, result.file),
                alt: result.label,
                title: `${result.label} · 示例`,
                download: `zimage-${result.file}.webp`,
              })
            }
          >
            <SceneImage
              scene={scene}
              file={result.file}
              alt={`${result.label} · 效果示例`}
              loading="lazy"
            />
            {result.regenerating && (
              <span className="cm-result-loading" role="status">
                <span className="cm-spinner" />
                <span>正在重新生成…</span>
              </span>
            )}
          </button>
          <div>
            <span>
              {String(index + 1).padStart(2, '0')} · {result.label}
            </span>
            {result.version > 1 && <small>v{result.version}</small>}
          </div>
          <footer>
            <button
              type="button"
              className="cm-text-button"
              disabled={result.regenerating}
              onClick={() => onRegenerate(result.id)}
            >
              {result.regenerating ? '正在重新生成…' : '重新生成'}
            </button>
            <a href={imageSource(scene, result.file)} download={`zimage-${result.file}.webp`}>
              下载示例
            </a>
          </footer>
        </article>
      ))}
    </div>
  );
}
