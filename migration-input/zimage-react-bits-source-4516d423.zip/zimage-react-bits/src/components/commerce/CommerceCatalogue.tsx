'use client';
import { memo } from 'react';
import Link from 'next/link';
import { IntentLink } from '@/components/IntentLink';
import { ArrowLeft, ArrowUpRight } from 'lucide-react';
import { scenes } from './commerce-data';
import { SceneImage } from './CommerceImage';
export const CommerceCatalogue = memo(function CommerceCatalogue() {
  return (
    <div className="cm-catalogue">
      <header className="cm-page-head">
        <Link href="/workspace" className="cm-back">
          <ArrowLeft size={13} />
          <span>返回工作区</span>
        </Link>
        <h1>电商生图</h1>
        <p>从一张商品图开始，让创意成为生意。</p>
      </header>
      <div className="cm-catalogue-grid">
        {scenes.map((scene, index) => (
          <IntentLink key={scene.id} href={`/create/${scene.id}`} className="cm-tool-card">
            <div className="cm-tool-cover">
              <SceneImage
                scene={scene}
                file={scene.cover}
                alt={`${scene.name}原创示例`}
                loading="lazy"
              />
              <span className="cm-tool-index">0{index + 1}</span>
            </div>
            <div className="cm-tool-copy">
              <div>
                <h2>{scene.name}</h2>
                <ArrowUpRight size={16} />
              </div>
              <p>{scene.description}</p>
              <span>{scene.meta}</span>
            </div>
          </IntentLink>
        ))}
      </div>
      <p className="cm-footnote">原创 AI 以实际生成效果为准。</p>
    </div>
  );
});
