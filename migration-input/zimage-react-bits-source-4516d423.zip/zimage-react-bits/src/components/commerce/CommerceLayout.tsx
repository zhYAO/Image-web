'use client';
import { usePathname } from 'next/navigation';
import type { ReactNode } from 'react';
import { WorkspaceShell } from '@/components/workspace/WorkspaceShell';
import { CommerceCatalogue } from './CommerceCatalogue';
import './commerce.css';
export function CommerceLayout({ children }: { children: ReactNode }) {
  const path = usePathname().replace(/\/$/, '');
  const catalogue = path === '/create';
  return (
    <WorkspaceShell active="create" title="电商生图">
      <div className={`cm-root ${catalogue ? 'cm-catalogue-outlet' : 'cm-editor-outlet'}`}>
        {children}
        <div className="cm-catalogue-cache" hidden={!catalogue} inert={!catalogue}>
          <CommerceCatalogue />
        </div>
      </div>
    </WorkspaceShell>
  );
}
