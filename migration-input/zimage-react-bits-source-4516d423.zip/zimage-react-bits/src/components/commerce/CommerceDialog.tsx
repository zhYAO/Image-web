'use client';
import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';
import ImagePreviewDialog from '@/components/ImagePreviewDialog';
import type { ImageTarget } from './CommerceImage';
export default function CommerceDialog({
  title,
  children,
  onClose,
  image,
}: {
  title: string;
  children?: ReactNode;
  onClose: () => void;
  image?: ImageTarget;
}) {
  if (image) return <ImagePreviewDialog image={{ ...image, title }} onClose={onClose} />;
  return (
    <ContentDialog title={title} onClose={onClose}>
      {children}
    </ContentDialog>
  );
}

function ContentDialog({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children?: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const focused = document.activeElement as HTMLElement | null;
    node.showModal();
    return () => {
      if (node.open) node.close();
      if (focused?.isConnected) focused.focus({ preventScroll: true });
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className="cm-dialog"
      aria-label={title}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="cm-dialog-heading">
        <h2>{title}</h2>
        <button type="button" className="cm-icon-button" aria-label="关闭" onClick={onClose}>
          <X size={18} />
        </button>
      </div>
      {children}
    </dialog>
  );
}
