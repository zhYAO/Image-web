export type SceneId = 'product-set' | 'detail' | 'clone' | 'product-main' | 'apparel-catalog';
export type Scene = {
  id: SceneId;
  name: string;
  description: string;
  meta: string;
  cover: string;
  originals: string[];
};
export const scenes: Scene[] = [
  {
    id: 'product-set',
    name: '商品套图',
    description: '上传商品、分配白底／卖点／场景／其他图，生成完整上架套图。',
    meta: '默认 7 张 · 最多 20 张',
    cover: 'kit-scene',
    originals: ['kit-product', 'kit-scene', 'kit-model', 'kit-detail', 'kit-selling'],
  },
  {
    id: 'detail',
    name: 'A+ 详情页',
    description: '先编辑视觉策略与模块文案，再生成普通或高级 A+ 图片。',
    meta: '16 个可选模块',
    cover: 'detail-hero',
    originals: [
      'detail-hero',
      'detail-selling',
      'detail-scene',
      'detail-angle',
      'detail-atmosphere',
      'detail-texture',
    ],
  },
  {
    id: 'clone',
    name: '爆款图复刻',
    description: '每张参考图独立设置要求，按图逐张生成。',
    meta: '最多 20 张参考图',
    cover: 'clone-result',
    originals: ['clone-reference', 'clone-result'],
  },
  {
    id: 'product-main',
    name: 'AI 商品图',
    description: '上传商品，选择场景或自定义要求，生成候选图并继续修改。',
    meta: '每次最多 4 张',
    cover: 'shoot-botanical',
    originals: ['shoot-product', 'shoot-studio', 'shoot-botanical'],
  },
  {
    id: 'apparel-catalog',
    name: '服装商品图片',
    description: '上传五张主图、展示照片与 Logo，按固定版式排出完整商品图。',
    meta: '整套 11–30 张 · 固定排版',
    cover: 'main-1',
    originals: [
      'main-1',
      'main-2',
      'main-3',
      'main-4',
      'main-5',
      'detail-01',
      'detail-03',
      'detail-04',
      'detail-05',
      'detail-06',
      'detail-07',
    ],
  },
];
export const categoryLabels = {
  white: '白底图',
  selling: '卖点图',
  scene: '场景图',
  other: '其他',
};
export const detailModules = [
  '品牌首屏',
  '核心卖点',
  '产品展示',
  '使用场景',
  '材质细节',
  '功能介绍',
  '规格参数',
  '尺寸说明',
  '结构拆解',
  '使用步骤',
  '适用人群',
  '对比展示',
  '包装内容',
  '品牌故事',
  '常见问题',
  '购买提示',
];
export const sellingLayouts = [
  '自动分配',
  '左文右图',
  '右文左图',
  '上文下图',
  '下文上图',
  '居中标题',
  '顶部标题',
  '底部标题',
  '分栏对比',
  '三栏卖点',
  '编号清单',
  '图标矩阵',
  '环绕标注',
  '侧边标签',
  '对角构图',
  '卡片堆叠',
  '杂志留白',
  '大字聚焦',
  '产品特写',
  '场景拼贴',
  '信息阶梯',
];
export const templates = [
  {
    id: 'white-main',
    name: '白底主图',
    note: '纯白背景，保留柔和接触阴影',
    image: 'shoot-product',
  },
  { id: 'soft-studio', name: '柔光棚拍', note: '简洁背景，准确呈现材质', image: 'shoot-studio' },
  { id: 'material-detail', name: '材质特写', note: '突出可见材质与结构' },
  { id: 'selling-point', name: '核心卖点', note: '清晰主体、信息分层' },
  { id: 'spec-layout', name: '参数版式', note: '仅呈现已确认参数' },
  { id: 'daily-scene', name: '日常场景', note: '自然光，真实生活环境', image: 'shoot-botanical' },
  { id: 'handheld', name: '手持展示', note: '成年人的自然手持姿态' },
  { id: 'brand-hero', name: '品牌主视觉', note: '统一色调、简洁构图' },
  { id: 'social-cover', name: '种草封面', note: '生活化构图与留白' },
  { id: 'lifestyle-collage', name: '生活方式拼贴', note: '场景与同款细节结合' },
  { id: 'detail-hero', name: '详情首屏', note: '商品主视觉与简短标题' },
  { id: 'detail-module', name: '详情模块', note: '模块化信息层级' },
];
export const apparelFields = [
  ['sku', '款号'],
  ['name', '商品名称'],
  ['color', '颜色'],
  ['composition', '面料成分'],
  ['care', '洗涤方式'],
  ['size', '上架尺码'],
  ['weightRecommendation', '体重推荐'],
  ['design', 'Design'],
  ['fabric', 'Fabric'],
  ['length', '衣长'],
  ['chest', '胸围'],
  ['shoulder', '肩宽'],
  ['sleeve', '袖长'],
] as const;
export const apparelCaptions = [
  '主图 1',
  '主图 2',
  '主图 3',
  '主图 4',
  '主图 5',
  '商品首图',
  '商品信息',
  '尺码信息',
  'DESIGN',
  'FABRIC',
  '产品展示',
];
export function imageSource(scene: Scene, file = scene.cover) {
  return `/assets/pages/${scene.id === 'apparel-catalog' ? 'apparel-v2' : 'meitu-v1'}/${file}.webp`;
}
export function fallbackSource(scene: Scene) {
  return `/assets/pages/${scene.id === 'apparel-catalog' ? 'apparel-v2/main-1' : 'meitu-v1/kit-product'}.webp`;
}
