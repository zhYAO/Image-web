import { ratios } from '@/lib/demo-data';
import { restoreImageModel } from '@/lib/model-catalog';
import { apparelFields, detailModules, sellingLayouts, templates } from './commerce-data';
import { createEditorState, type EditorState } from './commerce-state';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function choice<T extends string>(value: unknown, choices: readonly T[], fallback: T): T {
  return typeof value === 'string' && choices.includes(value as T) ? (value as T) : fallback;
}

function textFields(value: unknown, keys: string[]): Record<string, string> {
  if (!isRecord(value)) return {};
  return Object.fromEntries(
    keys.flatMap((key) => (typeof value[key] === 'string' ? [[key, value[key]]] : [])),
  );
}

function integer(value: unknown, minimum: number, maximum: number): value is number {
  return (
    typeof value === 'number' && Number.isInteger(value) && value >= minimum && value <= maximum
  );
}

/** Browser storage may contain older or damaged data; never spread it into live state. */
export function restoreDraftConfiguration(value: unknown): EditorState {
  const state = createEditorState();
  if (!isRecord(value)) return state;

  for (const key of ['description', 'instruction', 'sourceUrl', 'strategy'] as const) {
    if (typeof value[key] === 'string') state[key] = value[key];
  }
  state.modelId = restoreImageModel(value.modelId);
  state.ratio = choice(value.ratio, ratios, state.ratio);
  state.resolution = choice(value.resolution, ['2K'], state.resolution);
  state.source = choice(value.source, ['files', 'url'], state.source);
  state.cloneMode = choice(value.cloneMode, ['style', 'faithful'], state.cloneMode);
  state.sceneTab = choice(value.sceneTab, ['templates', 'custom', 'reference'], state.sceneTab);
  state.template = choice(
    value.template,
    templates.map((template) => template.id),
    state.template,
  );
  if (typeof value.advanced === 'boolean') state.advanced = value.advanced;
  if (integer(value.count, 1, 4)) state.count = value.count;
  if (integer(value.apparelVersion, 0, Number.MAX_SAFE_INTEGER))
    state.apparelVersion = value.apparelVersion;

  const savedCounts = value.counts;
  if (isRecord(savedCounts)) {
    const keys = Object.keys(state.counts) as (keyof EditorState['counts'])[];
    if (keys.every((key) => integer(savedCounts[key], 0, 20))) {
      const counts = Object.fromEntries(
        keys.map((key) => [key, savedCounts[key]]),
      ) as EditorState['counts'];
      if (Object.values(counts).reduce((sum, count) => sum + count, 0) <= 20) state.counts = counts;
    }
  }
  if (
    Array.isArray(value.modules) &&
    value.modules.every((module) => typeof module === 'string' && detailModules.includes(module))
  ) {
    state.modules = [...new Set<string>(value.modules)];
  }
  if (Array.isArray(value.layouts)) {
    state.layouts = value.layouts
      .slice(0, 20)
      .map((layout) => choice(layout, sellingLayouts, '自动分配'));
  }
  state.copy = textFields(value.copy, detailModules);
  state.listing = textFields(value.listing, ['title', 'highlights', 'description', 'keywords']);
  state.apparel = textFields(
    value.apparel,
    apparelFields.map(([key]) => key),
  );

  // Uploaded blobs and work-in-progress cannot survive navigation. Start at configuration
  // so the product uploader remains available even when a draft was saved during review.
  return state;
}
