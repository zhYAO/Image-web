'use client';
import { memo, useEffect, useRef, type ReactNode } from 'react';
import { apparelCaptions, detailModules, imageSource, type Scene } from './commerce-data';
import { SceneImage, type ImageTarget } from './CommerceImage';
import { fitExampleContent, type Reference } from './commerce-state';
function FitSlot({ children, stack = false }: { children: ReactNode; stack?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const slot = ref.current;
    if (!slot) return;
    const measure = () => {
      const frame = slot.firstElementChild as HTMLElement | null;
      const images = Array.from(slot.querySelectorAll<HTMLImageElement>('img'));
      if (
        !frame ||
        !images.length ||
        images.some((image) => !image.naturalWidth || !image.naturalHeight)
      )
        return;
      const style = getComputedStyle(frame),
        pixels = (name: string) => parseFloat(style.getPropertyValue(name)) || 0,
        caption = frame.querySelector('figcaption');
      const extraWidth =
          pixels('border-left-width') +
          pixels('border-right-width') +
          pixels('padding-left') +
          pixels('padding-right'),
        extraHeight =
          pixels('border-top-width') +
          pixels('border-bottom-width') +
          pixels('padding-top') +
          pixels('padding-bottom') +
          (caption?.clientHeight || 0);
      const fit = fitExampleContent(
        images.map((image) => ({ width: image.naturalWidth, height: image.naturalHeight })),
        slot.clientWidth,
        slot.clientHeight,
        { rotation: stack ? -1.5 : -2, extraWidth, extraHeight },
      );
      if (!fit || !fit.scale) return;
      frame.style.width = `${fit.frameWidth}px`;
      frame.style.marginBlock = `${Math.max(0, (fit.rotatedHeight - fit.frameHeight) / 2)}px`;
      images.forEach((image, index) => {
        image.style.width = `${fit.images[index].width}px`;
        image.style.height = `${fit.images[index].height}px`;
      });
      slot.classList.add('is-sized');
    };
    const observer = new ResizeObserver(measure);
    observer.observe(slot);
    slot.addEventListener('load', measure, true);
    measure();
    return () => {
      observer.disconnect();
      slot.removeEventListener('load', measure, true);
    };
  }, [stack]);
  return (
    <div ref={ref} className={`cm-example-slot ${stack ? 'cm-stack-slot' : ''}`}>
      {children}
    </div>
  );
}
export const CommerceExamples = memo(function CommerceExamples({
  scene,
  product,
  modules,
  onView,
  apparelVersion = 0,
}: {
  scene: Scene;
  product?: Reference;
  modules: string[];
  onView: (image: ImageTarget) => void;
  apparelVersion?: number;
}) {
  const image = (file: string, alt: string) => (
    <button
      type="button"
      className="cm-example-image"
      aria-label={`查看完整图片 · ${alt}`}
      onClick={() =>
        onView({
          src: imageSource(scene, file),
          alt,
          title: '完整图片',
          download: `zimage-${file}.webp`,
        })
      }
    >
      <SceneImage scene={scene} file={file} alt={alt} loading="eager" />
    </button>
  );
  const card = (file: string, caption: string, className = '') => (
    <figure key={file} className={className}>
      {image(file, caption)}
      <figcaption>{caption}</figcaption>
    </figure>
  );
  if (scene.id === 'apparel-catalog')
    return (
      <div className="cm-apparel-results">
        {scene.originals.map((file, index) => (
          <figure key={file}>
            {image(file, `服装${apparelCaptions[index]}`)}
            <figcaption>
              {apparelCaptions[index]}
              <small>
                {index < 5 ? '3:4 · 示例缩略图' : '详情模块 · 示例缩略图'}
                {apparelVersion ? ` · v${apparelVersion}` : ''}
              </small>
            </figcaption>
          </figure>
        ))}
      </div>
    );
  if (scene.id === 'clone')
    return (
      <div className="cm-before-after">
        {card('clone-reference', '01 · 参考风格')}
        {card('clone-result', '02 · 替换商品与配色')}
      </div>
    );
  if (scene.id === 'product-main')
    return (
      <div className="cm-main-art">
        <FitSlot>
          <figure className="cm-main-hero">
            {product ? (
              <button
                type="button"
                className="cm-example-image"
                aria-label="查看完整商品原图"
                onClick={() =>
                  onView({
                    src: product.url,
                    alt: product.name,
                    title: product.name,
                    dimensions: `${product.width} × ${product.height}`,
                  })
                }
              >
                <img src={product.url} alt="商品原图" />
              </button>
            ) : (
              image('shoot-botanical', '自然光场景示例')
            )}
            <figcaption>{product ? '商品原图' : '自然氛围 · 原创示例'}</figcaption>
          </figure>
        </FitSlot>
        <div className="cm-example-gallery">
          {card('shoot-product', '商品原图')}
          {card('shoot-studio', '影棚光影')}
        </div>
      </div>
    );
  if (scene.id === 'detail')
    return (
      <div className="cm-detail-art">
        <FitSlot stack>
          <div className="cm-long-preview">
            {scene.originals.map((file) => (
              <div key={file}>{image(file, '详情页模块原创示例')}</div>
            ))}
          </div>
        </FitSlot>
        <div className="cm-detail-tiles cm-example-gallery">
          {scene.originals
            .slice(0, 4)
            .map((file, index) =>
              card(file, `0${index + 1} · ${modules[index] || detailModules[index]}`),
            )}
        </div>
      </div>
    );
  return (
    <div className="cm-set-art">
      <FitSlot>{card('kit-product', '01 · 主图 / 白底展示', 'cm-set-main')}</FitSlot>
      <div className="cm-example-gallery">
        {scene.originals
          .slice(1)
          .map((file, index) =>
            card(
              file,
              `0${index + 2} · ${['场景展示', '模特场景', '细节说明', '卖点详解'][index]}`,
            ),
          )}
      </div>
    </div>
  );
});
