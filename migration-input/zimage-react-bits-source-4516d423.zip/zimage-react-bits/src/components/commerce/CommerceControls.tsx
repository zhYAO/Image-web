'use client';
import { useState, type ReactNode } from 'react';
import { ImagePlus, X } from 'lucide-react';
import GlideSelect from '../react-bits/GlideSelect';
import type { Reference } from './commerce-state';
export function Section({
  title,
  extra,
  children,
}: {
  title: string;
  extra?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="cm-section">
      <div className="cm-section-title">
        <h2>{title}</h2>
        {extra}
      </div>
      {children}
    </section>
  );
}
export function TextField({
  label,
  name,
  value,
  onChange,
  placeholder = '',
  rows,
  type = 'text',
}: {
  label: string;
  name: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  rows?: number;
  type?: string;
}) {
  return (
    <label className="cm-field">
      <span>{label}</span>
      {rows ? (
        <textarea
          name={name}
          value={value}
          rows={rows}
          maxLength={4000}
          placeholder={placeholder}
          onChange={(event) => onChange(event.target.value)}
        />
      ) : (
        <input
          name={name}
          type={type}
          value={value}
          maxLength={200}
          autoComplete="off"
          placeholder={placeholder}
          onChange={(event) => onChange(event.target.value)}
        />
      )}
    </label>
  );
}
export function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: (string | [string, string])[];
}) {
  return (
    <div className="cm-field">
      <span>{label}</span>
      <GlideSelect
        ariaLabel={label}
        includeValueInLabel
        menuWidth={240}
        className="cm-glide-select"
        value={value}
        onChange={onChange}
        options={options.map((item) =>
          typeof item === 'string' ? item : { value: item[0], label: item[1] },
        )}
      />
    </div>
  );
}

export function UploadGroup({
  role,
  label,
  optional = false,
  max = 6,
  references,
  onFiles,
  onRemove,
  onView,
  apparel = false,
}: {
  role: string;
  label: string;
  optional?: boolean;
  max?: number;
  references: Reference[];
  onFiles: (files: File[], role: string) => void;
  onRemove: (id: string) => void;
  onView: (ref: Reference) => void;
  apparel?: boolean;
}) {
  const refs = references.filter((ref) => ref.role === role);
  const [dragging, setDragging] = useState(false);
  return (
    <div className="cm-upload-group">
      <div className="cm-upload-label">
        <span>{label}</span>
        <small>
          {optional ? '选填 · ' : ''}
          {refs.length} / {max}
        </small>
      </div>
      <div className="cm-upload-list">
        {refs.map((ref) => (
          <div className="cm-upload-thumb" key={ref.id}>
            <button type="button" onClick={() => onView(ref)} aria-label={`查看大图 ${ref.name}`}>
              <img src={ref.url} alt={ref.name} />
            </button>
            <button
              className="cm-remove"
              type="button"
              onClick={() => onRemove(ref.id)}
              aria-label={`移除 ${ref.name}`}
            >
              <X size={11} />
            </button>
          </div>
        ))}
        {refs.length < max && (
          <label
            className={`cm-uploader ${refs.length ? 'cm-uploader-small' : ''} ${dragging ? 'is-dragging' : ''}`}
            onDragOver={(event) => {
              event.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(event) => {
              event.preventDefault();
              setDragging(false);
              onFiles(Array.from(event.dataTransfer.files), role);
            }}
          >
            <ImagePlus size={23} />
            <strong>{refs.length ? '添加' : '点击上传或拖入图片'}</strong>
            {!refs.length && (
              <span>
                {apparel ? (role === 'logo' ? 'PNG' : 'JPEG') : 'PNG、JPG、WebP'} · 每张不超过 10 MB
              </span>
            )}
            <input
              type="file"
              aria-label={label}
              accept={
                apparel
                  ? role === 'logo'
                    ? 'image/png'
                    : 'image/jpeg'
                  : 'image/png,image/jpeg,image/webp'
              }
              multiple={max > 1}
              onChange={(event) => {
                onFiles(Array.from(event.target.files || []), role);
                event.target.value = '';
              }}
            />
          </label>
        )}
      </div>
    </div>
  );
}
export function Segments({
  value,
  choices,
  onChange,
}: {
  value: string;
  choices: [string, string][];
  onChange: (value: string) => void;
}) {
  return (
    <div className="cm-segments">
      {choices.map(([id, label]) => (
        <button type="button" key={id} aria-pressed={value === id} onClick={() => onChange(id)}>
          {label}
        </button>
      ))}
    </div>
  );
}
