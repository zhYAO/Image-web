'use client';
import { lazy, Suspense, useEffect, useRef, useState, type ReactNode } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft,
  ArrowUpRight,
  Check,
  Image as ImageIcon,
  Sparkles,
  WandSparkles,
} from 'lucide-react';
import { usePreviewNotify } from '@/components/AppProvider';
import { Glass } from '@/components/Glass';
import { ModelSelector } from '@/components/models/ModelSelector';
import {
  apparelFields,
  categoryLabels,
  detailModules,
  sellingLayouts,
  templates,
  type Scene,
} from './commerce-data';
import {
  buildResults,
  createEditorState,
  draftConfiguration,
  reorderModules,
  totalImages,
  updateCount,
  uploadLimit,
  validateUploadFiles,
  type EditorState,
  type Reference,
} from './commerce-state';
import { restoreDraftConfiguration } from './commerce-drafts';
import { Section, Select, Segments, TextField, UploadGroup } from './CommerceControls';
import { CommerceExamples } from './CommerceExamples';
import { SceneImage, type ImageTarget } from './CommerceImage';
const CommerceResults = lazy(() => import('./CommerceResults'));
const CommerceDialog = lazy(() => import('./CommerceDialog'));
export function CommerceEditor({ scene }: { scene: Scene }) {
  const router = useRouter();
  const notify = usePreviewNotify();
  const [state, setState] = useState<EditorState>(createEditorState);
  const latest = useRef(state);
  const alive = useRef(true),
    timers = useRef<ReturnType<typeof setTimeout>[]>([]),
    urls = useRef(new Set<string>()),
    queue = useRef(Promise.resolve()),
    dragModule = useRef<number | null>(null);
  const [dialog, setDialog] = useState<'layouts' | ImageTarget | null>(null);
  const [dropTarget, setDropTarget] = useState<number | null>(null);
  const update = (change: Partial<EditorState> | ((current: EditorState) => EditorState)) => {
    const next =
      typeof change === 'function' ? change(latest.current) : { ...latest.current, ...change };
    latest.current = next;
    setState(next);
  };
  useEffect(() => {
    alive.current = true;
    const pendingTimers = timers.current;
    const objectUrls = urls.current;
    try {
      const saved = localStorage.getItem(`zimage-commerce-draft:${scene.id}`);
      if (saved) {
        const next = restoreDraftConfiguration(JSON.parse(saved));
        latest.current = next;
        // Storage is browser-only. Hydrate once after matching the static server render.
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setState(next);
      }
    } catch {
      /* Browsing continues when local storage is unavailable. */
    }
    return () => {
      alive.current = false;
      pendingTimers.forEach(clearTimeout);
      pendingTimers.length = 0;
      objectUrls.forEach((url) => URL.revokeObjectURL(url));
      objectUrls.clear();
    };
  }, [scene.id]);
  const later = (fn: () => void, delay: number) => {
    timers.current.push(
      setTimeout(() => {
        if (alive.current) fn();
      }, delay),
    );
  };
  const showRef = (ref: Reference) =>
    setDialog({
      src: ref.url,
      alt: ref.name,
      title: ref.name,
      dimensions: `${ref.width} × ${ref.height}`,
    });
  const removeRef = (id: string) => {
    const ref = latest.current.references.find((item) => item.id === id);
    if (ref) {
      URL.revokeObjectURL(ref.url);
      urls.current.delete(ref.url);
    }
    update((current) => ({
      ...current,
      references: current.references.filter((item) => item.id !== id),
      apparelSaved: false,
      error: '',
    }));
  };
  const addFiles = (files: File[], role: string) => {
    if (!files.length) return;
    queue.current = queue.current.then(async () => {
      if (!alive.current) return;
      const error = validateUploadFiles(scene.id, role, files, latest.current.references);
      if (error) {
        update({ error });
        return;
      }
      const additions: Reference[] = [];
      for (const file of files) {
        const url = URL.createObjectURL(file);
        urls.current.add(url);
        try {
          const dimensions = await new Promise<{ width: number; height: number }>(
            (resolve, reject) => {
              const image = new window.Image();
              image.onload = () =>
                resolve({ width: image.naturalWidth, height: image.naturalHeight });
              image.onerror = reject;
              image.src = url;
            },
          );
          if (!alive.current) {
            URL.revokeObjectURL(url);
            urls.current.delete(url);
            return;
          }
          if (
            role.startsWith('main-') &&
            Math.abs(dimensions.width / dimensions.height - 0.75) > 0.015
          )
            throw new Error('服装主图需要 3:4 比例的 JPEG 图片。');
          additions.push({
            id: crypto.randomUUID(),
            name: file.name,
            size: file.size,
            url,
            role,
            ...dimensions,
          });
        } catch (error) {
          URL.revokeObjectURL(url);
          urls.current.delete(url);
          additions.forEach((ref) => {
            URL.revokeObjectURL(ref.url);
            urls.current.delete(ref.url);
          });
          if (alive.current)
            update({
              error:
                error instanceof Error && error.message.includes('3:4')
                  ? error.message
                  : '这张图片无法读取，请选择有效的图片文件。',
            });
          return;
        }
      }
      update((current) => ({
        ...current,
        references: [...current.references, ...additions].sort((a, b) =>
          a.role === 'display' && b.role === 'display'
            ? a.name.localeCompare(b.name, 'zh', { numeric: true })
            : 0,
        ),
        apparelSaved: false,
        error: '',
      }));
    });
  };
  const uploader = (
    role: string,
    label: string,
    optional = false,
    max = uploadLimit(scene.id, role),
  ) => (
    <UploadGroup
      role={role}
      label={label}
      optional={optional}
      max={max}
      references={state.references}
      onFiles={addFiles}
      onRemove={removeRef}
      onView={showRef}
      apparel={scene.id === 'apparel-catalog'}
    />
  );
  const text = (label: string, key: keyof EditorState, placeholder = '', rows = 3) => (
    <TextField
      label={label}
      name={key}
      value={String(state[key])}
      placeholder={placeholder}
      rows={rows}
      onChange={(value) => update({ [key]: value })}
    />
  );
  const total = totalImages(scene.id, state),
    hasInput = state.references.some(
      (ref) => ref.role === (scene.id === 'clone' ? 'style' : 'product'),
    );
  const generate = () => {
    const current = latest.current;
    if (current.busy) return;
    if (
      !current.references.some((ref) => ref.role === (scene.id === 'clone' ? 'style' : 'product'))
    ) {
      update({
        error:
          scene.id === 'clone' ? '请上传至少一张复刻参考图。' : '请上传至少一张清晰的真实商品图。',
      });
      return;
    }
    if (totalImages(scene.id, current) < 1) {
      update({ error: '请至少选择一张图片。' });
      return;
    }
    if (scene.id === 'detail' && current.stage === 'configure') {
      update({ stage: 'review', error: '' });
      return;
    }
    update({ busy: true, error: '', progress: 15, view: 'results' });
    later(() => update({ progress: 58 }), 450);
    later(() => update({ progress: 88 }), 900);
    later(() => {
      update((current) => ({
        ...current,
        results: buildResults(scene, current),
        busy: false,
        progress: 100,
      }));
      notify('已准备好示例素材。');
    }, 1350);
  };
  const regenerate = (id: string) => {
    const current = latest.current,
      result = current.results.find((item) => item.id === id);
    if (!result || result.regenerating || current.busy) return;
    update({
      ...current,
      results: current.results.map((item) =>
        item.id === id ? { ...item, regenerating: true } : item,
      ),
    });
    later(() => {
      update((current) => ({
        ...current,
        results: current.results.map((item) =>
          item.id === id
            ? {
                ...item,
                regenerating: false,
                version: item.version + 1,
                file: scene.originals[
                  (scene.originals.indexOf(item.file) + 1) % scene.originals.length
                ],
              }
            : item,
        ),
      }));
      notify('示例已更新。');
    }, 850);
  };
  const moveModule = (from: number, to: number) => {
    if (to < 0 || to >= latest.current.modules.length || to === from) return;
    const name = latest.current.modules[from];
    update((current) => ({
      ...current,
      modules: reorderModules(current.modules, from, to),
      sortNotice: `${name}已移动到第 ${to + 1} 项`,
    }));
  };
  const saveDraft = () => {
    try {
      localStorage.setItem(
        `zimage-commerce-draft:${scene.id}`,
        JSON.stringify(draftConfiguration(latest.current)),
      );
      notify('设置草稿已保存，图片仅保留在当前页面。');
    } catch {
      notify('无法保存草稿，请检查浏览器存储设置。');
    }
  };
  const generation = (
    <Section title="生成设置">
      <div className={`cm-field-grid${scene.id === 'detail' ? ' cm-detail-output-fields' : ''}`}>
        {scene.id === 'detail' ? (
          <Select
            label="输出规格"
            value={String(state.advanced)}
            onChange={(value) => update({ advanced: value === 'true' })}
            options={[
              ['false', '普通 A+ · 970 × 600'],
              ['true', '高级 A+ · 桌面 + 移动'],
            ]}
          />
        ) : (
          <Select
            label="画面比例"
            value={state.ratio}
            onChange={(ratio) => update({ ratio })}
            options={['1:1', '3:4', '4:3', '9:16', '16:9']}
          />
        )}
        {scene.id !== 'detail' && (
          <Select
            label="分辨率"
            value={state.resolution}
            onChange={(resolution) => update({ resolution })}
            options={['2K']}
          />
        )}
      </div>
      {scene.id === 'detail' && (
        <>
          <p className="cm-help">
            {state.advanced
              ? '配置输出比例：桌面 16:9 · 移动 4:3；像素尺寸待接入服务后确认。'
              : '配置输出尺寸：每个模块 970 × 600 px。'}
          </p>
          <p className="cm-help">右侧展示固定示例素材，示例缩略图不代表输出尺寸。</p>
        </>
      )}
    </Section>
  );
  const description = (
    <Section title="商品卖点 & 要求">
      {text(
        '商品描述',
        'description',
        '建议包含产品名称、核心卖点、适用人群、期望场景和已确认规格。',
        4,
      )}
    </Section>
  );
  const prepareListing = () => {
    const description = latest.current.description;
    if (!description.trim()) {
      update({ error: '请先填写商品描述。' });
      return;
    }
    update({
      listing: {
        title: description.split(/[\n。]/)[0].slice(0, 80),
        highlights: description,
        description,
        keywords: '',
      },
      error: '',
    });
    notify('已将商品资料整理到文案字段。');
  };
  const copyListing = async () => {
    const content = Object.values(latest.current.listing).join('\n');
    if (!content.trim()) {
      notify('请先填写上架文案。');
      return;
    }
    try {
      await navigator.clipboard.writeText(content);
      notify('文案已复制。');
    } catch {
      notify('无法访问剪贴板，请选择文案手动复制。');
    }
  };
  let fields: ReactNode;
  if (scene.id === 'product-set')
    fields = (
      <>
        <Section title="商品原图">{uploader('product', '商品原图')}</Section>
        {generation}
        {description}
        <Section title="套图结构配置" extra={<span>{total} 张</span>}>
          {Object.entries(categoryLabels).map(([key, label]) => (
            <div className="cm-count-row" key={key}>
              <span>{label}</span>
              <div className="cm-stepper">
                <button
                  type="button"
                  aria-label={`减少${label}图片数量`}
                  disabled={state.counts[key as keyof typeof categoryLabels] === 0}
                  onClick={() =>
                    update((current) => ({
                      ...current,
                      counts: updateCount(current.counts, key as keyof typeof categoryLabels, -1),
                    }))
                  }
                >
                  −
                </button>
                <output>{state.counts[key as keyof typeof categoryLabels]}</output>
                <button
                  type="button"
                  aria-label={`增加${label}图片数量`}
                  disabled={total >= 20}
                  onClick={() =>
                    update((current) => ({
                      ...current,
                      counts: updateCount(current.counts, key as keyof typeof categoryLabels, 1),
                    }))
                  }
                >
                  +
                </button>
              </div>
            </div>
          ))}
          <button type="button" className="cm-inline-button" onClick={() => setDialog('layouts')}>
            选择卖点图版式参考
            <ArrowUpRight size={12} />
          </button>
        </Section>
        <details className="cm-details">
          <summary>商品上架文案（可选）</summary>
          <p>依据已填写资料整理商品信息。</p>
          <button type="button" className="cm-button cm-secondary" onClick={prepareListing}>
            <Sparkles size={14} />
            AI 编写上架文案
          </button>
          {[
            ['title', '标题'],
            ['highlights', '核心卖点'],
            ['description', '详情描述'],
            ['keywords', '关键词'],
          ].map(([key, label]) => (
            <TextField
              key={key}
              label={label}
              name={`listing:${key}`}
              value={state.listing[key] || ''}
              rows={2}
              onChange={(value) =>
                update((current) => ({ ...current, listing: { ...current.listing, [key]: value } }))
              }
            />
          ))}
          <button type="button" className="cm-text-button" onClick={copyListing}>
            复制文案
          </button>
        </details>
      </>
    );
  else if (scene.id === 'detail')
    fields =
      state.stage === 'review' ? (
        <>
          <Section
            title="模块策略与设计规范"
            extra={
              <button
                type="button"
                className="cm-ai-help"
                aria-label="AI帮写"
                data-tooltip="AI帮写"
                onClick={() => {
                  update({
                    strategy: state.description
                      ? `围绕已填写商品资料呈现，保持色调与版式统一。\n${state.description}`
                      : '统一色调与版式，以已确认商品资料为依据，不补充未经确认的信息。',
                  });
                  notify('视觉策略已整理。');
                }}
              >
                <WandSparkles size={18} />
              </button>
            }
          >
            {text('视觉策略', 'strategy', '填写统一的色调、构图与文案方向')}
          </Section>
          <Section title="模块内容" extra={<span>可拖动排序</span>}>
            <p className="cm-sort-help">拖动调整顺序，也可使用上下移按钮</p>
            <div className="cm-module-list">
              {state.modules.map((module, index) => (
                <article
                  className={`cm-module-edit ${dropTarget === index ? 'is-drop-target' : ''}`}
                  key={module}
                  draggable
                  onDragStart={(event) => {
                    if ((event.target as HTMLElement).matches('textarea,input')) {
                      event.preventDefault();
                      return;
                    }
                    dragModule.current = index;
                    event.dataTransfer.effectAllowed = 'move';
                    event.dataTransfer.setData('text/plain', String(index));
                  }}
                  onDragOver={(event) => {
                    event.preventDefault();
                    setDropTarget(index);
                  }}
                  onDrop={(event) => {
                    event.preventDefault();
                    if (dragModule.current !== null) moveModule(dragModule.current, index);
                    dragModule.current = null;
                    setDropTarget(null);
                  }}
                  onDragEnd={() => {
                    dragModule.current = null;
                    setDropTarget(null);
                  }}
                >
                  <div>
                    <strong>
                      <span className="cm-drag-grip" aria-hidden>
                        ⠿
                      </span>
                      <span>{String(index + 1).padStart(2, '0')}</span>
                      {module}
                    </strong>
                    <div className="cm-sort">
                      <button
                        type="button"
                        disabled={index === 0}
                        aria-label={`上移${module}`}
                        onClick={() => moveModule(index, index - 1)}
                      >
                        ↑
                      </button>
                      <button
                        type="button"
                        disabled={index === state.modules.length - 1}
                        aria-label={`下移${module}`}
                        onClick={() => moveModule(index, index + 1)}
                      >
                        ↓
                      </button>
                    </div>
                  </div>
                  <TextField
                    label={`${module}文案`}
                    name={`copy:${module}`}
                    rows={2}
                    placeholder="填写该模块要呈现的文案；留空由商品资料生成"
                    value={state.copy[module] || ''}
                    onChange={(value) =>
                      update((current) => ({
                        ...current,
                        copy: { ...current.copy, [module]: value },
                      }))
                    }
                  />
                </article>
              ))}
            </div>
            <p className="cm-visually-hidden" role="status" aria-live="polite">
              {state.sortNotice}
            </p>
          </Section>
        </>
      ) : (
        <>
          <Section title="商品原图">{uploader('product', '商品原图')}</Section>
          {generation}
          {description}
          <Section title="包含模块（多选）" extra={<span>已选 {state.modules.length} 项</span>}>
            <div className="cm-modules">
              {detailModules.map((module) => (
                <label
                  key={module}
                  className={`cm-module-choice ${state.modules.includes(module) ? 'is-selected' : ''}`}
                >
                  <input
                    type="checkbox"
                    checked={state.modules.includes(module)}
                    onChange={(event) =>
                      update((current) => ({
                        ...current,
                        modules: event.target.checked
                          ? [...current.modules, module]
                          : current.modules.filter((item) => item !== module),
                      }))
                    }
                  />
                  <span>{module}</span>
                  <Check size={12} />
                </label>
              ))}
            </div>
          </Section>
        </>
      );
  else if (scene.id === 'clone')
    fields = (
      <>
        <Section title="参考内容">
          <Segments
            value={state.source}
            choices={[
              ['files', '上传参考图'],
              ['url', '导入链接'],
            ]}
            onChange={(source) => update({ source: source as 'files' | 'url', error: '' })}
          />
          {state.source === 'files' ? (
            uploader('style', '复刻参考图', false, 20)
          ) : (
            <>
              <TextField
                label="公开商品链接"
                name="sourceUrl"
                type="url"
                value={state.sourceUrl}
                placeholder="https://"
                onChange={(sourceUrl) => update({ sourceUrl })}
              />
              <button
                type="button"
                className="cm-button cm-secondary"
                onClick={() =>
                  update({ error: '暂不支持链接导入，请切换「上传参考图」添加图片。' })
                }
              >
                从链接导入参考图
              </button>
              <p className="cm-help">请上传图片，暂不支持外部链接导入。</p>
            </>
          )}
        </Section>
        <Section title="产品原图">{uploader('product', '产品原图', true)}</Section>
        <Section title="复刻程度">
          <div className="cm-choice-stack">
            {[
              ['style', '参考风格', '参考整体风格与结构，重新演绎场景。'],
              ['faithful', '高度复刻', '参照构图和版式，替换商品与文案。'],
            ].map(([id, title, note]) => (
              <button
                key={id}
                type="button"
                className="cm-choice"
                aria-pressed={state.cloneMode === id}
                onClick={() => update({ cloneMode: id as 'style' | 'faithful' })}
              >
                <strong>{title}</strong>
                <small>{note}</small>
                <Check size={13} />
              </button>
            ))}
          </div>
        </Section>
        {text('统一复刻要求（选填）', 'instruction', '补充商品替换、文字和配色要求')}
        {state.references.some((ref) => ref.role === 'style') && (
          <Section title="逐图要求（选填）">
            {state.references
              .filter((ref) => ref.role === 'style')
              .map((ref, index) => (
                <TextField
                  key={ref.id}
                  name={`ref:${ref.id}`}
                  label={`参考图 ${index + 1} · ${ref.name}`}
                  rows={2}
                  placeholder="补充这张图的替换内容、排版或颜色要求"
                  value={ref.instruction || ''}
                  onChange={(value) =>
                    update((current) => ({
                      ...current,
                      references: current.references.map((item) =>
                        item.id === ref.id ? { ...item, instruction: value } : item,
                      ),
                    }))
                  }
                />
              ))}
          </Section>
        )}
        {generation}
        {description}
      </>
    );
  else if (scene.id === 'product-main')
    fields = (
      <>
        <Section title="商品原图">{uploader('product', '商品原图')}</Section>
        <Section title="选择场景">
          <Segments
            value={state.sceneTab}
            choices={[
              ['templates', '推荐场景'],
              ['custom', '自定义'],
              ['reference', '参考图'],
            ]}
            onChange={(sceneTab) => update({ sceneTab: sceneTab as EditorState['sceneTab'] })}
          />
          {state.sceneTab === 'templates' ? (
            <div className="cm-scene-choices">
              {templates.map((template) => (
                <button
                  key={template.id}
                  type="button"
                  aria-pressed={state.template === template.id}
                  onClick={() => update({ template: template.id })}
                >
                  {template.image ? (
                    <SceneImage
                      scene={scene}
                      file={template.image}
                      alt={`${template.name}场景示意`}
                      loading="lazy"
                    />
                  ) : (
                    <span className="cm-template-icon">
                      <ImageIcon size={20} />
                    </span>
                  )}
                  <span>
                    <strong>{template.name}</strong>
                    <small>{template.note}</small>
                  </span>
                  <Check size={13} />
                </button>
              ))}
            </div>
          ) : state.sceneTab === 'custom' ? (
            text('场景描述', 'instruction', '描述环境、光线、背景和构图')
          ) : (
            uploader('style', '背景参考图', true)
          )}
        </Section>
        {generation}
        <Select
          label="生成数量"
          value={String(state.count)}
          onChange={(count) => update({ count: Number(count) })}
          options={[
            ['1', '1 张'],
            ['2', '2 张'],
            ['3', '3 张'],
            ['4', '4 张'],
          ]}
        />
        {description}
      </>
    );
  else
    fields = (
      <>
        <Section title="商品照片">
          <p className="cm-help">主图须为 3:4 JPEG；展示照片按文件名自然排序。每张不超过 10 MB。</p>
          <div className="cm-apparel-mains">
            {[0, 1, 2, 3, 4].map((index) => (
              <div key={index}>{uploader(`main-${index}`, `主图 ${index + 1}`, false, 1)}</div>
            ))}
          </div>
          {uploader('display', '展示照片', false, 20)}
          {uploader('logo', '透明 PNG Logo', false, 1)}
        </Section>
        <Section title="商品资料">
          <div className="cm-field-grid">
            {apparelFields.map(([key, label]) => (
              <div
                key={key}
                className={
                  ['composition', 'care', 'design', 'fabric'].includes(key) ? 'cm-field-wide' : ''
                }
              >
                <TextField
                  label={label}
                  name={`apparel:${key}`}
                  rows={['composition', 'care', 'design', 'fabric'].includes(key) ? 2 : undefined}
                  placeholder={['length', 'chest', 'shoulder', 'sleeve'].includes(key) ? 'cm' : ''}
                  value={state.apparel[key] || ''}
                  onChange={(value) =>
                    update((current) => ({
                      ...current,
                      apparel: { ...current.apparel, [key]: value },
                      apparelSaved: false,
                    }))
                  }
                />
              </div>
            ))}
          </div>
        </Section>
      </>
    );
  const saveApparel = () => {
    const current = latest.current;
    const missing = [0, 1, 2, 3, 4].find(
      (index) => !current.references.some((ref) => ref.role === `main-${index}`),
    );
    let error = '';
    if (missing !== undefined) error = `请上传主图 ${missing + 1}（3:4 JPEG）。`;
    else if (!current.references.some((ref) => ref.role === 'display'))
      error = '请上传至少一张展示照片。';
    else if (!current.references.some((ref) => ref.role === 'logo'))
      error = '请上传透明 PNG Logo。';
    else {
      const missingField = apparelFields.find(
        ([key]) => key !== 'sku' && !current.apparel[key]?.trim(),
      );
      if (missingField) error = `请填写${missingField[1]}。`;
    }
    if (error) {
      update({ error });
      return;
    }
    update({ error: '', apparelSaved: true, apparelVersion: current.apparelVersion + 1 });
    notify('整套方案已准备好。');
  };
  const layoutApparel = () => {
    if (!latest.current.apparelSaved || latest.current.busy) return;
    update({ busy: true, progress: 20 });
    later(() => update({ progress: 70 }), 450);
    later(() => {
      update((current) => ({
        ...current,
        busy: false,
        view: 'results',
        results: buildResults(scene, current),
      }));
      notify('排版示例已就绪。');
    }, 1000);
  };
  return (
    <div
      className={`cm-editor-page ${state.results.length && state.view === 'results' && !state.busy ? 'cm-has-results' : ''}`}
    >
      <nav className="cm-editor-nav" aria-label="工具导航">
        <Link href="/create" className="cm-back">
          <ArrowLeft size={13} />
          <span>工具目录</span>
        </Link>
        <span className="cm-nav-divider">/</span>
        <h1>{scene.name}</h1>
      </nav>
      <div className={`cm-editor-grid ${scene.id === 'apparel-catalog' ? 'cm-apparel-grid' : ''}`}>
        <Glass className="cm-config-panel" refract={false}>
          <div className="cm-config-scroll">
            <fieldset disabled={state.busy}>
              <Section title="模型">
                <ModelSelector
                  capability="image"
                  value={state.modelId}
                  onChange={(modelId) => update({ modelId, apparelSaved: false })}
                  disabled={state.busy}
                  className="cm-glide-select"
                />
                <p className="cm-help">模型选择仅用于本地设置，当前展示示例素材。</p>
              </Section>
              {fields}
            </fieldset>
          </div>
          <footer className="cm-action-bar">
            {state.error && (
              <p className="cm-error" role="alert">
                {state.error}
              </p>
            )}
            {scene.id === 'apparel-catalog' ? (
              <>
                <button
                  type="button"
                  className="cm-button cm-primary"
                  disabled={state.busy}
                  onClick={saveApparel}
                >
                  {state.busy ? (
                    <>
                      <span className="cm-spinner" />
                      正在处理…
                    </>
                  ) : state.apparelSaved ? (
                    '保存为新版本'
                  ) : (
                    '保存整套方案'
                  )}
                </button>
                {state.apparelSaved && (
                  <button
                    type="button"
                    className="cm-button cm-secondary"
                    disabled={state.busy}
                    onClick={layoutApparel}
                  >
                    开始整套排版
                  </button>
                )}
              </>
            ) : (
              <>
                <div className="cm-action-summary">
                  <span>{total} 张图片</span>
                </div>
                <div className="cm-primary-row">
                  {state.stage === 'review' && (
                    <button
                      type="button"
                      className="cm-button cm-secondary"
                      disabled={state.busy}
                      onClick={() => update({ stage: 'configure' })}
                    >
                      上一步
                    </button>
                  )}
                  <button
                    type="button"
                    className="cm-button cm-primary"
                    disabled={state.busy || !hasInput || total < 1}
                    onClick={generate}
                  >
                    {state.busy ? (
                      <>
                        <span className="cm-spinner" />
                        正在准备…
                      </>
                    ) : !hasInput ? (
                      scene.id === 'clone' ? (
                        '请上传复刻参考图'
                      ) : (
                        '请上传产品图'
                      )
                    ) : scene.id === 'detail' && state.stage === 'configure' ? (
                      `下一步：确认模块内容（${state.modules.length}项）`
                    ) : (
                      `一键生成 ${total} 张`
                    )}
                  </button>
                </div>
                <div className="cm-secondary-actions">
                  <button
                    type="button"
                    className="cm-text-button"
                    disabled={state.busy}
                    onClick={saveDraft}
                  >
                    保存草稿
                  </button>
                  <button
                    type="button"
                    className="cm-text-button"
                    disabled={state.busy}
                    onClick={() => router.push('/create')}
                  >
                    取消方案
                  </button>
                </div>
              </>
            )}
          </footer>
        </Glass>
        <Glass as="aside" className="cm-preview-panel" refract={false} aria-label="电商创作方案">
          {state.busy ? (
            <div className="cm-generating" role="status" aria-live="polite">
              <div className="cm-generating-art">
                <SceneImage scene={scene} alt="商品视觉示例" />
                <div />
              </div>
              <span className="cm-spinner" />
              <h2>{state.progress < 45 ? '正在准备画面' : '正在载入示例结果'}</h2>
              <p>正在整理画面与布局</p>
              <div className="cm-progress">
                <i style={{ width: `${state.progress}%` }} />
              </div>
            </div>
          ) : (
            <>
              <div className="cm-preview-toolbar">
                <div>
                  <span className="cm-overline">
                    {scene.id === 'apparel-catalog'
                      ? 'APPAREL STUDIO'
                      : scene.id === 'detail'
                        ? 'A+ CONTENT'
                        : 'CREATIVE STUDIO'}
                  </span>
                  <h2>
                    {state.results.length && state.view === 'results'
                      ? '创作结果'
                      : scene.id === 'apparel-catalog'
                        ? '整套效果'
                        : scene.name}
                  </h2>
                  {state.results.length && state.view === 'results' ? (
                    <span>{state.results.length} 张 · 示例</span>
                  ) : scene.id === 'apparel-catalog' ? (
                    <span>
                      {state.apparelSaved ? `方案 v${state.apparelVersion}` : '排版效果示例'}
                    </span>
                  ) : null}
                </div>
                {state.results.length > 0 && (
                  <button
                    type="button"
                    className="cm-text-button"
                    onClick={() =>
                      update({ view: state.view === 'results' ? 'examples' : 'results' })
                    }
                  >
                    {state.view === 'results' ? '查看示例' : '查看结果'}
                  </button>
                )}
              </div>
              {state.results.length && state.view === 'results' ? (
                <Suspense fallback={<p className="cm-help">正在载入作品…</p>}>
                  <CommerceResults
                    scene={scene}
                    results={state.results}
                    onRegenerate={regenerate}
                    onView={setDialog}
                  />
                </Suspense>
              ) : (
                <CommerceExamples
                  scene={scene}
                  product={state.references.find((ref) => ref.role === 'product')}
                  modules={state.modules}
                  onView={setDialog}
                  apparelVersion={state.apparelVersion}
                />
              )}
            </>
          )}
        </Glass>
      </div>
      {dialog && (
        <Suspense fallback={null}>
          <CommerceDialog
            title={dialog === 'layouts' ? '选择卖点图版式参考' : dialog.title}
            onClose={() => setDialog(null)}
            image={dialog === 'layouts' ? undefined : dialog}
          >
            {dialog === 'layouts' && (
              <>
                <p className="cm-help">为每张卖点图指定版式，生成时使用对应构图要求。</p>
                {state.counts.selling ? (
                  Array.from({ length: state.counts.selling }, (_, index) => (
                    <Select
                      key={index}
                      label={`卖点图 ${index + 1}`}
                      value={state.layouts[index] || '自动分配'}
                      options={sellingLayouts}
                      onChange={(value) =>
                        update((current) => {
                          const layouts = [...current.layouts];
                          layouts[index] = value;
                          return { ...current, layouts };
                        })
                      }
                    />
                  ))
                ) : (
                  <p className="cm-help">请先添加卖点图数量。</p>
                )}
                <button
                  type="button"
                  className="cm-button cm-primary"
                  onClick={() => setDialog(null)}
                >
                  完成
                </button>
              </>
            )}
          </CommerceDialog>
        </Suspense>
      )}
    </div>
  );
}
