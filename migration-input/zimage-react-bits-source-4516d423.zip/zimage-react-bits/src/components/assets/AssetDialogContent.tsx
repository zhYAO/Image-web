'use client';
import { useEffect, useRef } from 'react';
import { Check, Folder, Plus, X } from 'lucide-react';
import { ASSET_COLLECTIONS, type AssetState } from './library';
export type AssetDialogState =
  { kind: 'detail'; id: string; ids: string[] } | { kind: 'collection'; ids: string[] };
type Props = {
  state: AssetState;
  dialogState: AssetDialogState;
  membership: (ids: string[], included: boolean, collection?: string) => void;
  closeDialog: () => void;
};
export default function AssetDialogContent({ state, dialogState, membership, closeDialog }: Props) {
  const content = useRef<HTMLDivElement>(null);
  useEffect(() => {
    content.current
      ?.querySelector<HTMLButtonElement>('[data-close-dialog]')
      ?.focus({ preventScroll: true });
  }, [dialogState.kind]);
  return (
    <div ref={content}>
      {dialogState.kind === 'collection' && (
        <div className="za-collection-dialog">
          <div className="za-dialog-heading">
            <div>
              <span className="za-eyebrow">CURATE YOUR INSPIRATION</span>
              <h2 id="za-dialog-title">整理到合集</h2>
              <p>已选择 {dialogState.ids.length} 张素材</p>
            </div>
            <button
              type="button"
              data-close-dialog
              className="za-icon-button"
              aria-label="关闭合集"
              onClick={closeDialog}
            >
              <X />
            </button>
          </div>
          <div className="za-collection-options">
            {ASSET_COLLECTIONS.map((collection) => {
              const count = dialogState.ids.filter((id) =>
                state.collections[collection.id].has(id),
              ).length;
              const included = count === dialogState.ids.length;
              return (
                <button
                  key={collection.id}
                  type="button"
                  className={`za-collection-option ${included ? 'is-included' : ''}`}
                  aria-pressed={included}
                  aria-label={included ? `从${collection.name}移出` : `加入${collection.name}`}
                  onClick={() => membership(dialogState.ids, !included, collection.id)}
                >
                  <span className={`za-folder-icon za-tone-${collection.tone}`}>
                    <Folder />
                  </span>
                  <span>
                    <strong>{collection.name}</strong>
                    <small>
                      {included
                        ? '已在此合集中'
                        : count
                          ? `${count} 张已在此合集中`
                          : `${state.collections[collection.id].size} 张素材`}
                    </small>
                  </span>
                  <span className="za-membership">{included ? <Check /> : <Plus />}</span>
                </button>
              );
            })}
          </div>
          <button
            type="button"
            className="za-button za-button-primary za-dialog-done"
            onClick={closeDialog}
          >
            完成
          </button>
        </div>
      )}
    </div>
  );
}
