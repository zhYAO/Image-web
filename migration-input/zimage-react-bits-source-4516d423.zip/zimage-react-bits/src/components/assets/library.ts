export type AssetType = 'scene' | 'product' | 'model' | 'detail';
export type Asset = {
  id: string;
  name: string;
  file: string;
  type: AssetType;
  typeLabel: string;
  tags: readonly string[];
  width: number;
  height: number;
};
export const ASSET_TYPES = [
  ['all', '全部类型'],
  ['product', '商品图'],
  ['scene', '场景图'],
  ['model', '模特图'],
  ['detail', '细节图'],
] as const;
const item = (
  id: string,
  name: string,
  file: string,
  type: AssetType,
  tags: string[],
  width = 1254,
  height = 1254,
): Asset => ({
  id,
  name,
  file: `/assets/pages/${file}.webp`,
  type,
  typeLabel: ASSET_TYPES.find(([key]) => key === type)![1],
  tags,
  width,
  height,
});
export const ASSET_ITEMS: readonly Asset[] = [
  item('amber-sound', '午后，听见暖意', 'meitu-v1/kit-scene', 'scene', [
    '耳机',
    '暖调',
    '生活方式',
  ]),
  item('botanical-perfume', '光落在香氛上', 'meitu-v1/shoot-botanical', 'scene', [
    '香氛',
    '自然光',
    '植物',
  ]),
  item(
    'linen-portrait',
    '自在的日常',
    'apparel-v2/main-1',
    'model',
    ['衬衫', '服饰', '奶油色'],
    360,
    480,
  ),
  item('lilac-cup', '一杯淡紫色', 'meitu-v1/clone-result', 'scene', ['水杯', '紫色', '生活方式']),
  item(
    'blue-studio',
    '深蓝声场',
    'meitu-v1/detail-hero',
    'product',
    ['耳机', '科技', '深蓝'],
    1672,
    941,
  ),
  item('headphone-study', '温柔的弧线', 'meitu-v1/kit-product', 'product', [
    '耳机',
    '白底',
    '暖调',
  ]),
  item('perfume-studio', '留白与香气', 'meitu-v1/shoot-studio', 'product', [
    '香氛',
    '光影',
    '奶油色',
  ]),
  item('warm-portrait', '沉浸这一刻', 'meitu-v1/kit-model', 'model', ['耳机', '人像', '暖调']),
  item(
    'fabric-detail',
    '质感，近一点',
    'apparel-v2/main-2',
    'detail',
    ['衬衫', '服饰', '材质'],
    360,
    480,
  ),
  item('mint-cup', '薄荷色的早晨', 'meitu-v1/clone-reference', 'scene', [
    '水杯',
    '薄荷绿',
    '自然光',
  ]),
  item('headphone-detail', '细节里的温度', 'meitu-v1/kit-detail', 'detail', [
    '耳机',
    '材质',
    '暖调',
  ]),
  item(
    'blue-detail',
    '蓝色的微观世界',
    'meitu-v1/detail-texture',
    'detail',
    ['耳机', '科技', '深蓝'],
    1672,
    941,
  ),
];
export const ASSET_COLLECTIONS = [
  {
    id: 'warm',
    name: '暖调日常',
    description: '把温柔留在画面里',
    tone: 'amber',
    ids: ['amber-sound', 'headphone-study', 'warm-portrait', 'headphone-detail'],
  },
  {
    id: 'light',
    name: '自然光影',
    description: '光、留白与呼吸感',
    tone: 'sage',
    ids: ['botanical-perfume', 'perfume-studio', 'mint-cup', 'lilac-cup'],
  },
  {
    id: 'style',
    name: '质感灵感',
    description: '让每一处细节发光',
    tone: 'violet',
    ids: ['linen-portrait', 'fabric-detail', 'blue-studio', 'blue-detail'],
  },
] as const;
export type AssetFilters = { query: string; scope: string; type: string; sort: string };
export type AssetState = AssetFilters & {
  favorites: Set<string>;
  selected: Set<string>;
  collections: Record<string, Set<string>>;
};
export const initialAssetState = (): AssetState => ({
  query: '',
  scope: 'all',
  type: 'all',
  sort: 'curated',
  favorites: new Set(),
  selected: new Set(),
  collections: Object.fromEntries(ASSET_COLLECTIONS.map((c) => [c.id, new Set<string>(c.ids)])),
});
export function orderedAssets(sort: string) {
  const items = [...ASSET_ITEMS];
  if (sort === 'size') items.sort((a, b) => b.width * b.height - a.width * a.height);
  if (sort === 'name') items.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
  return items;
}
export function visibleAssets(state: AssetState) {
  const query = state.query.trim().toLocaleLowerCase();
  const collection = state.scope.startsWith('collection:')
    ? state.collections[state.scope.slice(11)]
    : null;
  return orderedAssets(state.sort).filter(
    (asset) =>
      (state.type === 'all' || asset.type === state.type) &&
      (state.scope !== 'favorites' || state.favorites.has(asset.id)) &&
      (!collection || collection.has(asset.id)) &&
      (!query ||
        [asset.name, asset.typeLabel, 'ZImage', ...asset.tags]
          .join(' ')
          .toLocaleLowerCase()
          .includes(query)),
  );
}
export function updateMembership(set: Set<string>, ids: readonly string[], included: boolean) {
  const next = new Set(set);
  const known = new Set(ASSET_ITEMS.map((asset) => asset.id));
  ids.forEach((id) => {
    if (known.has(id)) {
      if (included) next.add(id);
      else next.delete(id);
    }
  });
  return next;
}

export function membershipEdit(
  state: AssetState,
  ids: readonly string[],
  included: boolean,
  collection?: string,
) {
  const prior = new Map(
    ids.map((id) => [id, (collection ? state.collections[collection] : state.favorites).has(id)]),
  );
  function apply(current: AssetState, undo = false) {
    let members = new Set(collection ? current.collections[collection] : current.favorites);
    if (undo)
      prior.forEach((had, id) => {
        members = updateMembership(members, [id], had);
      });
    else members = updateMembership(members, ids, included);
    return collection
      ? { ...current, collections: { ...current.collections, [collection]: members } }
      : { ...current, favorites: members };
  }
  return {
    apply: (current: AssetState) => apply(current),
    undo: (current: AssetState) => apply(current, true),
  };
}
