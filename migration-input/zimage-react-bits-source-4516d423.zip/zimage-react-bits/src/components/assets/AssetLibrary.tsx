'use client';

import Link from 'next/link';
import dynamic from 'next/dynamic';
import AssetImage from './AssetImage';
import GlideSelect from '@/components/react-bits/GlideSelect';
import { useEffect, useMemo, useRef, useState, type CSSProperties, type Ref } from 'react';
import {
  ArrowUpRight,
  Check,
  Folder,
  Grid2X2,
  Heart,
  Plus,
  Search,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { Glass } from '@/components/Glass';
import {
  ASSET_COLLECTIONS,
  ASSET_ITEMS,
  ASSET_TYPES,
  initialAssetState,
  membershipEdit,
  orderedAssets,
  updateMembership,
  visibleAssets,
  type AssetState,
} from './library';

import type { AssetDialogState } from './AssetDialogContent';
type DialogState = AssetDialogState;
const AssetDialogContent = dynamic(() => import('./AssetDialogContent'), {
  loading: () => (
    <p id="za-dialog-title" className="za-dialog-loading">
      正在载入…
    </p>
  ),
});
const ImagePreviewDialog = dynamic(() => import('@/components/ImagePreviewDialog'), { ssr: false });
type Feedback = { text: string; undo?: (state: AssetState) => AssetState };

export default function AssetLibrary() {
  const [state, setState] = useState(initialAssetState);
  const [dialogState, setDialogState] = useState<DialogState | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const dialogTrigger = useRef<HTMLElement | null>(null);
  const resultTitle = useRef<HTMLHeadingElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  const allItems = useMemo(() => orderedAssets(state.sort), [state.sort]);
  const visible = useMemo(() => visibleAssets(state), [state]);
  const visibleIds = useMemo(() => new Set(visible.map((asset) => asset.id)), [visible]);
  const scopeTitle =
    state.scope === 'favorites'
      ? '已收藏'
      : ASSET_COLLECTIONS.find((c) => state.scope === `collection:${c.id}`)?.name || '全部素材';
  const allSelected = visible.length > 0 && visible.every((asset) => state.selected.has(asset.id));
  const detailIndex = dialogState?.kind === 'detail' ? dialogState.ids.indexOf(dialogState.id) : 0;
  const detailAsset =
    dialogState?.kind === 'detail'
      ? ASSET_ITEMS.find((asset) => asset.id === dialogState.id)
      : null;

  useEffect(() => {
    if (!feedback) return;
    const timer = window.setTimeout(() => setFeedback(null), 7000);
    return () => window.clearTimeout(timer);
  }, [feedback]);
  useEffect(() => {
    if (dialogState?.kind === 'collection' && !dialogRef.current?.open) {
      dialogRef.current?.showModal();
      dialogRef.current
        ?.querySelector<HTMLButtonElement>('[data-close-dialog]')
        ?.focus({ preventScroll: true });
    }
    if (dialogState?.kind !== 'collection' && dialogRef.current?.open) dialogRef.current.close();
  }, [dialogState]);
  useEffect(() => {
    const active = document.activeElement as HTMLElement | null;
    if (!dialogState && active?.closest('[data-asset-card][hidden]'))
      resultTitle.current?.focus({ preventScroll: true });
  }, [visibleIds, dialogState]);

  function filter(key: 'query' | 'scope' | 'type' | 'sort', value: string) {
    setState((current) => ({ ...current, [key]: key === 'query' ? value.slice(0, 120) : value }));
  }
  function resetFilters() {
    setState((current) => ({ ...current, query: '', scope: 'all', type: 'all', sort: 'curated' }));
  }
  function membership(ids: string[], included: boolean, collection?: string) {
    const active = document.activeElement as HTMLElement | null;
    window.requestAnimationFrame(() => {
      if (!dialogRef.current?.open && active?.closest('[data-asset-card][hidden]'))
        resultTitle.current?.focus({ preventScroll: true });
    });
    const edit = membershipEdit(state, ids, included, collection);
    setState(edit.apply);
    setFeedback({
      text: collection
        ? included
          ? '已加入合集'
          : '已从合集中移出'
        : included
          ? ids.length > 1
            ? `已收藏 ${ids.length} 张素材`
            : '已加入收藏'
          : '已取消收藏',
      undo: edit.undo,
    });
  }
  function openDialog(next: DialogState, trigger: HTMLElement) {
    if (!dialogState) dialogTrigger.current = trigger;
    setFeedback(null);
    setDialogState(next);
  }
  function closeDialog() {
    setDialogState(null);
    const trigger = dialogTrigger.current;
    window.requestAnimationFrame(() => {
      if (trigger?.isConnected && !trigger.closest('[hidden]'))
        trigger.focus({ preventScroll: true });
      else resultTitle.current?.focus({ preventScroll: true });
    });
  }
  function moveDetail(direction: number) {
    if (dialogState?.kind !== 'detail') return;
    const id = dialogState.ids[detailIndex + direction];
    if (id) setDialogState({ ...dialogState, id });
  }
  function undo() {
    if (feedback?.undo) setState(feedback.undo);
    setFeedback({ text: '已撤销' });
  }
  const feedbackContent = feedback ? (
    <>
      <Check />
      <span>{feedback.text}</span>
      {feedback.undo && (
        <button className="za-text-button" type="button" onClick={undo}>
          撤销
        </button>
      )}
    </>
  ) : null;

  return (
    <div className="za-assets-host">
      <div className="za-assets">
        <div className="za-main" id="za-library-content" tabIndex={-1}>
          <section className="za-intro">
            <div>
              <span className="za-eyebrow">YOUR CREATIVE LIBRARY</span>
              <h1>
                让灵感，<span>有处可寻。</span>
              </h1>
              <p>每一个喜欢的画面，都可能是下一次创作的开始。</p>
            </div>
            <Link href="/create" className="za-button za-button-primary">
              <Plus />
              开始创作
            </Link>
          </section>
          <section className="za-collections-section" aria-label="灵感合集">
            <div className="za-section-eyebrow">
              <span>灵感合集</span>
              <span>COLLECTIONS / 03</span>
            </div>
            <div className="za-collections">
              {ASSET_COLLECTIONS.map((collection) => {
                const covers = ASSET_ITEMS.filter((asset) =>
                  state.collections[collection.id].has(asset.id),
                ).slice(0, 3);
                return (
                  <Glass
                    as="button"
                    key={collection.id}
                    type="button"
                    className={`za-collection liquid-glass--interactive za-tone-${collection.tone}`}
                    aria-pressed={state.scope === `collection:${collection.id}`}
                    onClick={() => filter('scope', `collection:${collection.id}`)}
                  >
                    <span className="za-collection-art" aria-hidden="true">
                      {ASSET_ITEMS.map((asset) => (
                        <span
                          key={asset.id}
                          data-collection-cover={asset.id}
                          hidden={!covers.includes(asset)}
                          style={{ '--stack': covers.indexOf(asset) } as CSSProperties}
                        >
                          <img
                            src={asset.file}
                            alt=""
                            width={asset.width}
                            height={asset.height}
                            loading="lazy"
                            decoding="async"
                          />
                        </span>
                      ))}
                      <span className="za-collection-art-empty" hidden={covers.length > 0}>
                        <Folder />
                      </span>
                    </span>
                    <span className="za-collection-copy">
                      <span className="za-collection-title">
                        {collection.name}
                        <ArrowUpRight />
                      </span>
                      <span>{collection.description}</span>
                      <span className="za-collection-count">
                        {state.collections[collection.id].size} 张素材
                      </span>
                    </span>
                  </Glass>
                );
              })}
            </div>
          </section>
          <section className="za-library" aria-label="素材库">
            <div className="za-library-top">
              <div className="za-scope-tabs" role="group" aria-label="素材范围">
                <button
                  type="button"
                  aria-pressed={state.scope === 'all'}
                  onClick={() => filter('scope', 'all')}
                >
                  <Grid2X2 />
                  全部素材 <span>{ASSET_ITEMS.length}</span>
                </button>
                <button
                  type="button"
                  aria-pressed={state.scope === 'favorites'}
                  onClick={() => filter('scope', 'favorites')}
                >
                  <Heart />
                  已收藏 <span>{state.favorites.size}</span>
                </button>
              </div>
              <span className="za-library-label">灵感，从这里延续</span>
            </div>
            <Glass className="za-controls">
              <label className="za-search">
                <Search />
                <input
                  ref={searchInput}
                  type="search"
                  placeholder="搜索名称、风格、关键词…"
                  aria-label="搜索素材"
                  maxLength={120}
                  value={state.query}
                  onChange={(event) => filter('query', event.target.value)}
                />
                <button
                  type="button"
                  className="za-clear-search"
                  aria-label="清空搜索"
                  onClick={() => {
                    filter('query', '');
                    searchInput.current?.focus();
                  }}
                >
                  <X />
                </button>
              </label>
              <div className="za-select-controls">
                <div className="za-select-label">
                  <SlidersHorizontal />
                  <GlideSelect
                    ariaLabel="素材类型"
                    value={state.type}
                    options={ASSET_TYPES.map(([value, label]) => ({ value, label }))}
                    onChange={(value) => filter('type', value)}
                  />
                </div>
                <span className="za-controls-divider" />
                <div className="za-select-label">
                  <GlideSelect
                    ariaLabel="素材排序"
                    value={state.sort}
                    options={[
                      { value: 'curated', label: '推荐排序' },
                      { value: 'name', label: '名称排序' },
                      { value: 'size', label: '尺寸从大到小' },
                    ]}
                    onChange={(value) => filter('sort', value)}
                    align="right"
                  />
                </div>
              </div>
            </Glass>
            <div className="za-results-heading">
              <div>
                <h2 ref={resultTitle} tabIndex={-1}>
                  {scopeTitle}
                </h2>
                <span>{visible.length} 张图片</span>
              </div>
              <button
                type="button"
                className="za-text-button"
                hidden={!visible.length}
                aria-pressed={allSelected}
                onClick={() =>
                  setState((current) => ({
                    ...current,
                    selected: updateMembership(
                      current.selected,
                      visible.map((asset) => asset.id),
                      !allSelected,
                    ),
                  }))
                }
              >
                {allSelected ? '取消全选' : '选择全部'}
              </button>
            </div>
            <div className="za-grid" hidden={!visible.length}>
              {allItems.map((asset, index) => (
                <article
                  key={asset.id}
                  className={`za-card ${state.selected.has(asset.id) ? 'is-selected' : ''}`}
                  data-asset-card={asset.id}
                  hidden={!visibleIds.has(asset.id)}
                >
                  <div className="za-card-visual">
                    <button
                      type="button"
                      className="za-card-open"
                      aria-label={`查看 ${asset.name}`}
                      onClick={(event) =>
                        openDialog(
                          { kind: 'detail', id: asset.id, ids: visible.map((item) => item.id) },
                          event.currentTarget,
                        )
                      }
                    >
                      <AssetImage asset={asset} eager={index < 4} />
                      <span className="za-open-hint">
                        查看图片 <ArrowUpRight />
                      </span>
                    </button>
                    <label className="za-card-select">
                      <input
                        type="checkbox"
                        aria-label={`选择 ${asset.name}`}
                        checked={state.selected.has(asset.id)}
                        onChange={() =>
                          setState((current) => ({
                            ...current,
                            selected: updateMembership(
                              current.selected,
                              [asset.id],
                              !current.selected.has(asset.id),
                            ),
                          }))
                        }
                      />
                      <span aria-hidden="true">
                        <Check />
                      </span>
                    </label>
                    <button
                      type="button"
                      className={`za-card-heart ${state.favorites.has(asset.id) ? 'is-favorite' : ''}`}
                      aria-label={`${state.favorites.has(asset.id) ? '取消收藏' : '收藏'} ${asset.name}`}
                      aria-pressed={state.favorites.has(asset.id)}
                      onClick={() => membership([asset.id], !state.favorites.has(asset.id))}
                    >
                      <Heart />
                    </button>
                  </div>
                  <div className="za-card-caption">
                    <h3>{asset.name}</h3>
                    <span>
                      {asset.typeLabel}
                      <i />
                      {asset.width} × {asset.height}
                    </span>
                  </div>
                </article>
              ))}
            </div>
            <div className="za-empty" hidden={visible.length > 0}>
              <span className="za-empty-icon">
                {state.scope === 'favorites' ? <Heart /> : <Search />}
              </span>
              <h3>
                {state.scope === 'favorites' && !state.query && state.type === 'all'
                  ? '把喜欢的画面留在这里'
                  : '暂时没有找到素材'}
              </h3>
              <p>
                {state.scope === 'favorites' && !state.query && state.type === 'all'
                  ? '轻点图片上的爱心，慢慢整理自己的灵感。'
                  : '试试其他关键词，或放宽筛选条件。'}
              </p>
              <button type="button" className="za-button za-button-primary" onClick={resetFilters}>
                浏览全部素材
              </button>
            </div>
            <p className="za-bottom-note">
              每一个好想法，都值得被好好收藏。<span>ZImage</span>
            </p>
          </section>
        </div>
        <Glass className="za-selection" hidden={!state.selected.size}>
          <span className="za-selected-count">
            <Check />
            <span>已选择 {state.selected.size} 张</span>
          </span>
          <span className="za-selection-actions">
            <button
              type="button"
              className="za-button za-button-quiet"
              onClick={() => membership([...state.selected], true)}
            >
              <Heart />
              <span>收藏</span>
            </button>
            <button
              type="button"
              className="za-button za-button-quiet"
              onClick={(event) =>
                openDialog({ kind: 'collection', ids: [...state.selected] }, event.currentTarget)
              }
            >
              <Folder />
              <span>加入合集</span>
            </button>
            <button
              type="button"
              className="za-icon-button"
              aria-label="取消选择"
              onClick={() => {
                setState((current) => ({ ...current, selected: new Set() }));
                resultTitle.current?.focus({ preventScroll: true });
              }}
            >
              <X />
            </button>
          </span>
        </Glass>
        <Glass
          className="za-feedback"
          role="status"
          aria-live="polite"
          hidden={!feedback || !!dialogState}
        >
          {!dialogState && feedbackContent}
        </Glass>
        <span className="za-sr-only" role="status" aria-live="polite" aria-atomic="true">
          {scopeTitle}，共 {visible.length} 张图片
          {state.selected.size ? `，已选择 ${state.selected.size} 张` : ''}
        </span>
        {dialogState?.kind === 'detail' && detailAsset && (
          <ImagePreviewDialog
            image={{ src: detailAsset.file, alt: detailAsset.name }}
            imageOnly
            onClose={closeDialog}
            onPrevious={detailIndex > 0 ? () => moveDetail(-1) : undefined}
            onNext={detailIndex < dialogState.ids.length - 1 ? () => moveDetail(1) : undefined}
          />
        )}
        <Glass
          as="dialog"
          ref={dialogRef as Ref<HTMLElement>}
          className="za-dialog za-dialog-compact"
          aria-labelledby="za-dialog-title"
          onCancel={(event) => {
            event.preventDefault();
            closeDialog();
          }}
          onClick={(event) => {
            if (event.target === event.currentTarget) closeDialog();
          }}
        >
          {dialogState?.kind === 'collection' && (
            <AssetDialogContent
              state={state}
              dialogState={dialogState}
              membership={membership}
              closeDialog={closeDialog}
            />
          )}
          <div className="za-dialog-feedback" role="status" aria-live="polite" hidden={!feedback}>
            {dialogState && feedbackContent}
          </div>
        </Glass>
      </div>
    </div>
  );
}
