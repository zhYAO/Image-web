'use client';
import { memo, useEffect, useRef, useState } from 'react';
import { ImageIcon } from 'lucide-react';
import type { Asset } from './library';

function AssetImageComponent({ asset, eager = false }: { asset: Asset; eager?: boolean }) {
  const ref = useRef<HTMLImageElement>(null);
  const [imageState, setImageState] = useState<'loading' | 'loaded' | 'error'>('loading');
  useEffect(() => {
    if (ref.current?.complete) setImageState(ref.current.naturalWidth ? 'loaded' : 'error');
  }, [asset.file]);
  return (
    <>
      <img
        ref={ref}
        src={asset.file}
        alt={asset.name}
        width={asset.width}
        height={asset.height}
        loading={eager ? 'eager' : 'lazy'}
        decoding="async"
        fetchPriority={eager ? 'high' : undefined}
        data-asset-image
        className={`is-${imageState}`}
        onLoad={() => setImageState('loaded')}
        onError={() => setImageState('error')}
      />
      <span className="za-image-fallback" hidden={imageState !== 'error'}>
        <ImageIcon />
        <span>图片暂时无法显示</span>
      </span>
    </>
  );
}

export default memo(AssetImageComponent);
