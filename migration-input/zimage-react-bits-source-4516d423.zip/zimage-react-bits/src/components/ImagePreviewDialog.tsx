'use client';

import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, ImageIcon, X } from 'lucide-react';
import './image-preview.css';

export type PreviewImage = {
  src: string;
  alt: string;
  title?: string;
  dimensions?: string;
  download?: string;
};

/** Shared full-image viewer, extracted from the product-set preview. */
export default function ImagePreviewDialog({
  image,
  onClose,
  imageOnly = false,
  onPrevious,
  onNext,
}: {
  image: PreviewImage;
  onClose: () => void;
  imageOnly?: boolean;
  onPrevious?: () => void;
  onNext?: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const focused = document.activeElement as HTMLElement | null;
    node.showModal();
    node.querySelector<HTMLButtonElement>('[data-preview-close]')?.focus({ preventScroll: true });
    return () => {
      if (node.open) node.close();
      if (focused?.isConnected && !focused.closest('[hidden]'))
        focused.focus({ preventScroll: true });
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className={`image-preview-dialog${imageOnly ? ' image-preview-only' : ''}`}
      aria-label={image.title || image.alt}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      onKeyDown={(event) => {
        if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
          event.preventDefault();
          (event.key === 'ArrowLeft' ? onPrevious : onNext)?.();
        }
      }}
    >
      <div className="image-preview-heading">
        {!imageOnly && <h2>{image.title || image.alt}</h2>}
        <button
          type="button"
          data-preview-close
          className="image-preview-control"
          aria-label="关闭图片"
          onClick={onClose}
        >
          <X size={18} />
        </button>
      </div>
      <PreviewContent key={image.src} image={image} />
      {(onPrevious || onNext) && (
        <nav className="image-preview-navigation" aria-label="图片导航">
          <button
            type="button"
            className="image-preview-control"
            aria-label="上一张图片"
            disabled={!onPrevious}
            onClick={onPrevious}
          >
            <ChevronLeft size={18} />
          </button>
          <button
            type="button"
            className="image-preview-control"
            aria-label="下一张图片"
            disabled={!onNext}
            onClick={onNext}
          >
            <ChevronRight size={18} />
          </button>
        </nav>
      )}
      {!imageOnly && image.dimensions && (
        <p className="image-preview-help">图片尺寸 · {image.dimensions}</p>
      )}
      {!imageOnly && image.download && (
        <a className="image-preview-download" href={image.src} download={image.download}>
          下载示例图片
        </a>
      )}
    </dialog>
  );
}

/** Keyed by source so a new image always gets a fresh loading/error state. */
function PreviewContent({ image }: { image: PreviewImage }) {
  const [failed, setFailed] = useState(false);
  return (
    <>
      <img
        className="image-preview-full"
        src={image.src}
        alt={image.alt}
        hidden={failed}
        onError={() => setFailed(true)}
      />
      {failed && (
        <div className="image-preview-error" role="status">
          <ImageIcon aria-hidden="true" />
          <p>图片暂时无法显示</p>
        </div>
      )}
    </>
  );
}
