'use client';

// React Bits ShinyText single-band smooth sweep, with app lifecycle gates.
import { useEffect, useRef } from 'react';
import { observeChatMotion } from './motion';
import './chat-effects.css';

const FALLOFF = [0, 0.2, 0.4, 0.6, 0.8, 1];
const smooth = (t: number) => 0.5 - Math.cos(Math.PI * t) / 2;

/** Upstream soft-band geometry; CSS color-mix resolves live application tokens. */
export function shineGradient(position: number) {
  const half = 20;
  const core = half * (1 - 0.8);
  const fade = half - core;
  const stops: [number, number][] = [];
  for (const side of [-1, 1]) {
    for (const f of FALLOFF) {
      stops.push([position + side * (core + fade * (1 - f)), f * f * (3 - 2 * f)]);
    }
  }
  stops.sort((a, b) => a[0] - b[0]);
  const list = stops.map(
    ([at, amount]) =>
      `color-mix(in srgb, var(--text) ${amount * 100}%, var(--primary)) ${at.toFixed(2)}%`,
  );
  return `linear-gradient(120deg, var(--primary) 0%, ${list.join(', ')}, var(--primary) 100%)`;
}

export default function ShinyText({
  text,
  disabled = false,
  className = '',
}: {
  text: string;
  disabled?: boolean;
  className?: string;
}) {
  const root = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const node = root.current;
    if (!node || disabled) return;
    let raf = 0;
    let last = 0;
    let elapsed = 0;
    let alive = true;
    const tick = (now: number) => {
      if (!alive) return;
      elapsed += last ? Math.min(64, now - last) : 0;
      last = now;
      const phase = (elapsed % 2200) / 2200;
      node.style.backgroundImage = shineGradient(122 - 144 * smooth(phase));
      raf = requestAnimationFrame(tick);
    };
    const stop = observeChatMotion(node, (running) => {
      cancelAnimationFrame(raf);
      last = 0;
      if (running && typeof requestAnimationFrame === 'function') raf = requestAnimationFrame(tick);
      else {
        node.dataset.running = 'false';
        node.style.backgroundImage = 'none';
      }
    });
    return () => {
      alive = false;
      node.dataset.running = 'false';
      cancelAnimationFrame(raf);
      stop();
      node.style.backgroundImage = 'none';
    };
  }, [disabled]);
  return (
    <span ref={root} className={`zi-chat-shiny-text ${className}`} data-running="false">
      {text}
    </span>
  );
}
