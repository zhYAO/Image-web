'use client';

import { useEffect, type RefObject } from 'react';

/** Own all animation eligibility listeners; content is never hidden by this gate. */
export function observeChatMotion(
  node: HTMLElement,
  update: (running: boolean, reduced: boolean) => void,
) {
  const preference = window.matchMedia?.('(prefers-reduced-motion: reduce)');
  let visible = true;
  const sync = () => {
    const reduced = preference?.matches ?? true;
    const running = visible && !document.hidden && !reduced;
    node.dataset.running = String(running);
    update(running, reduced);
  };
  const observer =
    typeof IntersectionObserver !== 'undefined'
      ? new IntersectionObserver((entries) => {
          visible = entries.some((entry) => entry.isIntersecting);
          sync();
        })
      : undefined;
  observer?.observe(node);
  preference?.addEventListener('change', sync);
  document.addEventListener('visibilitychange', sync);
  sync();
  return () => {
    observer?.disconnect();
    preference?.removeEventListener('change', sync);
    document.removeEventListener('visibilitychange', sync);
  };
}

export function useChatMotion(ref: RefObject<HTMLElement | null>, enabled = true) {
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (!enabled) {
      node.dataset.running = 'false';
      return;
    }
    return observeChatMotion(node, () => {});
  }, [ref, enabled]);
}
