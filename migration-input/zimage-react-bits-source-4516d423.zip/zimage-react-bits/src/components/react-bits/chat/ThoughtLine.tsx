'use client';

// Adapted from React Bits ThoughtLine, c2a1408; MIT + Commons Clause.
import { useId, useRef, useState } from 'react';
import { Check, ChevronDown, Sparkles } from 'lucide-react';
import { useChatMotion } from './motion';
import './ThoughtLine.css';
import './chat-effects.css';

export interface ThoughtStep {
  id: string;
  label: string;
  description?: string;
  status?: 'pending' | 'active' | 'done';
}
export interface ThoughtLineProps {
  working?: boolean;
  steps: ThoughtStep[];
  title?: string;
  defaultExpanded?: boolean;
  className?: string;
}

export default function ThoughtLine({
  working = true,
  steps,
  title,
  defaultExpanded = true,
  className = '',
}: ThoughtLineProps) {
  const [open, setOpen] = useState(defaultExpanded);
  const ref = useRef<HTMLDivElement>(null);
  const traceId = useId();
  useChatMotion(ref, working);
  const label = title ?? (working ? '正在整理演示思路' : '演示步骤');
  return (
    <div
      ref={ref}
      className={`thought-line zi-chat-thought ${className}`}
      data-running="false"
      data-working={working ? '' : undefined}
      data-open={open ? '' : undefined}
    >
      <button
        type="button"
        className="thought-line__head"
        data-toggle=""
        aria-expanded={open}
        aria-controls={traceId}
        onClick={() => setOpen((value) => !value)}
      >
        <span className="thought-line__glyph" aria-hidden="true">
          <Sparkles />
        </span>
        <span className="thought-line__breath">{label}</span>
        <span className="thought-line__chevron" data-on="" aria-hidden="true">
          <ChevronDown size={16} />
        </span>
      </button>
      <div
        id={traceId}
        className="thought-line__trace"
        data-open={open ? '' : undefined}
        aria-hidden={!open}
      >
        <div className="thought-line__fold">
          <ol className="thought-line__steps">
            {steps.map((step, index) => {
              const status =
                step.status ?? (!working || index < steps.length - 1 ? 'done' : 'active');
              return (
                <li
                  key={step.id}
                  className="thought-line__step"
                  data-status={status}
                  data-done={status === 'done' ? '' : undefined}
                >
                  <span className="thought-line__mark" aria-hidden="true">
                    {status === 'done' ? (
                      <Check size={15} />
                    ) : (
                      <i
                        className={
                          status === 'active' ? 'thought-line__pulse' : 'thought-line__dot'
                        }
                      />
                    )}
                  </span>
                  <span className="thought-line__step-text">
                    <span>{step.label}</span>
                    {step.description && (
                      <span className="zi-chat-step-description">{step.description}</span>
                    )}
                    <span className="thought-line__sr">
                      {status === 'done' ? '已完成' : status === 'active' ? '进行中' : '待处理'}
                    </span>
                  </span>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </div>
  );
}
