'use client';

// Single-sentence subset of React Bits TextType; see docs/react-bits-chat.md.
import { useEffect, useMemo, useRef, useState } from 'react';
import { observeChatMotion } from './motion';
import './chat-effects.css';

const graphemes = (value: string) =>
  typeof Intl !== 'undefined' && Intl.Segmenter
    ? Array.from(
        new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(value),
        (part) => part.segment,
      )
    : Array.from(value);

export interface TextTypeProps {
  text: string;
  typingSpeed?: number;
  loop?: false;
  active?: boolean;
  onTextChange?: (text: string) => void;
  onComplete?: () => void;
  className?: string;
}
export default function TextType({
  text,
  typingSpeed = 28,
  active = true,
  onTextChange,
  onComplete,
  className = '',
}: TextTypeProps) {
  const chars = useMemo(() => graphemes(text), [text]);
  const [count, setCount] = useState(0);
  const countRef = useRef(0);
  const completed = useRef(false);
  const root = useRef<HTMLSpanElement>(null);
  const callbacks = useRef({ onTextChange, onComplete });
  useEffect(() => {
    callbacks.current = { onTextChange, onComplete };
  }, [onTextChange, onComplete]);
  useEffect(() => {
    const node = root.current;
    if (!node || !active || completed.current) return;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    let alive = true;
    let running = false;
    let reduced = false;
    const advance = () => {
      if (!alive) return;
      countRef.current = reduced ? chars.length : Math.min(countRef.current + 1, chars.length);
      setCount(countRef.current);
      callbacks.current.onTextChange?.(chars.slice(0, countRef.current).join(''));
      if (countRef.current === chars.length) {
        completed.current = true;
        node.dataset.running = 'false';
        callbacks.current.onComplete?.();
      } else schedule();
    };
    const schedule = () => {
      clearTimeout(timeout);
      if (!alive || completed.current || (!running && !reduced)) return;
      timeout = setTimeout(advance, reduced ? 0 : Math.max(1, typingSpeed));
    };
    const cleanup = observeChatMotion(node, (eligible, reduce) => {
      running = eligible;
      reduced = reduce;
      schedule();
    });
    return () => {
      alive = false;
      node.dataset.running = 'false';
      clearTimeout(timeout);
      cleanup();
    };
  }, [chars, typingSpeed, active]);
  return (
    <span ref={root} className={`zi-chat-text-type ${className}`} data-running="false">
      <span className="zi-chat-text-type__sr">{text}</span>
      <span aria-hidden="true" className="text-type__content">
        {chars.slice(0, count).map((char, index) => (
          <span className="text-type__char" key={index}>
            {char}
          </span>
        ))}
        {active && count < chars.length && <span className="zi-chat-text-type__cursor">▍</span>}
      </span>
    </span>
  );
}
