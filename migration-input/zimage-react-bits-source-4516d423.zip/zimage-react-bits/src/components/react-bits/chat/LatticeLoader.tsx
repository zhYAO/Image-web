'use client';

// React Bits LatticeLoader: original 3×3 orbit, layered marks and timing.
import { useRef, type CSSProperties } from 'react';
import { useChatMotion } from './motion';
import './LatticeLoader.css';
import './chat-effects.css';

const CELLS = [0, 1, 2, 7, null, 3, 6, 5, 4];
const MARKS = { done: [2, 3, 5, 7], error: [0, 2, 4, 6, 8] };
export default function LatticeLoader({
  state = 'working',
  className = '',
}: {
  state?: 'working' | 'done' | 'error';
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  useChatMotion(ref, state === 'working');
  const mark = state === 'error' ? 'error' : 'done';
  return (
    <span
      ref={ref}
      className={`lattice-loader zi-chat-lattice ${className}`}
      data-status={state}
      data-shape="round"
      data-running="false"
      aria-hidden="true"
      style={{ '--ll-cycle': '864ms' } as CSSProperties}
    >
      <span className="lattice-loader__grid">
        <span className="lattice-loader__layer lattice-loader__run">
          {CELLS.map((unit, index) => (
            <span
              key={index}
              className="lattice-loader__cell"
              data-hole={unit == null ? '' : undefined}
              style={unit == null ? undefined : { animationDelay: `${Math.round(unit * 108)}ms` }}
            />
          ))}
        </span>
        <span className="lattice-loader__layer lattice-loader__mark">
          {CELLS.map((_, index) => (
            <span
              key={index}
              className="lattice-loader__cell"
              data-on={MARKS[mark].includes(index) ? '' : undefined}
            />
          ))}
        </span>
      </span>
    </span>
  );
}
