'use client';

import React, {
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import { Check, ChevronDown } from 'lucide-react';
import { createPortal } from 'react-dom';

/** React Bits / David Haz (2026), MIT + Commons Clause.
 * Adapted from revision 43591e8b3fa327d45633b4e8239ff6742ef706ef.
 * See licenses/react-bits-LICENSE.md and docs/react-bits-selection.md.
 * Retains upstream phase/pop, translated glide pill, sizing and selected-label feedback.
 * Adds dialog-aware portal, bounded scrolling, native click/touch, focus and typeahead. */

import './GlideSelect.css';

export interface GlideSelectOption {
  value: string;
  label: ReactNode;
  /** Plain readable label for typeahead and accessible trigger names. */
  textValue?: string;
  tag?: string;
}

export interface GlideSelectProps {
  options?: readonly (string | GlideSelectOption)[];
  value?: string;
  defaultValue?: string;
  onChange?: (value: string, option: GlideSelectOption) => void;
  placeholder?: string;
  showTags?: boolean;
  accentColor?: string;
  surfaceColor?: string;
  highlightColor?: string;
  textColor?: string;
  size?: 'sm' | 'md' | 'lg';
  radius?: number;
  menuWidth?: number;
  placement?: 'top' | 'bottom';
  align?: 'left' | 'right';
  popDuration?: number;
  glideDuration?: number;
  rememberPosition?: boolean;
  disabled?: boolean;
  ariaLabel?: string;
  includeValueInLabel?: boolean;
  className?: string;
}

type Phase = 'closed' | 'open' | 'closing';

const SIZES: Record<string, { chip: number; row: number; font: number }> = {
  sm: { chip: 28, row: 26, font: 12 },
  md: { chip: 32, row: 30, font: 13 },
  lg: { chip: 44, row: 40, font: 14 },
};
const GAP = 1;
const MENU_GAP = 6;
// Menu border-box: two 4px padding edges and two 1px borders (GlideSelect.css).
const MENU_CHROME = 10;
export function glideMenuHeight(count: number, rowHeight: number) {
  return Math.min(count * rowHeight + Math.max(0, count - 1) * GAP + MENU_CHROME, 280);
}
const DEFAULT_OPTIONS: (string | GlideSelectOption)[] = [];

const norm = (o: string | GlideSelectOption): GlideSelectOption =>
  typeof o === 'string' ? { value: o, label: o } : o;
const textOf = (it: GlideSelectOption) =>
  it.textValue ?? (typeof it.label === 'string' ? it.label : it.value);
const typeaheadIndex = (items: GlideSelectOption[], from: number, ch: string) => {
  const c = ch.toLowerCase();
  const n = items.length;
  for (let k = 1; k <= n; k++) {
    const i = (from + k) % n;
    if (textOf(items[i]).toLowerCase().startsWith(c)) return i;
  }
  return from;
};

const GlideSelect: React.FC<GlideSelectProps> = ({
  options = DEFAULT_OPTIONS,
  value,
  defaultValue,
  onChange,
  placeholder = 'Select…',
  showTags = true,
  accentColor = '#62548a',
  surfaceColor = '#ffffff',
  highlightColor = '#eeeaf7',
  textColor = '#292633',
  size = 'md',
  radius = 10,
  menuWidth = 176,
  placement = 'bottom',
  align = 'left',
  popDuration = 180,
  glideDuration = 220,
  rememberPosition = true,
  disabled = false,
  ariaLabel = 'Select',
  includeValueInLabel = false,
  className = '',
}) => {
  const items = options.map(norm);
  const [inner, setInner] = useState(defaultValue ?? '');
  const current = value ?? inner;
  const selected = items.findIndex((it) => it.value === current);
  const [phase, setPhase] = useState<Phase>('closed');
  const [activeIndex, setActive] = useState<number | null>(null);
  const active =
    activeIndex === null || !items.length ? null : Math.min(activeIndex, items.length - 1);
  const [side, setSide] = useState<'top' | 'bottom'>(placement);
  const rootRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const pillRef = useRef<HTMLSpanElement>(null);
  const instant = useRef(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [host, setHost] = useState<HTMLElement | null>(null);
  const [position, setPosition] = useState<CSSProperties>({});
  const typeahead = useRef({ text: '', time: 0 });
  const id = useId();
  const S = SIZES[size] ?? SIZES.md;
  const step = S.row + GAP;
  const popOut = Math.round((popDuration * 2) / 3);

  useLayoutEffect(() => {
    if (phase !== 'open') return;
    const el = menuRef.current;
    const root = rootRef.current;
    if (!el || !root) return;
    const r = triggerRef.current!.getBoundingClientRect();
    const margin = 12;
    const width = Math.min(Math.max(r.width, menuWidth), window.innerWidth - margin * 2);
    const below = Math.max(0, window.innerHeight - r.bottom - margin - MENU_GAP);
    const above = Math.max(0, r.top - margin - MENU_GAP);
    const wanted = glideMenuHeight(items.length, S.row);
    const down =
      placement === 'bottom'
        ? below >= Math.min(wanted, 140) || below >= above
        : above < Math.min(wanted, 140) && below > above;
    const maxHeight = Math.min(wanted, down ? below : above);
    setSide(down ? 'bottom' : 'top');
    setPosition({
      left: Math.max(
        margin,
        Math.min(align === 'right' ? r.right - width : r.left, window.innerWidth - width - margin),
      ),
      top: down ? r.bottom + MENU_GAP : Math.max(margin, r.top - maxHeight - MENU_GAP),
      width,
      maxHeight,
    });
    el.querySelector<HTMLElement>('[role="listbox"]')?.focus({ preventScroll: true });
    el.style.transitionDuration = instant.current ? '0ms' : '';
    el.dataset.state = 'closed';
    void el.offsetHeight;
    el.dataset.state = 'open';
    const p = pillRef.current;
    if (p) {
      p.style.transition = 'none';
      p.style.transform = `translateY(${Math.max(0, selected) * step}px)`;
      p.style.opacity = '0';
      void p.offsetHeight;
      p.style.transition = '';
    }
  }, [phase, menuWidth, items.length, S.row, step, placement, align, selected]);

  useLayoutEffect(() => {
    const p = pillRef.current;
    if (!p || phase !== 'open') return;
    if (active === null) {
      p.style.opacity = '0';
      return;
    }
    const jump = instant.current || p.style.opacity !== '1';
    p.style.transitionDuration = jump ? '0ms, 150ms' : '';
    p.style.transform = `translateY(${active * step}px)`;
    p.style.opacity = '1';
    instant.current = false;
  }, [active, phase, step]);

  const open = (viaKey: boolean) => {
    if (disabled || !items.length) return;
    setHost(triggerRef.current?.closest('dialog') || document.body);
    clearTimeout(closeTimer.current);
    instant.current = true;
    typeahead.current = { text: '', time: 0 };
    setActive(selected >= 0 ? selected : viaKey ? 0 : null);
    setPhase('open');
  };
  const close = useCallback(
    (mode: 'instant' | 'pop') => {
      setActive(null);
      clearTimeout(closeTimer.current);
      const el = menuRef.current;
      if (mode === 'instant' || !el) {
        setPhase('closed');
        return;
      }
      el.style.transitionDuration = '';
      el.dataset.state = 'closed';
      setPhase('closing');
      closeTimer.current = setTimeout(() => setPhase('closed'), popOut + 20);
    },
    [popOut],
  );
  const pick = (i: number, viaKey: boolean) => {
    const it = items[i];
    if (!it) {
      close('instant');
      return;
    }
    if (it.value !== current) {
      if (value === undefined) setInner(it.value);
      onChange?.(it.value, it);
      if (!viaKey && rootRef.current) rootRef.current.dataset.swap = '';
    }
    close('instant');
    triggerRef.current?.focus({ preventScroll: true });
  };

  const onTriggerKey = (e: React.KeyboardEvent<HTMLElement>) => {
    const k = e.key;
    const n = items.length;
    const cur = active ?? Math.max(0, selected);
    if (phase !== 'open') {
      if (
        k === 'Enter' ||
        k === ' ' ||
        k === 'ArrowDown' ||
        k === 'ArrowUp' ||
        k === 'Home' ||
        k === 'End'
      ) {
        e.preventDefault();
        open(true);
        if (n && (k === 'Home' || k === 'End')) setActive(k === 'Home' ? 0 : n - 1);
      }
      return;
    }
    const go = (i: number) => {
      e.preventDefault();
      instant.current = true;
      setActive(Math.min(n - 1, Math.max(0, i)));
    };
    if (k === 'ArrowDown' || k === 'ArrowUp')
      go(active === null ? cur : cur + (k === 'ArrowDown' ? 1 : -1));
    else if (k === 'Home' || k === 'End') go(k === 'Home' ? 0 : n - 1);
    else if (k === 'Enter' || k === ' ') {
      e.preventDefault();
      pick(cur, true);
    } else if (k === 'Escape' || k === 'Tab') {
      if (k === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
      }
      triggerRef.current?.focus({ preventScroll: true });
      close('instant');
    } else if (k.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
      const now = Date.now();
      const text = now - typeahead.current.time < 700 ? typeahead.current.text + k : k;
      typeahead.current = { text, time: now };
      const repeated = [...text].every((ch) => ch === text[0]);
      go(typeaheadIndex(items, repeated ? cur : cur - 1, repeated ? k : text));
    }
  };

  useEffect(() => {
    if (phase === 'closed') return undefined;
    const onDown = (e: PointerEvent) => {
      if (
        !rootRef.current?.contains(e.target as Node) &&
        !menuRef.current?.contains(e.target as Node)
      )
        close('instant');
    };
    const dismissAfterLayoutChange = () => {
      // A disappearing focused listbox must not strand focus on the document.
      // Pointer dismissal intentionally leaves focus to the clicked destination.
      if (menuRef.current?.contains(document.activeElement))
        triggerRef.current?.focus({ preventScroll: true });
      close('instant');
    };
    const onScroll = (e: Event) => {
      if (!menuRef.current?.contains(e.target as Node)) dismissAfterLayoutChange();
    };
    const onResize = dismissAfterLayoutChange;
    document.addEventListener('pointerdown', onDown, true);
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onResize);
    return () => {
      document.removeEventListener('pointerdown', onDown, true);
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', onResize);
    };
  }, [phase, close]);
  useEffect(() => {
    // External disabling invalidates an already-open interactive popup.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if ((disabled || !items.length) && phase !== 'closed') close('instant');
  }, [disabled, items.length, phase, close]);
  useEffect(() => () => clearTimeout(closeTimer.current), []);

  useEffect(() => {
    if (phase !== 'open' || active === null) return;
    const menu = menuRef.current;
    const option = menu?.querySelector<HTMLElement>(`[data-index="${active}"]`);
    if (!menu || !option || !menu.clientHeight) return;
    // scrollIntoView also scrolls enclosing dialogs/documents, which can move
    // the trigger and dismiss this popup. Only its own scrollport should move.
    const top = option.offsetTop + (option.parentElement?.offsetTop ?? 0);
    const bottom = top + option.offsetHeight;
    if (top < menu.scrollTop) menu.scrollTop = top;
    else if (bottom > menu.scrollTop + menu.clientHeight)
      menu.scrollTop = bottom - menu.clientHeight;
  }, [active, phase, position]);
  const onListOver = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch') return;
    const row = (e.target as HTMLElement).closest<HTMLElement>('[data-index]');
    if (row) setActive(Number(row.dataset.index));
  };
  const origin = `${side === 'bottom' ? 'top' : 'bottom'} ${align}`;
  const variables = {
    '--gs-accent': accentColor,
    '--gs-surface': surfaceColor,
    '--gs-highlight': highlightColor,
    '--gs-text': textColor,
    '--gs-radius': `${radius}px`,
    '--gs-inner-radius': `${Math.max(3, radius - 4)}px`,
    '--gs-chip': `${S.chip}px`,
    '--gs-row': `${S.row}px`,
    '--gs-font': `${S.font}px`,
    '--gs-menu-w': `${menuWidth}px`,
    '--gs-pop': `${popDuration}ms`,
    '--gs-pop-out': `${popOut}ms`,
    '--gs-glide': `${glideDuration}ms`,
    '--gs-origin': origin,
    '--gs-ease-out': 'cubic-bezier(0.23, 1, 0.32, 1)',
  } as CSSProperties;
  return (
    <div
      ref={rootRef}
      className={`glide-select${className ? ` ${className}` : ''}`}
      data-size={size}
      data-disabled={disabled ? '' : undefined}
      style={variables}
      onAnimationEnd={(e) => {
        if (e.animationName === 'gs-swap' && rootRef.current) delete rootRef.current.dataset.swap;
      }}
    >
      <button
        ref={triggerRef}
        type="button"
        role="combobox"
        aria-haspopup="listbox"
        aria-expanded={phase === 'open'}
        aria-controls={`${id}-list`}
        aria-activedescendant={active !== null ? `${id}-${active}` : undefined}
        aria-label={
          includeValueInLabel && selected >= 0
            ? `${ariaLabel} ${textOf(items[selected])}`
            : ariaLabel
        }
        disabled={disabled || !items.length}
        className="glide-select__trigger"
        onClick={(e) => {
          if (disabled) return;
          e.currentTarget.focus({ preventScroll: true });
          if (phase === 'open') close('pop');
          else open(false);
        }}
        onKeyDown={onTriggerKey}
      >
        <span
          className="glide-select__label"
          key={current}
          data-empty={selected < 0 ? '' : undefined}
        >
          {selected >= 0 ? items[selected].label : placeholder}
        </span>
        <span className="glide-select__chevron" aria-hidden="true">
          <ChevronDown size={13} strokeWidth={2} />
        </span>
      </button>
      {phase !== 'closed' && host
        ? createPortal(
            <div
              ref={menuRef}
              style={{ ...variables, ...position }}
              className="glide-select__menu"
              data-state="open"
              data-side={side}
              data-align={align}
            >
              <div
                id={`${id}-list`}
                role="listbox"
                tabIndex={-1}
                aria-activedescendant={active !== null ? `${id}-${active}` : undefined}
                onKeyDown={onTriggerKey}
                aria-label={ariaLabel}
                className="glide-select__list"
                data-live={active !== null ? '' : undefined}
                onPointerOver={onListOver}
                onPointerLeave={() => {
                  if (!rememberPosition) setActive(null);
                }}
              >
                <span ref={pillRef} className="glide-select__pill" aria-hidden="true" />
                {items.map((it, i) => (
                  <div
                    key={it.value}
                    id={`${id}-${i}`}
                    role="option"
                    aria-selected={i === selected}
                    data-index={i}
                    data-active={i === active ? 'true' : undefined}
                    onClick={() => pick(i, false)}
                    className="glide-select__option"
                  >
                    <span className="glide-select__name">{it.label}</span>
                    {showTags && it.tag ? (
                      <span className="glide-select__tag">{it.tag}</span>
                    ) : null}
                    <span
                      className="glide-select__check"
                      data-on={i === selected ? '' : undefined}
                      aria-hidden="true"
                    >
                      <Check size={13} strokeWidth={2} />
                    </span>
                  </div>
                ))}
              </div>
            </div>,
            host,
          )
        : null}
    </div>
  );
};

export default GlideSelect;
