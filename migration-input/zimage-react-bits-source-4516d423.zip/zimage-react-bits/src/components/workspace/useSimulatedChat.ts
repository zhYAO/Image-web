'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { usePreviewSessions } from '@/components/AppProvider';

export const SIMULATED_STEPS = [
  { id: 'brief', label: '整理创作方向', description: '演示步骤：提取输入中的主题与表达目标。' },
  {
    id: 'structure',
    label: '组织建议结构',
    description: '演示步骤：按主体、环境、光线与构图组织建议。',
  },
  {
    id: 'answer',
    label: '准备示例回复',
    description: '演示步骤：展示预设文案，不代表模型的真实思考。',
  },
];

export function simulatedAnswer(prompt: string) {
  const subject = prompt.replace(/\s+/g, ' ').slice(0, 72);
  return `围绕「${subject}」，可以先明确画面的主体与希望传达的情绪，再逐步补充环境和视觉细节。\n\n建议把创意分成四部分：主体是什么、场景在哪里、采用怎样的光线，以及希望使用的构图。先保留一个清晰的视觉重点，再用少量细节建立氛围。\n\n示例提示词结构：主体描述 + 场景与背景 + 柔和光线 + 简洁构图 + 色彩风格。你可以据此调整自己的描述。\n\n以上是本地预设的模拟回复，仅用于体验对话流程；没有调用 AI 模型，也没有生成图片。`;
}

type Run = {
  sessionId: string;
  messageId: string;
  answer: string;
  step: number;
  status: 'thinking' | 'typing';
  partial: string;
};

export function useSimulatedChat() {
  const { activeSessionId, appendMessage, updateMessage } = usePreviewSessions();
  const [run, setRun] = useState<Run | null>(null);
  const current = useRef<Run | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cancelTimer = useCallback(() => {
    if (timer.current !== null) clearTimeout(timer.current);
    timer.current = null;
  }, []);
  const finish = useCallback(
    (status: 'done' | 'stopped', render = true) => {
      const task = current.current;
      if (!task) return;
      cancelTimer();
      current.current = null;
      updateMessage(task.sessionId, task.messageId, {
        text: status === 'done' ? task.answer : task.partial,
        simulation: { status, step: task.step },
      });
      if (render) setRun(null);
    },
    [cancelTimer, updateMessage],
  );
  const start = useCallback(
    (sessionId: string, prompt: string) => {
      if (current.current) return false;
      const task: Run = {
        sessionId,
        messageId: `simulated-${crypto.randomUUID()}`,
        answer: simulatedAnswer(prompt),
        step: 0,
        status: 'thinking',
        partial: '',
      };
      current.current = task;
      appendMessage(sessionId, {
        id: task.messageId,
        role: 'assistant',
        text: '',
        simulation: { status: 'thinking', step: 0 },
      });
      setRun({ ...task });
      const advance = () => {
        if (current.current !== task) return;
        task.step += 1;
        if (task.step === SIMULATED_STEPS.length) task.status = 'typing';
        updateMessage(task.sessionId, task.messageId, {
          simulation: { status: task.status, step: task.step },
        });
        setRun({ ...task });
        if (task.status === 'thinking') timer.current = setTimeout(advance, 700);
        else timer.current = null;
      };
      timer.current = setTimeout(advance, 700);
      return true;
    },
    [appendMessage, updateMessage],
  );
  const onTextChange = useCallback((partial: string) => {
    if (current.current) current.current.partial = partial;
  }, []);
  const complete = useCallback(() => finish('done'), [finish]);
  const stop = useCallback(() => finish('stopped'), [finish]);
  useEffect(() => {
    if (current.current && current.current.sessionId !== activeSessionId) stop();
  }, [activeSessionId, stop]);
  useEffect(() => () => finish('stopped', false), [finish]);
  return { run, start, stop, complete, onTextChange, isRunning: () => current.current !== null };
}
