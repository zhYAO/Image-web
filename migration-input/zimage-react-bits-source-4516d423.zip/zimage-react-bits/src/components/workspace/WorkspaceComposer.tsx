'use client';

import dynamic from 'next/dynamic';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowUp, ChevronDown, ImagePlus, Plus, SlidersHorizontal, Square, X } from 'lucide-react';
import { Glass } from '@/components/Glass';
import { ModelSelector } from '@/components/models/ModelSelector';
import { usePreviewComposer, usePreviewNotify } from '@/components/AppProvider';
import { ratios } from '@/lib/demo-data';
import { AnchoredPopover } from './AnchoredPopover';
import { ComposerOrbs } from './ComposerOrbs';
import styles from './workspace.module.css';

const ReferenceViewer = dynamic(() => import('./ReferenceViewer'), { ssr: false });

export function WorkspaceComposer({
  onRecord,
  busy = false,
  onStop,
}: {
  onRecord: (text: string, imageMode: boolean) => boolean | void;
  busy?: boolean;
  onStop?: () => void;
}) {
  const {
    mode,
    setMode,
    chatDraft,
    setChatDraft,
    imageDraft,
    setImageDraft,
    chatModel,
    setChatModel,
    imageModel,
    setImageModel,
    references,
    addReferences,
    removeReference,
  } = usePreviewComposer();
  const notify = usePreviewNotify();
  const imageMode = mode === 'image';
  const draft = imageMode ? imageDraft : chatDraft;
  const [ratio, setRatio] = useState('1:1');
  const [focused, setFocused] = useState(false);
  const [paramsAnchor, setParamsAnchor] = useState<HTMLElement | null>(null);
  const [viewing, setViewing] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const dock = useRef<HTMLDivElement>(null);
  const viewingReference = references.find((reference) => reference.id === viewing);
  useEffect(() => {
    const textarea = input.current;
    if (!textarea) return;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 145)}px`;
  }, [draft, imageMode, references.length]);
  useEffect(() => {
    const element = dock.current;
    const shell = element?.closest<HTMLElement>('[data-workspace-shell]');
    if (!element || !shell) return;
    const measure = () =>
      shell.style.setProperty('--composer-obstruction', `${element.offsetHeight + 80}px`);
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    measure();
    return () => {
      observer.disconnect();
      shell.style.removeProperty('--composer-obstruction');
    };
  }, []);
  function submit(event: FormEvent) {
    event.preventDefault();
    if (!draft.trim() || busy) return;
    setParamsAnchor(null);
    if (onRecord(draft.trim(), imageMode) === false) return;
    (imageMode ? setImageDraft : setChatDraft)('');
    if (imageMode) notify('消息已加入当前会话。图片生成服务暂不可用。');
  }
  return (
    <>
      <div className={styles.composerDock} ref={dock}>
        <Glass
          as="form"
          className={`${styles.composer} ${imageMode ? styles.imageMode : ''}`}
          onSubmit={submit}
        >
          <ComposerOrbs focused={focused} />
          <div className={styles.composerInputRow}>
            {imageMode && (
              <div className={styles.referenceStrip} aria-label="参考图">
                {!!references.length && (
                  <div className={styles.referenceItems}>
                    {references.map((reference) => (
                      <div className={styles.referenceItem} key={reference.id}>
                        <button
                          type="button"
                          aria-label={`查看参考图 ${reference.name}`}
                          onClick={() => setViewing(reference.id)}
                        >
                          <img src={reference.url} alt={`参考图 ${reference.name}`} />
                        </button>
                        <button
                          type="button"
                          className={styles.referenceRemove}
                          aria-label={`移除 ${reference.name}`}
                          onClick={() => removeReference(reference.id)}
                        >
                          <X />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                {references.length < 4 && (
                  <button
                    type="button"
                    className={styles.referenceAdd}
                    aria-label="添加参考图"
                    onClick={() => fileInput.current?.click()}
                  >
                    <Plus />
                    <span>参考图</span>
                  </button>
                )}
              </div>
            )}
            <input
              ref={fileInput}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              multiple
              aria-label="上传参考图"
              hidden
              onChange={(event) => {
                if (event.currentTarget.files) addReferences(event.currentTarget.files);
                event.currentTarget.value = '';
              }}
            />
            <label htmlFor="creation-prompt" className={styles.srOnly}>
              创作输入
            </label>
            <textarea
              ref={input}
              id="creation-prompt"
              rows={3}
              value={draft}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              placeholder={
                imageMode
                  ? '添加参考图，描述你想创作的画面…'
                  : '聊聊你的想法，或让 AI 帮你完善提示词…'
              }
              onChange={(event) => (imageMode ? setImageDraft : setChatDraft)(event.target.value)}
              onKeyDown={(event) => {
                if (
                  event.key === 'Enter' &&
                  !event.shiftKey &&
                  !event.nativeEvent.isComposing &&
                  event.keyCode !== 229
                ) {
                  event.preventDefault();
                  if (draft.trim()) event.currentTarget.form?.requestSubmit();
                }
              }}
            />
          </div>
          <div className={styles.composerBottom}>
            <div className={styles.composerTools}>
              {imageMode ? (
                <ModelSelector
                  capability="image"
                  value={imageModel}
                  onChange={setImageModel}
                  className={styles.modelSelector}
                  placement="top"
                  disabled={busy}
                />
              ) : (
                <ModelSelector
                  capability="chat"
                  value={chatModel}
                  onChange={setChatModel}
                  className={styles.modelSelector}
                  placement="top"
                  disabled={busy}
                />
              )}
              <button
                type="button"
                className={`${styles.toolButton} ${styles.imageToggle}`}
                aria-label="创建图片"
                aria-pressed={imageMode}
                onClick={() => {
                  setParamsAnchor(null);
                  setMode(imageMode ? 'chat' : 'image');
                  input.current?.focus({ preventScroll: true });
                }}
              >
                <ImagePlus />
                <span>创建图片</span>
              </button>
              {imageMode && (
                <button
                  type="button"
                  className={styles.toolButton}
                  aria-label={`生成参数 ${ratio} 2K`}
                  aria-haspopup="dialog"
                  aria-expanded={!!paramsAnchor}
                  onClick={(event) => setParamsAnchor(paramsAnchor ? null : event.currentTarget)}
                >
                  <SlidersHorizontal />
                  <span>
                    2K <span className={styles.parameterDivider}>/</span> {ratio}
                  </span>
                  <ChevronDown className={styles.chevron} />
                </button>
              )}
            </div>
            {busy ? (
              <button
                className={styles.submitButton}
                type="button"
                aria-label="停止模拟回复"
                onClick={(event) => {
                  // React reuses this DOM button as type=submit after stopping.
                  // Cancel this click's default action before that synchronous change.
                  event.preventDefault();
                  // The send button becomes stop in place. Ignore the continuation
                  // of a pointer multi-click, not a fresh click or keyboard activation.
                  if (event.detail <= 1) onStop?.();
                }}
              >
                <Square size={16} fill="currentColor" />
              </button>
            ) : (
              <button
                className={styles.submitButton}
                type="submit"
                aria-label="发送创作请求"
                disabled={!draft.trim()}
                onClick={(event) => {
                  // Likewise, a second stop click must not send the queued draft.
                  if (event.detail > 1) event.preventDefault();
                }}
              >
                <ArrowUp />
              </button>
            )}
          </div>
          <p className={styles.modelNotice}>模型选择仅保留在本地，未连接服务</p>
        </Glass>
      </div>
      {paramsAnchor && (
        <AnchoredPopover
          anchor={paramsAnchor}
          label="生成参数"
          width={345}
          onClose={() => setParamsAnchor(null)}
        >
          <div className={styles.parameterPanel}>
            <button
              className={`${styles.iconButton} ${styles.popoverClose}`}
              aria-label="关闭生成参数"
              onClick={() => {
                setParamsAnchor(null);
                paramsAnchor.focus();
              }}
            >
              <X />
            </button>
            <p className={styles.optionLabel}>选择比例</p>
            <div className={styles.ratioOptions}>
              {ratios.map((value) => {
                const [width, height] = value.split(':').map(Number);
                return (
                  <button
                    type="button"
                    key={value}
                    aria-label={`比例 ${value}`}
                    aria-pressed={ratio === value}
                    onClick={() => setRatio(value)}
                  >
                    <span
                      className={styles.ratioGlyph}
                      style={{
                        width: Math.round((20 * width) / Math.max(width, height)),
                        height: Math.round((20 * height) / Math.max(width, height)),
                      }}
                    />
                    {value}
                  </button>
                );
              })}
            </div>
            <p className={styles.optionLabel}>选择分辨率</p>
            <button
              className={styles.resolutionOption}
              type="button"
              aria-label="分辨率 2K"
              aria-pressed
            >
              高清 2K
            </button>
          </div>
        </AnchoredPopover>
      )}
      {viewingReference && (
        <ReferenceViewer
          url={viewingReference.url}
          name={viewingReference.name}
          onClose={() => setViewing(null)}
        />
      )}
    </>
  );
}
