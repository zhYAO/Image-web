'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import dynamic from 'next/dynamic';
import FadeContent from '@/components/react-bits/FadeContent';
import { ThoughtLine, LatticeLoader, ShinyText, TextType } from '@/components/react-bits/chat';
import { useSimulatedChat, SIMULATED_STEPS } from './useSimulatedChat';
import { UserRound } from 'lucide-react';
import { usePreviewSessions } from '@/components/AppProvider';
import { WorkspaceShell } from './WorkspaceShell';
import { WorkspaceComposer } from './WorkspaceComposer';
import { SceneCarousel } from './SceneCarousel';
import { WorkspaceMark } from './WorkspaceMark';
import styles from './workspace.module.css';

const ImagePreviewDialog = dynamic(() => import('@/components/ImagePreviewDialog'), { ssr: false });

function MessageReveal({
  id,
  eligible,
  seen,
  children,
}: {
  id: string;
  eligible: boolean;
  seen: Set<string>;
  children: ReactNode;
}) {
  const [reveal] = useState(() => eligible && !seen.has(id));
  useEffect(() => {
    seen.add(id);
  }, [id, seen]);
  return (
    <FadeContent duration={reveal ? 260 : 0} distance={8}>
      {children}
    </FadeContent>
  );
}

export function WorkspacePage() {
  const { sessions, activeSessionId, createSession, renameSession, appendMessage } =
    usePreviewSessions();
  const simulation = useSimulatedChat();
  const [seenEntries] = useState(
    () =>
      new Set(
        sessions.flatMap((session) =>
          session.messages.map((message, index) => message.id || `${session.id}-${index}`),
        ),
      ),
  );
  const followBottom = useRef(true);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [leaving, setLeaving] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const timeline = useRef<HTMLElement>(null);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );
  const session = sessions.find((item) => item.id === activeSessionId);
  const sessionId = session?.id;
  const messageCount = session?.messages.length || 0;
  useEffect(() => {
    const onScroll = () => {
      followBottom.current =
        document.documentElement.scrollHeight - window.scrollY - window.innerHeight < 160;
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  useEffect(() => {
    const node = timeline.current;
    if (!node) return;
    const observer = new ResizeObserver(() => {
      if (followBottom.current)
        node.lastElementChild?.scrollIntoView({ block: 'end', behavior: 'instant' });
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, [sessionId, leaving]);
  useEffect(() => {
    if (followBottom.current && sessionId && messageCount > 0 && !leaving)
      timeline.current?.lastElementChild?.scrollIntoView({
        block: 'end',
        behavior: window.matchMedia('(prefers-reduced-motion:reduce)').matches
          ? 'instant'
          : 'smooth',
      });
  }, [sessionId, messageCount, leaving]);
  function record(text: string, imageMode: boolean) {
    if (simulation.isRunning()) return false;
    followBottom.current = true;
    let id = activeSessionId;
    if (!id) {
      if (!window.matchMedia('(prefers-reduced-motion:reduce)').matches) {
        setLeaving(true);
        timer.current = setTimeout(() => setLeaving(false), 190);
      }
      id = createSession();
      renameSession(id, text.slice(0, 28));
    }
    appendMessage(id, { id: `local-user-${crypto.randomUUID()}`, role: 'user', text });
    if (!imageMode) simulation.start(id, text);
    return true;
  }
  return (
    <WorkspaceShell title={session?.title || '开启创作'} active="workspace">
      <div className={`${styles.mainContent} ${session && !leaving ? styles.isChat : ''}`}>
        {session && !leaving ? (
          <section
            ref={timeline}
            key={session.id}
            className={styles.timeline}
            role="log"
            aria-live="off"
            aria-label="对话时间线"
          >
            {session.messages.map((message, index) => (
              <div
                key={message.id || `${session.id}-${index}`}
                className={message.role === 'user' ? styles.userEntry : styles.assistantEntry}
              >
                {message.role === 'user' ? (
                  <MessageReveal
                    id={message.id || `${session.id}-${index}`}
                    eligible={!!message.simulation || !!message.id?.startsWith('local-user-')}
                    seen={seenEntries}
                  >
                    <article className={`${styles.message} ${styles.userMessage}`}>
                      <span className={styles.messageAvatar}>
                        <UserRound />
                      </span>
                      <div className={styles.messageBubble}>
                        {message.text}
                        {message.image && (
                          <button
                            type="button"
                            className={styles.messageImageButton}
                            aria-label="查看创作图片"
                            onClick={() => setPreviewImage(message.image!)}
                          >
                            <img src={message.image} alt="创作图片" />
                          </button>
                        )}
                      </div>
                    </article>
                  </MessageReveal>
                ) : (
                  <MessageReveal
                    id={message.id || `${session.id}-${index}`}
                    eligible={!!message.simulation || !!message.id?.startsWith('local-user-')}
                    seen={seenEntries}
                  >
                    <article className={styles.message}>
                      <span className={styles.messageAvatar}>
                        <WorkspaceMark />
                      </span>
                      <div
                        className={`${styles.messageBubble} ${message.simulation ? styles.simulatedBubble : ''}`}
                      >
                        {message.simulation && (
                          <>
                            <div className={styles.simulationLabel}>
                              模拟 AI · 本地演示，未连接模型
                            </div>
                            <ThoughtLine
                              working={message.simulation.status === 'thinking'}
                              title="思考步骤 · 模拟演示"
                              steps={SIMULATED_STEPS.map((step, stepIndex) => ({
                                ...step,
                                status:
                                  stepIndex < message.simulation!.step
                                    ? 'done'
                                    : stepIndex === message.simulation!.step &&
                                        message.simulation!.status === 'thinking'
                                      ? 'active'
                                      : 'pending',
                              }))}
                            />
                          </>
                        )}
                        {message.simulation?.status === 'thinking' ? (
                          <div className={styles.thinkingStatus} aria-hidden="true">
                            <LatticeLoader state="working" />
                            <ShinyText text="正在整理示例回复…" />
                          </div>
                        ) : message.simulation?.status === 'typing' &&
                          simulation.run &&
                          simulation.run.messageId === message.id ? (
                          <TextType
                            text={simulation.run.answer}
                            typingSpeed={18}
                            loop={false}
                            onTextChange={simulation.onTextChange}
                            onComplete={simulation.complete}
                            className={styles.answerText}
                          />
                        ) : (
                          <div className={styles.answerText}>{message.text}</div>
                        )}
                        {message.simulation?.status === 'stopped' && (
                          <p className={styles.stoppedLabel}>
                            已停止模拟回复{!message.text && '，尚未输出正文。'}
                          </p>
                        )}
                        {message.image && (
                          <button
                            type="button"
                            className={styles.messageImageButton}
                            aria-label="查看创作图片"
                            onClick={() => setPreviewImage(message.image!)}
                          >
                            <img src={message.image} alt="创作图片" />
                          </button>
                        )}
                      </div>
                    </article>
                  </MessageReveal>
                )}
              </div>
            ))}
          </section>
        ) : (
          <section
            className={`${styles.welcome} ${leaving ? styles.welcomeLeaving : ''}`}
            aria-labelledby="welcome-title"
          >
            <div className={styles.hero}>
              <div className={styles.heroMark}>
                <WorkspaceMark />
              </div>
              <h1 id="welcome-title">你好，想创作什么？</h1>
            </div>
            <SceneCarousel />
          </section>
        )}
      </div>
      <div
        role={session?.messages.at(-1)?.simulation ? 'status' : undefined}
        aria-live="polite"
        aria-atomic="true"
        className={styles.srOnly}
      >
        {simulation.run?.status === 'thinking'
          ? '正在演示思考步骤，未调用真实模型。'
          : simulation.run?.status === 'typing'
            ? '正在显示模拟回复。'
            : session?.messages.at(-1)?.simulation?.status === 'stopped'
              ? '模拟回复已停止。'
              : session?.messages.at(-1)?.simulation?.status === 'done'
                ? '模拟回复已完成。'
                : ''}
      </div>
      <WorkspaceComposer onRecord={record} busy={!!simulation.run} onStop={simulation.stop} />
      {previewImage && (
        <ImagePreviewDialog
          image={{ src: previewImage, alt: '创作图片' }}
          onClose={() => setPreviewImage(null)}
        />
      )}
    </WorkspaceShell>
  );
}
