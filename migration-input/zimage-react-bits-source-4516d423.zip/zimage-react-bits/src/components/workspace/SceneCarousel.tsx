'use client';

import { IntentLink } from '@/components/IntentLink';
import {
  memo,
  useCallback,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type PointerEvent,
} from 'react';
import { ArrowLeft, ArrowRight, ArrowUpRight } from 'lucide-react';
import { Glass } from '@/components/Glass';
import { scenes } from '@/lib/demo-data';
import styles from './workspace.module.css';

type Gesture = { id: number; x: number; y: number; dx: number; locked: boolean; vertical: boolean };

export const SceneCarousel = memo(function SceneCarousel() {
  const [size, setSize] = useState(3);
  const [index, setIndex] = useState(0);
  const [drag, setDrag] = useState(0);
  const [hover, setHover] = useState(false);
  const [focused, setFocused] = useState(false);
  const [visible, setVisible] = useState(true);
  const [inViewport, setInViewport] = useState(false);
  const [reduced, setReduced] = useState(true);
  const [dragging, setDragging] = useState(false);
  const gesture = useRef<Gesture | null>(null);
  const viewport = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLAnchorElement | null)[]>([]);
  const suppressClick = useRef(false);
  const wheel = useRef({ distance: 0, at: 0, changed: 0 });
  const last = Math.max(0, scenes.length - size);
  const move = useCallback(
    (target: number) => {
      const next = Math.max(0, Math.min(last, target));
      const focusedCard = cardRefs.current.findIndex((card) => card === document.activeElement);
      setIndex(next);
      setDrag(0);
      if (focusedCard >= 0 && (focusedCard < next || focusedCard >= next + size))
        cardRefs.current[next]?.focus({ preventScroll: true });
    },
    [last, size],
  );
  useEffect(() => {
    const compact = window.matchMedia('(max-width:767px)');
    const reduce = window.matchMedia('(prefers-reduced-motion:reduce)');
    const resize = () => {
      const count = compact.matches ? 1 : 3;
      setSize(count);
      setIndex((current) => Math.min(current, scenes.length - count));
    };
    const motion = () => setReduced(reduce.matches);
    const visibility = () => setVisible(!document.hidden);
    resize();
    motion();
    visibility();
    compact.addEventListener('change', resize);
    reduce.addEventListener('change', motion);
    document.addEventListener('visibilitychange', visibility);
    return () => {
      compact.removeEventListener('change', resize);
      reduce.removeEventListener('change', motion);
      document.removeEventListener('visibilitychange', visibility);
    };
  }, []);
  useEffect(() => {
    if (!viewport.current) return;
    if (typeof IntersectionObserver === 'undefined') {
      setInViewport(true);
      return;
    }
    const observer = new IntersectionObserver(([entry]) => setInViewport(entry.isIntersecting), {
      threshold: 0.1,
    });
    observer.observe(viewport.current);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (reduced || hover || focused || !visible || !inViewport || dragging) return;
    const timer = setTimeout(() => move(index === last ? 0 : index + size), 6000);
    return () => clearTimeout(timer);
  }, [reduced, hover, focused, visible, inViewport, dragging, index, last, size, move]);
  useEffect(() => {
    const element = viewport.current;
    if (!element) return;
    function scroll(event: WheelEvent) {
      if (Math.abs(event.deltaX) <= Math.abs(event.deltaY)) return;
      event.preventDefault();
      const now = Date.now();
      const state = wheel.current;
      if (now - state.changed < 400) return;
      if (now - state.at > 180) state.distance = 0;
      state.at = now;
      state.distance += event.deltaX;
      if (Math.abs(state.distance) > 60) {
        move(index + (state.distance > 0 ? size : -size));
        wheel.current = { distance: 0, at: now, changed: now };
      }
    }
    element.addEventListener('wheel', scroll, { passive: false });
    return () => element.removeEventListener('wheel', scroll);
  }, [index, size, move]);
  function finish(event: PointerEvent<HTMLDivElement>, cancel = false) {
    const current = gesture.current;
    if (!current || current.id !== event.pointerId) return;
    gesture.current = null;
    suppressClick.current = current.locked;
    setDragging(false);
    setDrag(0);
    if (event.currentTarget.hasPointerCapture(current.id))
      event.currentTarget.releasePointerCapture(current.id);
    if (!cancel && current.locked && Math.abs(current.dx) > 45)
      move(index + (current.dx < 0 ? size : -size));
  }
  return (
    <section
      className={styles.carousel}
      tabIndex={0}
      aria-label="电商生图"
      aria-roledescription="轮播"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onFocus={() => setFocused(true)}
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) setFocused(false);
      }}
      onKeyDown={(event) => {
        const target: Record<string, number> = {
          ArrowLeft: index - size,
          ArrowRight: index + size,
          Home: 0,
          End: last,
        };
        if (target[event.key] !== undefined) {
          event.preventDefault();
          move(target[event.key]);
        }
      }}
    >
      <div className={styles.carouselHeading}>
        <h2>电商生图</h2>
        <div className={styles.carouselControls}>
          <button
            className={styles.carouselArrow}
            aria-label="上一组创作场景"
            disabled={index === 0}
            onClick={() => move(index - size)}
          >
            <ArrowLeft />
          </button>
          <button
            className={styles.carouselArrow}
            aria-label="下一组创作场景"
            disabled={index === last}
            onClick={() => move(index + size)}
          >
            <ArrowRight />
          </button>
        </div>
      </div>
      <div
        ref={viewport}
        className={styles.carouselViewport}
        onPointerDown={(event) => {
          if (event.button !== 0 || gesture.current) return;
          suppressClick.current = false;
          gesture.current = {
            id: event.pointerId,
            x: event.clientX,
            y: event.clientY,
            dx: 0,
            locked: false,
            vertical: false,
          };
          setDragging(true);
        }}
        onPointerMove={(event) => {
          const current = gesture.current;
          if (!current || current.id !== event.pointerId) return;
          if (event.pointerType === 'mouse' && event.buttons === 0) {
            finish(event, true);
            return;
          }
          if (current.vertical) return;
          const dx = event.clientX - current.x;
          const dy = event.clientY - current.y;
          if (!current.locked) {
            if (Math.abs(dy) > 8 && Math.abs(dy) >= Math.abs(dx)) {
              current.vertical = true;
              return;
            }
            if (Math.abs(dx) < 8 || Math.abs(dx) <= Math.abs(dy)) return;
            current.locked = true;
            event.currentTarget.setPointerCapture(event.pointerId);
          }
          event.preventDefault();
          current.dx = dx;
          setDrag((index === 0 && dx > 0) || (index === last && dx < 0) ? dx * 0.18 : dx);
        }}
        onPointerUp={(event) => finish(event)}
        onPointerCancel={(event) => finish(event, true)}
        onLostPointerCapture={(event) => finish(event, true)}
        onPointerLeave={(event) => {
          if (!gesture.current?.locked) finish(event, true);
        }}
        onClickCapture={(event) => {
          if (suppressClick.current && event.detail > 0) {
            event.preventDefault();
            event.stopPropagation();
            suppressClick.current = false;
          }
        }}
      >
        <div
          className={styles.carouselTrack}
          data-dragging={drag !== 0}
          style={{ '--index': index, '--drag': `${drag}px` } as CSSProperties}
        >
          {scenes.map((scene, position) => (
            <IntentLink
              key={scene.id}
              ref={(element) => {
                cardRefs.current[position] = element;
              }}
              href={`/create/${scene.id}`}
              className={styles.sceneCard}
              aria-label={scene.name}
              draggable={false}
              aria-hidden={position < index || position >= index + size}
              inert={position < index || position >= index + size}
              tabIndex={position >= index && position < index + size ? 0 : -1}
            >
              <div className={styles.sceneCover}>
                <img
                  src={scene.image}
                  alt={scene.name}
                  width={512}
                  height={320}
                  loading={position < 3 ? 'eager' : 'lazy'}
                  decoding="async"
                  draggable={false}
                />
                <Glass as="span" className={styles.sceneTag}>
                  {scene.tag}
                </Glass>
              </div>
              <div className={styles.sceneCaption}>
                <span>{scene.name}</span>
                <ArrowUpRight />
              </div>
              <p>{scene.description}</p>
            </IntentLink>
          ))}
        </div>
      </div>
      <span className={styles.srOnly} aria-live={focused ? 'polite' : 'off'}>
        {scenes
          .slice(index, index + size)
          .map((scene) => scene.name)
          .join('、')}
      </span>
    </section>
  );
});
