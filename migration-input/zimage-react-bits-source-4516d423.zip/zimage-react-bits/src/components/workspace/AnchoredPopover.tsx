'use client';

import {
  useEffect,
  useEffectEvent,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import { createPortal } from 'react-dom';
import { Glass } from '@/components/Glass';
import styles from './workspace.module.css';

export function AnchoredPopover({
  anchor,
  label,
  children,
  onClose,
  className = '',
  width = 244,
}: {
  anchor: HTMLElement;
  label: string;
  children: ReactNode;
  onClose: () => void;
  className?: string;
  width?: number;
}) {
  const panel = useRef<HTMLDivElement>(null);
  const close = useEffectEvent(onClose);
  const [position, setPosition] = useState<CSSProperties>({ opacity: 0, width });
  useLayoutEffect(() => {
    function place() {
      const rect = anchor.getBoundingClientRect();
      const height = panel.current?.offsetHeight || 140;
      const actualWidth = Math.min(width, window.innerWidth - 24);
      const left = Math.max(
        12,
        Math.min(window.innerWidth - actualWidth - 12, rect.right - actualWidth + 14),
      );
      const top =
        rect.top - height - 12 >= 12
          ? rect.top - height - 12
          : Math.min(window.innerHeight - height - 12, rect.bottom + 12);
      setPosition({ width: actualWidth, left, top: Math.max(12, top), opacity: 1 });
    }
    place();
    const observer = new ResizeObserver(place);
    if (panel.current) observer.observe(panel.current);
    window.addEventListener('resize', place);
    window.addEventListener('scroll', place, true);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', place);
      window.removeEventListener('scroll', place, true);
    };
  }, [anchor, width]);
  useEffect(() => {
    const input = panel.current?.querySelector<HTMLInputElement>('input');
    (input || panel.current?.querySelector<HTMLElement>('button'))?.focus({ preventScroll: true });
    input?.select();
    function dismiss(event: PointerEvent) {
      if (!panel.current?.contains(event.target as Node) && !anchor.contains(event.target as Node))
        close();
    }
    function keyboard(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault();
        close();
        anchor.focus({ preventScroll: true });
      }
      if (event.key === 'Tab') {
        const items = Array.from(
          panel.current?.querySelectorAll<HTMLElement>(
            'button:not([disabled]),input,a[href],[tabindex="0"]',
          ) || [],
        );
        if (event.shiftKey && document.activeElement === items[0]) {
          event.preventDefault();
          items.at(-1)?.focus();
        } else if (!event.shiftKey && document.activeElement === items.at(-1)) {
          event.preventDefault();
          items[0]?.focus();
        }
      }
    }
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', keyboard);
    return () => {
      document.removeEventListener('pointerdown', dismiss);
      document.removeEventListener('keydown', keyboard);
    };
  }, [anchor]);
  return createPortal(
    <div
      ref={panel}
      className={`${styles.popoverPosition} ${className}`}
      style={position}
      role="dialog"
      aria-label={label}
    >
      <Glass className={styles.popover}>{children}</Glass>
    </div>,
    document.body,
  );
}
