'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import {
  Archive,
  ArrowUpRight,
  Coins,
  Filter,
  MessageSquare,
  PanelLeftClose,
  PanelLeftOpen,
  Pencil,
  Plus,
  ShoppingBag,
  Trash2,
  X,
} from 'lucide-react';
import { Glass } from '@/components/Glass';
import { usePreviewSessions, usePreviewNotify } from '@/components/AppProvider';
import { AnchoredPopover } from './AnchoredPopover';
import { CategoryFilters, categories, type Category } from './CategoryFilters';
import { WorkspaceMark } from './WorkspaceMark';
import styles from './workspace.module.css';

type Section = 'workspace' | 'create' | 'assets' | 'account';
type Edit = { id: string; action: 'rename' | 'delete'; title: string; anchor: HTMLElement };

export function WorkspaceShell({
  children,
  title = '开启创作',
  active = 'workspace',
}: {
  children: ReactNode;
  title?: string;
  active?: Section;
}) {
  const { sessions, activeSessionId, selectSession, renameSession, deleteSession } =
    usePreviewSessions();
  const notify = usePreviewNotify();
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [category, setCategory] = useState<Category>('all');
  const [edit, setEdit] = useState<Edit | null>(null);
  const [name, setName] = useState('');
  const [filterAnchor, setFilterAnchor] = useState<HTMLElement | null>(null);
  const [tooltip, setTooltip] = useState<{ text: string; left: number; top: number } | null>(null);
  const [credits, setCredits] = useState<HTMLElement | null>(null);
  const sidebar = useRef<HTMLElement>(null);
  const mobileTrigger = useRef<HTMLButtonElement>(null);
  const visibleSessions = sessions.filter(
    (session) => category === 'all' || session.category === category,
  );
  useEffect(() => {
    try {
      const saved = localStorage.getItem('zimage-sidebar-collapsed');
      // Read browser-only preferences after hydration so server and initial client markup match.
      // eslint-disable-next-line react-hooks/set-state-in-effect -- A one-time post-hydration preference sync is required for SSR-safe localStorage.
      setCollapsed(saved ? saved === 'true' : window.innerWidth >= 768 && window.innerWidth <= 900);
    } catch {
      /* Storage may be disabled. */
    }
  }, []);
  useEffect(() => {
    if (!mobile) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    sidebar.current?.querySelector<HTMLButtonElement>(`[aria-label="关闭会话"]`)?.focus();
    function keyboard(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setMobile(false);
        mobileTrigger.current?.focus();
      }
      if (event.key === 'Tab') {
        const focusable = Array.from(
          sidebar.current?.querySelectorAll<HTMLElement>(
            'button:not([disabled]),a[href],[tabindex="0"]',
          ) || [],
        ).filter((element) => element.getClientRects().length > 0);
        if (event.shiftKey && document.activeElement === focusable[0]) {
          event.preventDefault();
          focusable.at(-1)?.focus();
        } else if (!event.shiftKey && document.activeElement === focusable.at(-1)) {
          event.preventDefault();
          focusable[0]?.focus();
        }
      }
    }
    document.addEventListener('keydown', keyboard);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener('keydown', keyboard);
    };
  }, [mobile]);
  useEffect(() => {
    const dismissTooltip = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setTooltip(null);
    };
    document.addEventListener('keydown', dismissTooltip);
    return () => document.removeEventListener('keydown', dismissTooltip);
  }, []);
  useEffect(() => {
    const query = window.matchMedia('(min-width:768px)');
    function desktop() {
      if (query.matches) setMobile(false);
    }
    query.addEventListener('change', desktop);
    return () => query.removeEventListener('change', desktop);
  }, []);
  function closePanels() {
    setEdit(null);
    setFilterAnchor(null);
    setTooltip(null);
    setCredits(null);
  }
  function toggleCollapse() {
    closePanels();
    setCollapsed((value) => {
      try {
        localStorage.setItem('zimage-sidebar-collapsed', String(!value));
      } catch {
        /* Optional UI preference. */
      }
      return !value;
    });
  }
  function select(id: string | null) {
    closePanels();
    selectSession(id);
    setMobile(false);
    router.push('/workspace');
  }
  function showTooltip(element: HTMLElement) {
    if (!collapsed || mobile || window.innerWidth < 768 || edit || filterAnchor) return;
    const rect = element.getBoundingClientRect();
    const edge = sidebar.current?.getBoundingClientRect().right || rect.right;
    setTooltip({
      text: element.getAttribute('aria-label') || '',
      left: edge + 10,
      top: Math.min(window.innerHeight - 52, Math.max(12, rect.top + rect.height / 2 - 17)),
    });
  }
  const tip = {
    onMouseEnter: (event: React.MouseEvent<HTMLElement>) => showTooltip(event.currentTarget),
    onMouseLeave: () => setTooltip(null),
    onFocus: (event: React.FocusEvent<HTMLElement>) => showTooltip(event.currentTarget),
    onBlur: () => setTooltip(null),
    onPointerDown: () => setTooltip(null),
  };
  function startEdit(id: string, action: 'rename' | 'delete', title: string, anchor: HTMLElement) {
    setName(title);
    setEdit({ id, action, title, anchor });
    setFilterAnchor(null);
  }
  return (
    <div
      className={`${styles.workspace} ${collapsed ? styles.collapsed : ''}`}
      data-workspace-shell="true"
    >
      <a className={styles.skipLink} href="#workspace-main">
        跳到主要内容
      </a>
      {mobile && (
        <button
          className={styles.drawerShade}
          aria-label="关闭会话侧栏"
          onClick={() => {
            setMobile(false);
            mobileTrigger.current?.focus();
          }}
          tabIndex={-1}
        />
      )}
      <aside
        ref={sidebar}
        className={`${styles.sidebar} ${mobile ? styles.mobileOpen : ''}`}
        aria-label="会话侧栏"
        role={mobile ? 'dialog' : undefined}
        aria-modal={mobile || undefined}
      >
        <Glass className={styles.sidebarSurface}>
          <div className={styles.sidebarClip}>
            <div className={styles.sidebarTop}>
              <div className={styles.brandRow}>
                <Link
                  className={styles.brand}
                  href="/"
                  aria-label="ZImage 品牌首页"
                  tabIndex={collapsed && !mobile ? -1 : undefined}
                >
                  <WorkspaceMark />
                  <span>
                    <strong>ZImage</strong>
                    <small>灵感，让创作发生</small>
                  </span>
                </Link>
                <button
                  className={`${styles.iconButton} ${styles.collapse}`}
                  aria-label={collapsed ? '展开会话侧栏' : '折叠会话侧栏'}
                  aria-expanded={!collapsed}
                  onClick={toggleCollapse}
                  {...tip}
                >
                  {collapsed ? <PanelLeftOpen /> : <PanelLeftClose />}
                </button>
                <button
                  className={`${styles.iconButton} ${styles.mobileClose}`}
                  aria-label="关闭会话"
                  onClick={() => {
                    setMobile(false);
                    mobileTrigger.current?.focus();
                  }}
                >
                  <X />
                </button>
              </div>
              <button
                className={styles.newConversation}
                aria-label="新对话"
                onClick={() => select(null)}
                {...tip}
              >
                <Plus />
                <span className={styles.sidebarLabel}>新对话</span>
                <span className={`${styles.shortcut} ${styles.sidebarLabel}`} aria-hidden="true">
                  ＋
                </span>
              </button>
              <Link
                className={styles.commerceNav}
                href="/create"
                aria-label="电商生图"
                aria-current={active === 'create' ? 'page' : undefined}
                {...tip}
              >
                <ShoppingBag />
                <span className={styles.sidebarLabel}>电商生图</span>
                <ArrowUpRight className={`${styles.navArrow} ${styles.sidebarLabel}`} />
              </Link>
              <div className={styles.categoryWrap}>
                <CategoryFilters
                  value={category}
                  onChange={setCategory}
                  inert={collapsed && !mobile}
                />
                <button
                  className={`${styles.iconButton} ${styles.compactFilter}`}
                  aria-label="筛选会话"
                  aria-haspopup="dialog"
                  aria-expanded={!!filterAnchor}
                  tabIndex={collapsed ? 0 : -1}
                  onClick={(event) => setFilterAnchor(filterAnchor ? null : event.currentTarget)}
                  {...tip}
                >
                  <Filter />
                </button>
              </div>
              <div className={`${styles.sectionLabel} ${styles.sidebarLabel}`}>
                <span>最近会话</span>
                <span>{visibleSessions.length}</span>
              </div>
            </div>
            <div
              className={styles.sessionList}
              role="region"
              aria-label="会话列表"
              tabIndex={0}
              onScroll={() => setTooltip(null)}
            >
              {sessions.map((session) => (
                <div
                  key={session.id}
                  hidden={category !== 'all' && session.category !== category}
                  className={`${styles.sessionItem} ${active === 'workspace' && activeSessionId === session.id ? styles.activeSession : ''}`}
                >
                  <button
                    className={styles.sessionMain}
                    aria-label={session.title}
                    aria-current={
                      active === 'workspace' && activeSessionId === session.id ? 'page' : undefined
                    }
                    onClick={() => select(session.id)}
                    {...tip}
                  >
                    <span className={styles.sessionIcon}>
                      {session.category === 'commerce' ? <ShoppingBag /> : <MessageSquare />}
                    </span>
                    <span className={styles.sessionCopy}>
                      <span className={styles.sessionName}>{session.title}</span>
                      <span className={styles.sessionType}>
                        {session.category === 'commerce' ? '电商生图' : '普通创作'}
                      </span>
                    </span>
                  </button>
                  <div className={styles.sessionActions} inert={collapsed && !mobile}>
                    <button
                      className={styles.iconButton}
                      aria-label={`重命名 ${session.title}`}
                      aria-haspopup="dialog"
                      aria-expanded={edit?.id === session.id && edit.action === 'rename'}
                      onClick={(event) =>
                        startEdit(session.id, 'rename', session.title, event.currentTarget)
                      }
                    >
                      <Pencil />
                    </button>
                    <button
                      className={styles.iconButton}
                      aria-label={`删除 ${session.title}`}
                      aria-haspopup="dialog"
                      aria-expanded={edit?.id === session.id && edit.action === 'delete'}
                      onClick={(event) =>
                        startEdit(session.id, 'delete', session.title, event.currentTarget)
                      }
                    >
                      <Trash2 />
                    </button>
                  </div>
                </div>
              ))}
              {!visibleSessions.length && <p className={styles.emptySessions}>暂无此类会话</p>}
            </div>
          </div>
        </Glass>
      </aside>
      <main id="workspace-main" className={styles.main} tabIndex={-1} inert={mobile}>
        <Glass as="header" className={styles.topbar} refract>
          <div className={styles.topbarStart}>
            <button
              ref={mobileTrigger}
              className={`${styles.iconButton} ${styles.mobileMenu}`}
              aria-label="打开会话"
              aria-expanded={mobile}
              onClick={() => {
                closePanels();
                setMobile(true);
              }}
            >
              <PanelLeftOpen />
            </button>
            <span>{title}</span>
          </div>
          <nav className={styles.topbarNav} aria-label="工作台导航">
            <button
              className={styles.credits}
              aria-label="查看积分与模型价格"
              aria-haspopup="dialog"
              onClick={(event) => setCredits(credits ? null : event.currentTarget)}
            >
              <Coins />
              <span>积分</span>
            </button>
            <span className={styles.navDivider} />
            <Link href="/account" aria-current={active === 'account' ? 'page' : undefined}>
              账号
            </Link>
            <Link
              href="/assets"
              className={styles.libraryButton}
              aria-label="资产库"
              aria-current={active === 'assets' ? 'page' : undefined}
            >
              <Archive />
              <span>资产库</span>
            </Link>
          </nav>
        </Glass>
        <div className={styles.pageContent}>{children}</div>
      </main>
      {tooltip &&
        createPortal(
          <div
            role="tooltip"
            className={styles.tooltipPosition}
            style={{ left: tooltip.left, top: tooltip.top }}
          >
            <Glass className={styles.tooltip}>{tooltip.text}</Glass>
          </div>,
          document.body,
        )}
      {filterAnchor && (
        <AnchoredPopover
          anchor={filterAnchor}
          label="筛选会话"
          width={154}
          onClose={() => setFilterAnchor(null)}
        >
          <div className={styles.filterOptions}>
            {categories.map(([key, label]) => (
              <button
                key={key}
                aria-pressed={category === key}
                onClick={() => {
                  setCategory(key);
                  setFilterAnchor(null);
                  filterAnchor.focus();
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </AnchoredPopover>
      )}
      {edit && (
        <AnchoredPopover
          anchor={edit.anchor}
          label={edit.action === 'rename' ? '重命名' : '删除会话？'}
          onClose={() => setEdit(null)}
        >
          <form
            className={styles.sessionForm}
            onSubmit={(event) => {
              event.preventDefault();
              if (edit.action === 'rename') {
                if (!name.trim()) {
                  notify('请输入会话名称');
                  return;
                }
                renameSession(edit.id, name.trim());
              } else deleteSession(edit.id);
              setEdit(null);
              if (edit.anchor.isConnected) edit.anchor.focus();
            }}
          >
            <h2>{edit.action === 'rename' ? '重命名' : '删除会话？'}</h2>
            {edit.action === 'rename' ? (
              <>
                <label className={styles.srOnly} htmlFor="session-title-input">
                  会话名称
                </label>
                <input
                  id="session-title-input"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  maxLength={80}
                  autoComplete="off"
                />
              </>
            ) : (
              <p>删除后无法恢复</p>
            )}
            <div className={styles.modalActions}>
              <button
                className={styles.secondaryButton}
                type="button"
                onClick={() => {
                  setEdit(null);
                  edit.anchor.focus();
                }}
              >
                取消
              </button>
              <button
                className={`${styles.primaryButton} ${edit.action === 'delete' ? styles.danger : ''}`}
                type="submit"
              >
                {edit.action === 'rename' ? '保存' : '删除'}
              </button>
            </div>
          </form>
        </AnchoredPopover>
      )}
      {credits && (
        <AnchoredPopover
          anchor={credits}
          label="我的积分"
          width={300}
          onClose={() => setCredits(null)}
        >
          <div className={styles.creditPanel}>
            <h2>我的积分</h2>
            <div className={styles.creditGrid}>
              <div>
                <span>可用积分</span>
                <strong>—</strong>
              </div>
              <div>
                <span>冻结积分</span>
                <strong>—</strong>
              </div>
            </div>
            <p>登录后可查看积分余额与使用记录。</p>
            <Link href="/account">
              查看积分流水 <ArrowUpRight />
            </Link>
          </div>
        </AnchoredPopover>
      )}
    </div>
  );
}
