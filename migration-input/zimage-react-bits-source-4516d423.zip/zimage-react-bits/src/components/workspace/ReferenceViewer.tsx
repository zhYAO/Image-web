'use client';

import ImagePreviewDialog from '@/components/ImagePreviewDialog';

export default function ReferenceViewer({
  url,
  name,
  onClose,
}: {
  url: string;
  name: string;
  onClose: () => void;
}) {
  return (
    <ImagePreviewDialog
      image={{ src: url, alt: name, title: `参考图 ${name}` }}
      onClose={onClose}
    />
  );
}
