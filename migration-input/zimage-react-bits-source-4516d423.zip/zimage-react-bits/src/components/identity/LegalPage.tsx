import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { BrandMark } from '@/components/BrandMark';
import { Glass } from '@/components/Glass';

export default function LegalPage({ privacy = false }: { privacy?: boolean }) {
  return (
    <main className="zi-identity zi-legal">
      <nav className="zi-topline">
        <Link href="/" className="zi-brand">
          <BrandMark />
          ZImage
        </Link>
        <Link href="/login" className="zi-back">
          <ArrowLeft />
          返回登录
        </Link>
      </nav>
      <header>
        <span className="zi-eyebrow">未批准草案</span>
        <h1>{privacy ? '隐私政策' : '服务条款'}</h1>
        <p>服务条款与隐私政策正在完善中。</p>
      </header>
      <Glass as="article" className="zi-account-card">
        <span className="zi-eyebrow">未批准草案 · 不构成正式协议</span>
        <h2>{privacy ? '隐私政策草案' : '服务条款草案'}</h2>
        <p>服务条款与隐私政策正在完善中。</p>
        <p>
          {privacy
            ? '拟议范围：手机号账号资料、创作会话与生成资产；日志不得记录手机号、验证码、密码、令牌或完整提示词。切换正式账号时匿名内容会永久删除。'
            : '拟议范围：中国大陆公开 Beta，切换正式账号后匿名数据将无通知永久删除；账号注销会立即停止访问并进入后台清理。'}
        </p>
        <p>注册功能将在服务条款确认后开放。</p>
        <Link href="/login" className="zi-button zi-secondary">
          返回登录
        </Link>
      </Glass>
    </main>
  );
}
