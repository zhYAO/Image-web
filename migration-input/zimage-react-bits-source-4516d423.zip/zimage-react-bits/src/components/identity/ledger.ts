export type LedgerEntry = {
  id: string;
  time: string;
  purpose: string;
  type: string;
  amount: string;
};
export const LEDGER_PAGE_SIZE = 3;
export function ledgerPage(records: readonly LedgerEntry[], limit = LEDGER_PAGE_SIZE) {
  return { entries: records.slice(0, Math.max(0, limit)), hasMore: records.length > limit };
}
