'use client';
import { useState } from 'react';
import { Glass } from '@/components/Glass';
import { ledgerPage, LEDGER_PAGE_SIZE, type LedgerEntry } from './ledger';

/** Pagination is ready for supplied records; unavailable data never becomes a fabricated balance. */
export default function AccountLedger({
  records = null,
  onRetry,
}: {
  records?: readonly LedgerEntry[] | null;
  onRetry: () => void;
}) {
  const [limit, setLimit] = useState(LEDGER_PAGE_SIZE);
  const { entries, hasMore } = ledgerPage(records ?? [], limit);
  return (
    <Glass as="section" className="zi-account-card" aria-labelledby="zi-ledger-title">
      <div className="zi-card-heading">
        <h2 id="zi-ledger-title">积分流水</h2>
        <span>最近记录</span>
      </div>
      <div className="zi-table-wrap">
        <table className="zi-ledger">
          <caption className="sr-only">积分流水</caption>
          <thead>
            <tr>
              <th scope="col">时间 / 用途</th>
              <th scope="col">类型</th>
              <th scope="col">积分</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((entry) => (
              <tr key={entry.id}>
                <td>
                  <strong>{entry.purpose}</strong>
                  <small>{entry.time}</small>
                </td>
                <td>
                  <span className="zi-ledger-type">{entry.type}</span>
                </td>
                <td className={entry.amount.startsWith('+') ? 'zi-credit-return' : ''}>
                  {entry.amount}
                </td>
              </tr>
            ))}
            {!entries.length && (
              <tr>
                <td colSpan={3}>
                  {records === null ? '暂时无法读取积分流水。' : '暂无积分流水。'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {records === null ? (
        <button type="button" className="zi-button zi-secondary" onClick={onRetry}>
          重新加载
        </button>
      ) : hasMore ? (
        <button
          type="button"
          className="zi-button zi-secondary"
          onClick={() => setLimit((current) => current + LEDGER_PAGE_SIZE)}
        >
          加载更多
        </button>
      ) : (
        entries.length > 0 && (
          <p className="zi-local-note" role="status">
            已显示全部流水
          </p>
        )
      )}
    </Glass>
  );
}
