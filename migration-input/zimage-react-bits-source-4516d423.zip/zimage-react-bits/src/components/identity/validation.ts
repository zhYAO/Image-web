export type AuthMode = 'login' | 'register' | 'recovery' | 'verify' | 'reset';
export type PhoneValidationError = { field: 'phone' | 'code'; message: string };

export function validatePhone(phone: string): PhoneValidationError | null {
  if (!phone.trim()) return { field: 'phone', message: '请输入手机号。' };
  if (!/^1[3-9]\d{9}$/.test(phone.trim())) {
    return { field: 'phone', message: '请输入有效的中国大陆 11 位手机号。' };
  }
  return null;
}

export function validatePhoneLogin(phone: string, code: string): PhoneValidationError | null {
  const phoneError = validatePhone(phone);
  if (phoneError) return phoneError;
  if (!/^\d{6}$/.test(code)) return { field: 'code', message: '请输入 6 位数字验证码。' };
  return null;
}
