'use client';

import { usePathname } from 'next/navigation';
import AuthPage from './AuthPage';
import type { AuthMode } from './validation';

const modes: Record<string, AuthMode> = {
  '/login': 'login',
  '/auth': 'login',
  '/register': 'register',
  '/auth/register': 'register',
  '/forgot-password': 'recovery',
  '/auth/recovery': 'recovery',
  '/auth/verify': 'verify',
  '/auth/reset': 'reset',
};

// Owned by the shared layout, so links and browser history update only the form.
export default function AuthRoute() {
  const pathname = usePathname();
  const mode = modes[pathname.replace(/\/$/, '')] ?? 'login';
  return <AuthPage mode={mode} />;
}
