/** This boundary is deliberately frontend-only. It never returns a session or token. */
export type PhoneIdentity = { countryCode: '+86'; number: string };
export type PhoneCodeChallenge = { id: string; retryAfterSeconds: number };
export type PhoneCodeVerification = PhoneIdentity & { challengeId: string; code: string };
export type PhoneCodeResult = { kind: 'demo-verified' };
export type PhoneAuthOptions = { signal: AbortSignal };

/** Replace the adapter when integrating SMS; add real session handling separately. */
export interface PhoneAuthService {
  requestCode(phone: PhoneIdentity, options: PhoneAuthOptions): Promise<PhoneCodeChallenge>;
  verifyCode(input: PhoneCodeVerification, options: PhoneAuthOptions): Promise<PhoneCodeResult>;
}

export class PhoneAuthError extends Error {
  constructor(readonly code: 'invalid-phone' | 'invalid-code' | 'expired-challenge') {
    super(code);
    this.name = 'PhoneAuthError';
  }
}

export const DEMO_PHONE_CODE = '123456';

/** Local fixture only: no SMS, network, persistence, credentials or authentication. */
export const demoPhoneAuth: PhoneAuthService = {
  async requestCode(phone, { signal }) {
    signal.throwIfAborted();
    if (phone.countryCode !== '+86' || !/^1[3-9]\d{9}$/.test(phone.number)) {
      throw new PhoneAuthError('invalid-phone');
    }
    return { id: 'local-phone-demo', retryAfterSeconds: 60 };
  },
  async verifyCode(input, { signal }) {
    signal.throwIfAborted();
    if (input.countryCode !== '+86' || !/^1[3-9]\d{9}$/.test(input.number)) {
      throw new PhoneAuthError('invalid-phone');
    }
    if (input.challengeId !== 'local-phone-demo') {
      throw new PhoneAuthError('expired-challenge');
    }
    if (input.code !== DEMO_PHONE_CODE) throw new PhoneAuthError('invalid-code');
    return { kind: 'demo-verified' };
  },
};
