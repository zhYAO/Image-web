'use client';

import Link from 'next/link';
import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import { BrandMark } from '@/components/BrandMark';
import { Glass } from '@/components/Glass';
import FadeContent from '@/components/react-bits/FadeContent';
import type { AuthMode } from './validation';
import PhoneLoginForm from './PhoneLoginForm';
import type { PhoneAuthService } from './phone-auth';

const titles: Record<AuthMode, string> = {
  login: '登录',
  register: '创建账号',
  recovery: '找回密码',
  verify: '验证邮箱',
  reset: '设置新密码',
};
const descriptions: Record<AuthMode, string> = {
  login: '使用手机号与验证码，继续你的下一次创作。',
  register: '给你的下一次创作，一个新的开始。',
  recovery: '手机号验证码登录，无需找回密码。',
  verify: '旧版邮箱验证入口，当前不可用。',
  reset: '手机号验证码登录，无需设置密码。',
};

export default function AuthPage({
  mode = 'login',
  phoneAuth,
}: {
  mode?: AuthMode;
  phoneAuth?: PhoneAuthService;
}) {
  const screen = useRef<HTMLElement>(null);

  useEffect(() => {
    const viewport = window.visualViewport;
    const sync = () => {
      screen.current?.style.setProperty(
        '--zi-viewport-height',
        `${viewport?.height ?? window.innerHeight}px`,
      );
      screen.current?.style.setProperty('--zi-viewport-top', `${viewport?.offsetTop ?? 0}px`);
    };
    sync();
    viewport?.addEventListener('resize', sync);
    viewport?.addEventListener('scroll', sync);
    window.addEventListener('resize', sync);
    return () => {
      viewport?.removeEventListener('resize', sync);
      viewport?.removeEventListener('scroll', sync);
      window.removeEventListener('resize', sync);
    };
  }, []);

  return (
    <main ref={screen} className="zi-identity zi-auth-screen" aria-labelledby="zi-auth-title">
      <div className="zi-auth-layout">
        <aside className="zi-auth-visual" aria-label="ZImage 创作空间">
          <FadeContent className="zi-auth-story" distance={14} duration={700}>
            <span className="zi-eyebrow">IMAGINATION, IN FOCUS.</span>
            <h2>
              让每个灵感，
              <br />
              都有好画面。
            </h2>
            <p>
              从第一句想法，到下一张作品。
              <br />
              让创作，在这里自然发生。
            </p>
          </FadeContent>
          <div className="zi-auth-orbit" aria-hidden="true">
            <div className="zi-orbit-ring" />
            <div className="zi-orbit-ring zi-orbit-ring-second" />
            <Glass className="zi-glass-frame zi-glass-frame-back" />
            <Glass className="zi-glass-frame zi-glass-frame-front">
              <BrandMark />
            </Glass>
            <span className="zi-orbit-dot" />
          </div>
          <div className="zi-visual-foot">
            <span>ZIMAGE</span>
            <span>让想象，清晰可见。</span>
          </div>
        </aside>
        <div className="zi-auth-panel">
          <FadeContent className="zi-auth-reveal" distance={12} duration={600}>
            <Glass as="section" className="zi-auth-card" aria-labelledby="zi-auth-title">
              <div
                className="zi-auth-scroll"
                role="region"
                tabIndex={0}
                aria-label="登录与账号操作"
              >
                <Link href="/" className="zi-brand">
                  <BrandMark />
                  <span>ZImage</span>
                </Link>
                <div className="zi-auth-heading">
                  <span className="zi-eyebrow">YOUR NEXT CREATION</span>
                  <h1 id="zi-auth-title">{titles[mode]}</h1>
                  <p>{descriptions[mode]}</p>
                </div>
                {mode === 'login' ? (
                  <PhoneLoginForm key={mode} service={phoneAuth} />
                ) : (
                  <div className="zi-auth-form" key={mode}>
                    <p className="zi-register-note" role="status">
                      {mode === 'register'
                        ? '注册暂未开放，短信与账号服务未接入。服务条款与隐私政策仍为未批准草案，不会自动创建账号。'
                        : '旧版邮箱与密码服务未接入，此入口不再收集邮箱、密码或验证码。请使用手机号验证码登录入口。'}
                    </p>
                    <Link className="zi-button zi-primary zi-auth-submit" href="/login">
                      返回手机号登录
                    </Link>
                  </div>
                )}
                <nav className="zi-auth-tabs" aria-label="账号操作">
                  <Link href="/login" aria-current={mode === 'login' ? 'page' : undefined}>
                    手机号登录
                  </Link>
                  <Link href="/register" aria-current={mode === 'register' ? 'page' : undefined}>
                    注册说明
                  </Link>
                </nav>
                <p className="zi-auth-footnote">
                  <Link href="/create">先探索一下电商创作</Link>
                  <ArrowRight />
                </p>
                <footer className="zi-footer">
                  <Link href="/workspace" className="zi-back">
                    进入工作区
                    <ArrowRight />
                  </Link>
                  <nav aria-label="法律信息">
                    <Link href="/terms">服务条款</Link>
                    <Link href="/privacy">隐私政策</Link>
                  </nav>
                </footer>
              </div>
            </Glass>
          </FadeContent>
        </div>
      </div>
    </main>
  );
}
