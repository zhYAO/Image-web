'use client';

import Link from 'next/link';
import { useRef, useState, type FormEvent } from 'react';
import { ArrowLeft, ArrowRight, Archive, Coins, SlidersHorizontal, UserRound } from 'lucide-react';
import { Glass } from '@/components/Glass';
import { usePreviewNotify } from '@/components/AppProvider';
import { WorkspaceShell } from '@/components/workspace/WorkspaceShell';
import FadeContent from '@/components/react-bits/FadeContent';
import AccountLedger from './AccountLedger';

export default function AccountPage() {
  const notify = usePreviewNotify();
  const [name, setName] = useState('创作者');
  const [savedName, setSavedName] = useState('创作者');
  const nameInput = useRef<HTMLInputElement>(null);
  function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = name.trim();
    if (!normalized) {
      notify('请输入显示名称。');
      nameInput.current?.focus();
      return;
    }
    setName(normalized);
    setSavedName(normalized);
    notify('显示名称已更新，仅在本次访问中保留。');
  }
  return (
    <WorkspaceShell title="我的账户" active="account">
      <div className="zi-identity zi-account">
        <nav className="zi-topline" aria-label="账号导航">
          <Link href="/workspace" className="zi-back">
            <ArrowLeft />
            <span>返回工作区</span>
          </Link>
          <span className="zi-eyebrow">YOUR CREATIVE SPACE</span>
        </nav>
        <FadeContent distance={12} duration={600}>
          <header className="zi-account-hero">
            <div className="zi-account-identity">
              <div className="zi-profile-avatar">
                <UserRound />
              </div>
              <div>
                <span className="zi-eyebrow">我的账号</span>
                <h1>{savedName}</h1>
                <p>整理资料，专注下一次创作。</p>
              </div>
            </div>
            <nav className="zi-account-shortcuts" aria-label="创作快捷入口">
              <Link href="/assets" className="zi-button zi-secondary">
                <Archive />
                <span>资产库</span>
              </Link>
              <Link href="/workspace" className="zi-button zi-primary">
                <span>开始创作</span>
                <ArrowRight />
              </Link>
            </nav>
          </header>
        </FadeContent>
        <div className="zi-account-grid">
          <div className="zi-account-main">
            <FadeContent duration={650} delay={50}>
              <Glass as="section" className="zi-account-card" aria-labelledby="zi-credit-title">
                <div className="zi-card-heading">
                  <h2 id="zi-credit-title">我的积分</h2>
                  <span>创作消耗一目了然</span>
                </div>
                <div className="zi-credit-overview">
                  <div>
                    <span>可用积分</span>
                    <strong>
                      —<small>CREDITS</small>
                    </strong>
                  </div>
                  <div className="zi-credit-emblem" aria-hidden="true">
                    <Coins />
                  </div>
                </div>
                <div className="zi-balance-grid">
                  <div>
                    <span>冻结积分</span>
                    <strong>—</strong>
                  </div>
                  <div>
                    <span>累计消费</span>
                    <strong>—</strong>
                  </div>
                </div>
                <details className="zi-details">
                  <summary>模型价格与计费说明</summary>
                  <div className="zi-price-row">
                    <span>豆包 · 文字创作</span>
                    <span>价格暂不可用</span>
                  </div>
                  <div className="zi-price-row">
                    <span>Seedream 5.0 Pro · 图片创作</span>
                    <span>价格暂不可用</span>
                  </div>
                  <p>生成前冻结预计积分，按任务实际状态结算。</p>
                </details>
                <p className="zi-local-note">账户服务暂不可用，尚未读取积分余额。</p>
              </Glass>
            </FadeContent>
            <FadeContent duration={650} delay={90}>
              <AccountLedger onRetry={() => notify('账户服务暂不可用，请稍后再试。')} />
            </FadeContent>
          </div>
          <div className="zi-account-settings">
            <FadeContent duration={650} delay={90}>
              <Glass as="section" className="zi-account-card">
                <div className="zi-card-heading">
                  <h2>个人资料</h2>
                  <UserRound />
                </div>
                <p className="zi-account-email">手机号尚未绑定 · 账号服务未接入</p>
                <form onSubmit={saveProfile}>
                  <label className="zi-field">
                    显示名称
                    <input
                      ref={nameInput}
                      name="displayName"
                      value={name}
                      maxLength={40}
                      onChange={(event) => setName(event.target.value)}
                      autoComplete="nickname"
                    />
                  </label>
                  <button type="submit" className="zi-button zi-primary">
                    保存资料
                  </button>
                </form>
                <p className="zi-local-note">名称修改仅在本次访问中保留。</p>
              </Glass>
            </FadeContent>
            <FadeContent duration={650} delay={120}>
              <Glass as="section" className="zi-account-card">
                <div className="zi-card-heading">
                  <h2>账号安全</h2>
                  <SlidersHorizontal />
                </div>
                <p className="zi-settings-intro">当前使用手机号验证码登录，无需设置密码。</p>
                <p className="zi-local-note">短信与账号服务尚未接入，本页面不代表已登录。</p>
                <Link href="/login" className="zi-button zi-secondary">
                  前往手机号登录
                </Link>
              </Glass>
            </FadeContent>
            <div className="zi-account-session">
              <Link href="/login" className="zi-button zi-secondary">
                <ArrowRight />
                <span>登录账号</span>
              </Link>
              <details className="zi-danger-zone">
                <summary>注销账号</summary>
                <p>账号注销暂不可用。当前不会删除任何数据。</p>
                <button
                  type="button"
                  className="zi-text-button"
                  onClick={() => notify('账号注销暂不可用，未删除任何数据。')}
                >
                  查看注销状态
                </button>
              </details>
            </div>
          </div>
        </div>
      </div>
    </WorkspaceShell>
  );
}
