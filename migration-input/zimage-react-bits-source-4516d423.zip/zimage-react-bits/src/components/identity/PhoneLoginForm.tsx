'use client';

import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useHydrated } from '@/lib/useHydrated';
import {
  DEMO_PHONE_CODE,
  PhoneAuthError,
  demoPhoneAuth,
  type PhoneAuthService,
  type PhoneCodeChallenge,
} from './phone-auth';
import { validatePhone, validatePhoneLogin, type PhoneValidationError } from './validation';

type Feedback = { kind: 'error' | 'status'; message: string; field?: 'phone' | 'code' };

export default function PhoneLoginForm({
  service = demoPhoneAuth,
}: {
  service?: PhoneAuthService;
}) {
  const hydrated = useHydrated();
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState<'request' | 'verify' | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [challenge, setChallenge] = useState<(PhoneCodeChallenge & { phone: string }) | null>(null);
  const [resendAt, setResendAt] = useState(0);
  const [secondsRemaining, setSecondsRemaining] = useState(0);
  const form = useRef<HTMLFormElement>(null);
  const feedbackRef = useRef<HTMLParagraphElement>(null);
  // State alone cannot block two events before React commits the disabled controls.
  const active = useRef<AbortController | null>(null);
  const resendDeadline = useRef(0);

  useEffect(
    () => () => {
      active.current?.abort();
      active.current = null;
    },
    [],
  );

  useEffect(() => {
    if (!resendAt) return;
    const tick = () => {
      const remaining = Math.max(0, Math.ceil((resendAt - Date.now()) / 1000));
      setSecondsRemaining(remaining);
      if (!remaining) clearInterval(interval);
    };
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [resendAt]);

  useEffect(() => {
    if (feedback) feedbackRef.current?.scrollIntoView({ block: 'nearest' });
    if (feedback?.field && !busy) {
      form.current?.querySelector<HTMLInputElement>(`[name="${feedback.field}"]`)?.focus();
    }
  }, [feedback, busy]);

  function showValidation(error: PhoneValidationError) {
    setFeedback({ kind: 'error', ...error });
  }

  function changePhone(value: string) {
    active.current?.abort();
    active.current = null;
    setBusy(null);
    setPhone(value);
    setCode('');
    setChallenge(null);
    setFeedback(null);
  }

  function reportFailure(error: unknown, operation: 'request' | 'verify') {
    if (error instanceof PhoneAuthError) {
      if (error.code === 'invalid-phone') {
        showValidation({ field: 'phone', message: '请输入有效的中国大陆 11 位手机号。' });
        return;
      }
      if (error.code === 'invalid-code') {
        showValidation({ field: 'code', message: `演示验证码不正确，请输入 ${DEMO_PHONE_CODE}。` });
        return;
      }
      setChallenge(null);
      setCode('');
      setFeedback({ kind: 'error', message: '验证码已失效，请重新获取。' });
      return;
    }
    // Never render raw provider errors, which can contain phone numbers or credentials.
    setFeedback({
      kind: 'error',
      message:
        operation === 'request'
          ? '暂时无法获取演示验证码，请重试。'
          : '暂时无法完成演示校验，请重试。',
    });
  }

  async function requestCode() {
    if (!hydrated || active.current || Date.now() < resendDeadline.current) return;
    const number = phone.trim();
    const error = validatePhone(number);
    if (error) return showValidation(error);
    const controller = new AbortController();
    active.current = controller;
    setBusy('request');
    setFeedback(null);
    setChallenge(null);
    setCode('');
    try {
      const result = await service.requestCode(
        { countryCode: '+86', number },
        { signal: controller.signal },
      );
      if (active.current !== controller || controller.signal.aborted) return;
      const seconds = Number.isFinite(result.retryAfterSeconds)
        ? Math.max(0, Math.ceil(result.retryAfterSeconds))
        : 60;
      resendDeadline.current = Date.now() + seconds * 1000;
      setResendAt(seconds > 0 ? resendDeadline.current : 0);
      setSecondsRemaining(seconds);
      setChallenge({ ...result, phone: number });
      setFeedback({ kind: 'status', message: `演示验证码为 ${DEMO_PHONE_CODE}，未发送短信。` });
    } catch (error) {
      if (active.current === controller && !controller.signal.aborted)
        reportFailure(error, 'request');
    } finally {
      if (active.current === controller) {
        active.current = null;
        setBusy(null);
      }
    }
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!hydrated || active.current) return;
    const number = phone.trim();
    const error = validatePhoneLogin(number, code);
    if (error) return showValidation(error);
    if (!challenge || challenge.phone !== number) {
      setFeedback({ kind: 'error', message: '请先获取当前手机号的演示验证码。' });
      return;
    }
    const controller = new AbortController();
    active.current = controller;
    setBusy('verify');
    setFeedback(null);
    try {
      await service.verifyCode(
        { countryCode: '+86', number, code, challengeId: challenge.id },
        { signal: controller.signal },
      );
      if (active.current !== controller || controller.signal.aborted) return;
      setCode('');
      setChallenge(null);
      setFeedback({
        kind: 'status',
        message: '演示校验完成，尚未登录。短信与账号服务未接入，不会创建登录会话。',
      });
    } catch (error) {
      if (active.current === controller && !controller.signal.aborted)
        reportFailure(error, 'verify');
    } finally {
      if (active.current === controller) {
        active.current = null;
        setBusy(null);
      }
    }
  }

  return (
    <form
      ref={form}
      className="zi-auth-form"
      method="post"
      noValidate
      onSubmit={submit}
      aria-busy={busy !== null}
      aria-describedby="zi-phone-demo-note"
    >
      <p id="zi-phone-demo-note" className="zi-register-note">
        仅供前端演示：短信与账号服务未接入，不会发送短信或真实登录。请勿输入真实验证码。
      </p>
      <fieldset className="zi-credential-fields" disabled={!hydrated}>
        <label className="zi-field" htmlFor="zi-phone">
          手机号
        </label>
        <div className="zi-phone-field zi-field">
          <span className="zi-phone-prefix" aria-hidden="true">
            +86
          </span>
          <input
            id="zi-phone"
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel-national"
            placeholder="输入 11 位手机号"
            maxLength={11}
            value={phone}
            onChange={(event) => changePhone(event.target.value)}
            disabled={busy !== null}
            aria-describedby={
              feedback?.field === 'phone' ? 'zi-phone-region zi-phone-feedback' : 'zi-phone-region'
            }
            aria-invalid={feedback?.field === 'phone' || undefined}
            required
          />
        </div>
        <p id="zi-phone-region" className="sr-only">
          中国大陆手机号，国家区号 +86
        </p>
        <label className="zi-field" htmlFor="zi-phone-code">
          6 位数字验证码
        </label>
        <div className="zi-code-field zi-field">
          <input
            id="zi-phone-code"
            name="code"
            inputMode="numeric"
            autoComplete="one-time-code"
            pattern="[0-9]{6}"
            maxLength={6}
            placeholder="输入演示验证码"
            value={code}
            onChange={(event) => setCode(event.target.value.replace(/[^0-9]/g, '').slice(0, 6))}
            disabled={busy !== null}
            aria-invalid={feedback?.field === 'code' || undefined}
            aria-describedby={feedback?.field === 'code' ? 'zi-phone-feedback' : undefined}
            required
          />
          <button
            type="button"
            className="zi-button zi-secondary zi-code-request"
            disabled={!hydrated || busy !== null || secondsRemaining > 0}
            onClick={requestCode}
          >
            {busy === 'request'
              ? '获取中…'
              : secondsRemaining > 0
                ? `${secondsRemaining} 秒后重新获取`
                : '获取演示验证码'}
          </button>
        </div>
        {feedback && (
          <p
            id="zi-phone-feedback"
            ref={feedbackRef}
            className={feedback.kind === 'error' ? 'zi-feedback' : 'zi-register-note'}
            role={feedback.kind === 'error' ? 'alert' : 'status'}
          >
            {feedback.message}
          </p>
        )}
        <button
          className="zi-button zi-primary zi-auth-submit"
          type="submit"
          disabled={!hydrated || busy !== null}
          onClick={(event) => {
            // A local response can settle before the second click of a physical double-click.
            if (event.detail > 1) event.preventDefault();
          }}
        >
          {busy === 'verify' ? '校验中…' : '验证并继续（演示）'}
        </button>
      </fieldset>
    </form>
  );
}
