import type { ModelProvider } from '@/lib/model-catalog';

/** Small application-drawn provider glyphs. No remote assets or icon-library payload. */
export function ProviderIcon({ provider }: { provider: ModelProvider }) {
  return (
    <svg
      className="model-provider-icon"
      data-provider={provider}
      viewBox="0 0 24 24"
      width="20"
      height="20"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {provider === 'openai' && (
        <>
          {[0, 60, 120].map((angle) => (
            <ellipse
              key={angle}
              cx="12"
              cy="12"
              rx="4.5"
              ry="9"
              transform={`rotate(${angle} 12 12)`}
            />
          ))}
        </>
      )}
      {provider === 'google' && (
        <path
          d="M12 2c1.4 6.3 3.7 8.6 10 10-6.3 1.4-8.6 3.7-10 10C10.6 15.7 8.3 13.4 2 12c6.3-1.4 8.6-3.7 10-10Z"
          fill="currentColor"
          stroke="none"
        />
      )}
      {provider === 'qwen' && (
        <>
          <path d="m12 2 4 6 6 4-6 4-4 6-4-6-6-4 6-4Z" />
          <path d="m8 8 8 8m0-8-8 8M8 8h8v8H8Z" />
        </>
      )}
      {provider === 'anthropic' && <path d="m3 20 7-16 7 16M6 14h8M17 4l5 16" strokeWidth="2.3" />}
      {provider === 'deepseek' && (
        <>
          <path
            d="M3 9c2-4 9-5 13-1l5-3-1 6 2 2-6 1c-2 6-10 7-13 1l3 1c-2-2-3-4-3-7Z"
            fill="currentColor"
            stroke="none"
          />
          <circle cx="8" cy="10" r="1" fill="white" stroke="none" />
        </>
      )}
      {provider === 'xai' && <path d="m4 4 16 16M20 4 4 20M14 4h6v6" strokeWidth="2.2" />}
      {provider === 'bytedance' && (
        <>
          <path d="M12 21V10M12 13C5 13 3 9 3 4c6 0 9 3 9 9Zm0-3c0-5 3-7 8-7 0 5-3 7-8 7Z" />
          <path d="m8 21 4-2 4 2" />
        </>
      )}
    </svg>
  );
}
