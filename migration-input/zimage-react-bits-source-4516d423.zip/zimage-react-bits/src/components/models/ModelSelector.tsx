'use client';

import GlideSelect from '@/components/react-bits/GlideSelect';
import {
  CHAT_MODELS,
  IMAGE_MODELS,
  type ChatModelId,
  type ImageModelId,
} from '@/lib/model-catalog';
import { ProviderIcon } from './ProviderIcon';
import './model-selector.css';

type ModelSelectorProps = {
  className?: string;
  disabled?: boolean;
  placement?: 'top' | 'bottom';
} & (
  | { capability: 'chat'; value: ChatModelId; onChange: (value: ChatModelId) => void }
  | { capability: 'image'; value: ImageModelId; onChange: (value: ImageModelId) => void }
);

const optionsFor = (models: typeof CHAT_MODELS | typeof IMAGE_MODELS) =>
  models.map((model) => ({
    value: model.id,
    textValue: model.name,
    label: (
      <span className="model-selector-label">
        <ProviderIcon provider={model.provider} />
        <span className="model-selector-name">{model.name}</span>
      </span>
    ),
  }));
const CHAT_OPTIONS = optionsFor(CHAT_MODELS);
const IMAGE_OPTIONS = optionsFor(IMAGE_MODELS);

export function ModelSelector(props: ModelSelectorProps) {
  const { capability, value, className = '', disabled, placement = 'bottom' } = props;
  return (
    <GlideSelect
      className={`model-selector ${className}`}
      ariaLabel={capability === 'chat' ? '对话模型' : '图片模型'}
      includeValueInLabel
      value={value}
      options={capability === 'chat' ? CHAT_OPTIONS : IMAGE_OPTIONS}
      onChange={(next) => {
        // Validate at the UI boundary as well as when restoring browser storage.
        if (props.capability === 'chat') {
          const model = CHAT_MODELS.find((candidate) => candidate.id === next);
          if (model) props.onChange(model.id);
        } else {
          const model = IMAGE_MODELS.find((candidate) => candidate.id === next);
          if (model) props.onChange(model.id);
        }
      }}
      disabled={disabled}
      placement={placement}
      menuWidth={280}
      size="lg"
      surfaceColor="#ffffff"
      textColor="#292633"
      showTags={false}
    />
  );
}
