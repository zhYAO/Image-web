export type WorkspaceMode = 'chat' | 'image';
export type SessionCategory = 'general' | 'commerce';

export interface PreviewMessage {
  id?: string;
  role: 'user' | 'assistant';
  text: string;
  image?: string;
  simulation?: { status: 'thinking' | 'typing' | 'done' | 'stopped'; step: number };
}

export interface PreviewSession {
  id: string;
  title: string;
  category: SessionCategory;
  messages: PreviewMessage[];
}

export interface PreviewReference {
  id: string;
  name: string;
  url: string;
  size: number;
  type: string;
}

export interface CreationScene {
  id: string;
  name: string;
  image: string;
  tag: string;
  description: string;
}
