export type ModelCapability = 'chat' | 'image';
export type ModelProvider =
  'openai' | 'google' | 'qwen' | 'anthropic' | 'deepseek' | 'xai' | 'bytedance';

interface ModelDefinition {
  id: string;
  name: string;
  provider: ModelProvider;
  capability: ModelCapability;
}

/** Frontend choices only. These IDs never dispatch a request to a model provider.
 * Official catalog references checked 2026-10-19: docs/model-selectors.md. */
export const MODEL_CATALOG = [
  { id: 'gpt-6.1-sol', name: 'GPT-6.1 Sol', provider: 'openai', capability: 'chat' },
  { id: 'gemini-4-argon', name: 'Gemini 4 Argon', provider: 'google', capability: 'chat' },
  { id: 'qwen3.8-max', name: 'Qwen3.8-Max', provider: 'qwen', capability: 'chat' },
  { id: 'claude-opus-5-5', name: 'Claude Opus 5.5', provider: 'anthropic', capability: 'chat' },
  { id: 'deepseek-flash', name: 'DeepSeek V4.1 Flash', provider: 'deepseek', capability: 'chat' },
  { id: 'grok-4.7', name: 'Grok 4.7', provider: 'xai', capability: 'chat' },
  {
    id: 'gpt-image-2.5-sunburst',
    name: 'GPT-Image-2.5 Sunburst',
    provider: 'openai',
    capability: 'image',
  },
  {
    id: 'gemini-nano-banana-2.1',
    name: 'Gemini Nano Banana 2.1',
    provider: 'google',
    capability: 'image',
  },
  { id: 'qwen-image-3.0-pro', name: 'Qwen Image 3.0 Pro', provider: 'qwen', capability: 'image' },
  // Preserve the preview's selected Pro-tier identity, not a regional API endpoint.
  {
    id: 'doubao-seedream-5.0-pro',
    name: 'Seedream 5.0 Pro',
    provider: 'bytedance',
    capability: 'image',
  },
] as const satisfies readonly ModelDefinition[];

export type ModelId = (typeof MODEL_CATALOG)[number]['id'];
export type ChatModelId = Extract<(typeof MODEL_CATALOG)[number], { capability: 'chat' }>['id'];
export type ImageModelId = Extract<(typeof MODEL_CATALOG)[number], { capability: 'image' }>['id'];

export const CHAT_MODELS = MODEL_CATALOG.filter((model) => model.capability === 'chat');
export const IMAGE_MODELS = MODEL_CATALOG.filter((model) => model.capability === 'image');
export const DEFAULT_CHAT_MODEL: ChatModelId = 'gpt-6.1-sol';
export const DEFAULT_IMAGE_MODEL: ImageModelId = 'doubao-seedream-5.0-pro';

/** Ignore obsolete, unknown and chat-only IDs when restoring a local image draft. */
export function restoreImageModel(value: unknown): ImageModelId {
  return IMAGE_MODELS.find((model) => model.id === value)?.id ?? DEFAULT_IMAGE_MODEL;
}
