import type { CreationScene, PreviewSession } from './preview-types';

// Content and route names mirror the current ZImage source. All session content is synthetic.
export const scenes: CreationScene[] = [
  {
    id: 'product-set',
    name: '商品套图',
    image: '/assets/pages/meitu-v1/kit-scene.webp',
    tag: '风格统一',
    description: '从商品主图到细节展示，让每一张图都有同一种质感。',
  },
  {
    id: 'detail',
    name: 'A+ 详情页',
    image: '/assets/pages/meitu-v1/detail-hero.webp',
    tag: '卖点呈现',
    description: '把产品特点变成有说服力的画面，讲清每一个细节。',
  },
  {
    id: 'clone',
    name: '爆款图复刻',
    image: '/assets/pages/meitu-v1/clone-result.webp',
    tag: '灵感再创作',
    description: '从参考画面出发，为你的商品探索新的视觉表达。',
  },
  {
    id: 'product-main',
    name: 'AI 商品图',
    image: '/assets/pages/meitu-v1/shoot-botanical.webp',
    tag: '场景塑造',
    description: '用光影、材质与场景，让商品自然成为画面中心。',
  },
  {
    id: 'apparel-catalog',
    name: '服装商品图片',
    image: '/assets/pages/apparel-v2/main-1.webp',
    tag: '服装展示',
    description: '呈现版型与面料细节，为服装打造清晰统一的视觉。',
  },
];
export const ratios = ['1:1', '3:4', '4:3', '9:16', '16:9'];
export const mockSessions: PreviewSession[] = [
  {
    id: 'preview-light',
    title: '光影与材质练习',
    category: 'general',
    messages: [
      { role: 'user', text: '想试试柔和的自然光与细腻的材质。' },
      {
        role: 'assistant',
        text: '可以用侧窗漫射光搭配浅色背景，让柔和阴影衬托材质。你更想突出表面纹理，还是整体轮廓？',
      },
    ],
  },
  {
    id: 'preview-product',
    title: '商品套图创作',
    category: 'commerce',
    messages: [
      {
        role: 'assistant',
        text: '先选定一套统一的背景与光线，再分别安排主图、细节和使用场景，让商品套图保持一致。',
      },
    ],
  },
  {
    id: 'preview-ideas',
    title: '长对话滚动示例',
    category: 'general',
    messages: Array.from({ length: 28 }, (_, index) => ({
      id: `preview-scroll-${index + 1}`,
      role: index % 2 === 0 ? 'user' : 'assistant',
      text:
        index === 0
          ? '这是一段用于检查长对话滚动的静态示例，不代表实时生成的回复。请从顶部向下查看光线、构图与材质的讨论。'
          : index % 2 === 0
            ? `第 ${Math.floor(index / 2) + 1} 轮：继续讨论商品画面的自然光、背景与材质。希望保留完整的主体轮廓，也能看清表面纹理。不同尺寸的画面该怎样保持一致？`
            : `静态示例 · 创作建议 ${Math.ceil(index / 2)}：先确定柔和的侧窗光，再用浅色背景突出主体。为文字与裁切预留空间，把主图、细节图和使用场景分开组织。检查边缘、阴影方向与色彩的一致性，保留产品完整信息。`,
    })),
  },
];

const sampleTitles = [
  '春日香氛的视觉提案',
  '陶瓷杯的晨光场景',
  '轻户外服饰上新',
  '护肤系列的色彩研究',
  '咖啡包装与桌面静物',
  '珠宝系列主图',
  '一组温暖的居家画面',
  '产品细节页排版',
  '深色背景的光影实验',
  '夏日果饮灵感',
  '极简家具的空间感',
  '鞋履新品拍摄方案',
  '自然材质的色彩搭配',
  '节日礼盒创意',
  '单品主图对比练习',
  '运动水杯场景搭建',
  '柔软织物的细节',
  '从参考图寻找新的视觉方向：自然光、亚麻材质与柔和暖色的组合',
  '木质香调的画面表达',
  '日常小物的创作记录',
  '品牌系列视觉探索',
];
mockSessions.push(
  ...sampleTitles.map<PreviewSession>((title, i) => ({
    id: `preview-sample-${i + 1}`,
    title,
    category: i % 3 === 0 ? 'commerce' : 'general',
    messages: [
      { role: 'user', text: `一起看看「${title}」的创作方向。` },
      { role: 'assistant', text: '可以从光线、色彩和构图开始，慢慢把想法变成完整的画面。' },
    ],
  })),
);
