export const MAX_REFERENCES = 4;
export const MAX_REFERENCE_BYTES = 10 * 1024 * 1024;
export const REFERENCE_TYPES = ['image/png', 'image/jpeg', 'image/webp'] as const;

export function validateReference(
  file: { size: number; type: string },
  existingCount: number,
): string | null {
  if (existingCount >= MAX_REFERENCES) return '最多添加 4 张参考图。';
  if (!(REFERENCE_TYPES as readonly string[]).includes(file.type))
    return '请选择 PNG、JPEG 或 WebP 图片。';
  if (file.size > MAX_REFERENCE_BYTES) return '每张参考图不能超过 10 MB。';
  if (file.size === 0) return '这张图片是空文件，请重新选择。';
  return null;
}
