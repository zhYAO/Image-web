import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  MODEL_CATALOG,
  CHAT_MODELS,
  IMAGE_MODELS,
  DEFAULT_CHAT_MODEL,
  DEFAULT_IMAGE_MODEL,
  restoreImageModel,
} from '../src/lib/model-catalog.ts';

test('the shared frontend catalog contains ten unique readable choices with explicit capabilities', () => {
  assert.equal(MODEL_CATALOG.length, 10);
  assert.equal(new Set(MODEL_CATALOG.map((model) => model.id)).size, 10);
  assert.equal(CHAT_MODELS.length, 6);
  assert.equal(IMAGE_MODELS.length, 4);
  assert.ok(CHAT_MODELS.every((model) => model.capability === 'chat'));
  assert.ok(IMAGE_MODELS.every((model) => model.capability === 'image'));
  assert.ok(CHAT_MODELS.some((model) => model.id === DEFAULT_CHAT_MODEL));
  assert.equal(DEFAULT_IMAGE_MODEL, 'doubao-seedream-5.0-pro');
  assert.deepEqual(
    IMAGE_MODELS.map((model) => model.name),
    ['GPT-Image-2.5 Sunburst', 'Gemini Nano Banana 2.1', 'Qwen Image 3.0 Pro', 'Seedream 5.0 Pro'],
  );
  assert.deepEqual(
    new Set(MODEL_CATALOG.map((model) => model.provider)),
    new Set(['openai', 'google', 'qwen', 'anthropic', 'deepseek', 'xai', 'bytedance']),
  );
});

test('image model restoration rejects chat choices, obsolete IDs and malformed stored data', () => {
  for (const model of IMAGE_MODELS) assert.equal(restoreImageModel(model.id), model.id);
  for (const value of [
    undefined,
    null,
    '',
    {},
    [],
    'retired-image-model',
    ...CHAT_MODELS.map((model) => model.id),
  ]) {
    assert.equal(restoreImageModel(value), DEFAULT_IMAGE_MODEL);
  }
});

test('all value dropdown implementations use the one local GlideSelect and glyphs have no remote assets', () => {
  function sourceFiles(directory) {
    return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
      const file = path.join(directory, entry.name);
      return entry.isDirectory() ? sourceFiles(file) : file.endsWith('.tsx') ? [file] : [];
    });
  }
  for (const file of sourceFiles('src/components')) {
    const source = fs.readFileSync(file, 'utf8');
    assert.doesNotMatch(source, /<select\b/, `${file} must reuse GlideSelect for value menus`);
    if (!file.endsWith('/GlideSelect.tsx')) assert.doesNotMatch(source, /role=["']listbox["']/);
  }
  const iconSource = fs.readFileSync('src/components/models/ProviderIcon.tsx', 'utf8');
  assert.doesNotMatch(iconSource, /https?:|<img\b|<image\b|from ['"].*icons/);
  assert.match(iconSource, /aria-hidden="true"/);
});
