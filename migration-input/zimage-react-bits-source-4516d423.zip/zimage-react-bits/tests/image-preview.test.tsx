import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';

const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'https://zimage.test',
  pretendToBeVisual: true,
});
for (const key of [
  'window',
  'self',
  'document',
  'navigator',
  'HTMLElement',
  'HTMLDialogElement',
  'Element',
  'Node',
  'Event',
  'MouseEvent',
  'KeyboardEvent',
  'MutationObserver',
]) {
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
}
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
HTMLDialogElement.prototype.showModal = function () {
  this.setAttribute('open', '');
};
HTMLDialogElement.prototype.close = function () {
  this.removeAttribute('open');
};
const { render, fireEvent, cleanup } = await import('@testing-library/react');
const { default: ImagePreviewDialog } = await import('../src/components/ImagePreviewDialog');
const { default: CommerceDialog } = await import('../src/components/commerce/CommerceDialog');
const { default: ReferenceViewer } = await import('../src/components/workspace/ReferenceViewer');
afterEach(() => cleanup());

test('product-set and reference images use the same canonical full-image dialog', () => {
  const image = {
    src: '/example.webp',
    alt: '商品原图',
    title: '示例图片',
    dimensions: '100 × 200',
    download: 'example.webp',
  };
  const view = render(<CommerceDialog title={image.title} image={image} onClose={() => {}} />);
  assert.ok(view.getByRole('dialog').classList.contains('image-preview-dialog'));
  assert.equal(view.getByRole('img').getAttribute('src'), image.src);
  assert.ok(view.getByText('图片尺寸 · 100 × 200'));
  assert.equal(
    view.getByRole('link', { name: '下载示例图片' }).getAttribute('download'),
    image.download,
  );
  view.rerender(<ReferenceViewer url={image.src} name="上传参考" onClose={() => {}} />);
  assert.ok(
    view
      .getByRole('dialog', { name: '参考图 上传参考' })
      .classList.contains('image-preview-dialog'),
  );
});

test('shared preview uses latest paging callbacks, closes on backdrop/cancel and restores focus', () => {
  const trigger = document.createElement('button');
  document.body.append(trigger);
  trigger.focus();
  let previous = 0;
  let next = 0;
  let closes = 0;
  const image = { src: '/one.webp', alt: '一' };
  const view = render(
    <ImagePreviewDialog image={image} imageOnly onClose={() => closes++} onNext={() => next++} />,
  );
  const dialog = view.getByRole('dialog');
  const close = view.getByRole('button', { name: '关闭图片' });
  assert.equal(document.activeElement, close);
  fireEvent.keyDown(dialog, { key: 'ArrowRight' });
  assert.equal(next, 1);
  view.rerender(
    <ImagePreviewDialog
      image={{ src: '/two.webp', alt: '二' }}
      imageOnly
      onClose={() => closes++}
      onPrevious={() => previous++}
    />,
  );
  assert.equal(view.getByRole('dialog'), dialog);
  assert.equal(document.activeElement, close);
  fireEvent.keyDown(dialog, { key: 'ArrowLeft' });
  assert.equal(previous, 1);
  fireEvent.click(view.getByRole('button', { name: '上一张图片' }));
  assert.equal(previous, 2);
  fireEvent.click(view.getByRole('img'));
  assert.equal(closes, 0);
  fireEvent.click(dialog);
  fireEvent(dialog, new Event('cancel', { cancelable: true }));
  assert.equal(closes, 2);
  assert.equal(dialog.querySelector('h2'), null);
  view.unmount();
  assert.equal(document.activeElement, trigger);
  trigger.remove();
});

test('shared preview announces image failures and resets errors when navigating to another image', () => {
  const first = { src: '/missing.webp', alt: '第一张' };
  const view = render(<ImagePreviewDialog image={first} imageOnly onClose={() => {}} />);
  const image = view.getByRole('img');
  fireEvent.error(image);
  assert.equal((image as HTMLImageElement).hidden, true);
  assert.equal(view.getByRole('status').textContent, '图片暂时无法显示');
  assert.ok(view.getByRole('button', { name: '关闭图片' }));
  view.rerender(
    <ImagePreviewDialog
      image={{ src: '/working.webp', alt: '第二张' }}
      imageOnly
      onClose={() => {}}
    />,
  );
  assert.equal(view.queryByRole('status'), null);
  assert.equal((view.getByRole('img') as HTMLImageElement).hidden, false);
  view.rerender(<ImagePreviewDialog image={first} imageOnly onClose={() => {}} />);
  assert.equal(view.queryByRole('status'), null);
  assert.equal((view.getByRole('img') as HTMLImageElement).hidden, false);
});
