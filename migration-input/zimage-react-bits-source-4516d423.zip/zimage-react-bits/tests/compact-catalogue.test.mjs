import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const source = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('catalogue uses asset-library sizing at desktop, tablet and mobile widths', () => {
  const css = source('src/components/commerce/commerce.css').split('/* Match the asset library')[1];
  assert.ok(css);
  assert.match(css, /width: min\(1200px, calc\(100% - 48px\)\)/);
  assert.match(css, /repeat\(4, minmax\(0, 1fr\)\)/);
  assert.match(css, /\.cm-tool-cover\s*\{\s*aspect-ratio: 1;/);
  assert.match(css, /max-width: 850px[\s\S]*?repeat\(3, minmax\(0, 1fr\)\)/);
  assert.match(css, /max-width: 640px[\s\S]*?repeat\(2, minmax\(0, 1fr\)\)/);
});

test('every full-image entry uses the shared preview, with collection dialogs kept separate', () => {
  for (const file of [
    'commerce/CommerceDialog.tsx',
    'workspace/ReferenceViewer.tsx',
    'workspace/WorkspacePage.tsx',
    'assets/AssetLibrary.tsx',
  ]) {
    assert.match(source(`src/components/${file}`), /ImagePreviewDialog/);
  }
  assert.doesNotMatch(
    source('src/components/assets/AssetDialogContent.tsx'),
    /<img|AssetImage|za-detail-art/,
  );
  assert.doesNotMatch(source('src/components/workspace/ReferenceViewer.tsx'), /<dialog|<img/);
  assert.doesNotMatch(source('src/components/commerce/CommerceDialog.tsx'), /<img|cm-full-image/);
});

test('catalogue route anchor has nonzero geometry without adding layout height', () => {
  const css = source('src/components/commerce/commerce.css');
  const rule = css.match(/\.cm-catalogue-route-anchor\s*\{([^}]*)\}/s)?.[1];
  assert.ok(rule, 'Next skips zero-size or missing route targets');
  assert.match(rule, /height: 1px;/);
  assert.match(rule, /margin-bottom: -1px;/);
  assert.doesNotMatch(rule, /display:\s*none|visibility:\s*hidden|position:\s*(fixed|sticky)/);
});
