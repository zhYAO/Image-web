import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  createEditorState,
  totalImages,
  reorderModules,
  updateCount,
  buildResults,
  uploadLimit,
  validateUploadFiles,
  fitExampleContent,
  draftConfiguration,
} from '../src/components/commerce/commerce-state.ts';
import { scenes, imageSource, detailModules } from '../src/components/commerce/commerce-data.ts';
test('the five commerce routes and all original assets exist', () => {
  assert.equal(scenes.length, 5);
  assert.equal(detailModules.length, 16);
  for (const scene of scenes)
    for (const file of scene.originals)
      assert.ok(fs.existsSync(`public${imageSource(scene, file)}`));
});
test('set image counts stay between zero and twenty', () => {
  let counts = createEditorState().counts;
  assert.equal(totalImages('product-set', createEditorState()), 7);
  for (let i = 0; i < 30; i++) counts = updateCount(counts, 'white', 1);
  assert.equal(
    Object.values(counts).reduce((a, b) => a + b),
    20,
  );
  for (let i = 0; i < 30; i++) counts = updateCount(counts, 'white', -1);
  assert.equal(counts.white, 0);
});
test('module reorder is immutable and handles invalid targets', () => {
  const modules = ['a', 'b', 'c'];
  assert.deepEqual(reorderModules(modules, 0, 2), ['b', 'c', 'a']);
  assert.deepEqual(modules, ['a', 'b', 'c']);
  assert.deepEqual(reorderModules(modules, 0, -1), modules);
});
test('advanced A+ produces desktop and mobile results per selected module', () => {
  const state = createEditorState();
  state.advanced = true;
  state.modules = ['品牌故事', '尺寸说明'];
  const results = buildResults(scenes[1], state);
  assert.equal(results.length, 4);
  assert.match(results[0].label, /桌面/);
  assert.match(results[1].label, /移动/);
});
test('uploads validate formats, sizes, capacity and duplicate batch files', () => {
  const good = { name: 'one.jpg', size: 100, type: 'image/jpeg' };
  assert.equal(uploadLimit('clone', 'style'), 20);
  assert.equal(validateUploadFiles('product-set', 'product', [good], []), '');
  assert.match(validateUploadFiles('product-set', 'product', [good, good], []), /重复/);
  assert.match(validateUploadFiles('apparel-catalog', 'logo', [good], []), /PNG/);
  assert.match(
    validateUploadFiles('product-set', 'product', [{ ...good, size: 11 * 1024 * 1024 }], []),
    /10 MB/,
  );
});
test('rotated left hero and continuous stack fit the available slot', () => {
  for (const images of [
    [{ width: 1200, height: 1200 }],
    [
      { width: 970, height: 600 },
      { width: 970, height: 600 },
      { width: 970, height: 600 },
    ],
  ]) {
    const fit = fitExampleContent(images, 320, 380, {
      rotation: -2,
      extraWidth: 14,
      extraHeight: 30,
    });
    assert.ok(fit.rotatedWidth <= 320.00001);
    assert.ok(fit.rotatedHeight <= 380.00001);
  }
  assert.equal(fitExampleContent([{ width: 0, height: 200 }], 300, 300), null);
});
test('saved configuration excludes object URLs, runtime loading and results', () => {
  const state = createEditorState();
  state.references = [{ url: 'blob:secret', name: 'photo' }];
  state.busy = true;
  state.description = 'saved description';
  const draft = draftConfiguration(state);
  assert.equal(draft.description, state.description);
  assert.deepEqual(draft.references, []);
  assert.equal(draft.busy, false);
});
test('commerce routes use framework links and preserve the hidden catalogue in one persistent layout', () => {
  const layout = fs.readFileSync('src/components/commerce/CommerceLayout.tsx', 'utf8');
  const catalogue = fs.readFileSync('src/components/commerce/CommerceCatalogue.tsx', 'utf8');
  const route = fs.readFileSync('src/app/create/[scene]/page.tsx', 'utf8');
  assert.match(layout, /hidden\s*=\s*\{\s*!catalogue\s*\}\s+inert\s*=\s*\{\s*!catalogue\s*\}/);
  assert.match(catalogue, /memo\s*\(\s*function\s+CommerceCatalogue/);
  assert.match(catalogue, /loading="lazy"/);
  assert.match(route, /generateStaticParams/);
  assert.match(route, /params\s*:\s*Promise/);
});
test('commerce stays native React with conditional result/dialog chunks and no generation network', () => {
  for (const file of fs
    .readdirSync('src/components/commerce')
    .filter((file) => file.endsWith('.tsx'))) {
    const source = fs.readFileSync(`src/components/commerce/${file}`, 'utf8');
    assert.doesNotMatch(
      source,
      /dangerouslySetInnerHTML|innerHTML\s*=|<iframe|fetch\(|XMLHttpRequest|模拟|前端|预览|演示/,
    );
  }
  const editor = fs.readFileSync('src/components/commerce/CommerceEditor.tsx', 'utf8');
  assert.match(
    editor,
    /lazy\s*\(\s*\(\s*\)\s*=>\s*import\s*\(\s*['\"]\.\/CommerceResults['\"]\s*\)\s*\)/,
  );
  assert.match(editor, /usePreviewNotify/);
  assert.match(editor, /URL\.revokeObjectURL/);
});
test('results maintain card-level loading and stable identities', () => {
  const source = fs.readFileSync('src/components/commerce/CommerceResults.tsx', 'utf8');
  assert.match(source, /key=\{result.id\}/);
  assert.match(source, /aria-busy=\{Boolean\(result.regenerating\)\}/);
  assert.match(source, /disabled=\{result.regenerating\}/);
});
test('commerce dropdown delegates scrolling and popup ownership to shared GlideSelect', () => {
  const adapter = fs.readFileSync('src/components/commerce/CommerceControls.tsx', 'utf8');
  const source = fs.readFileSync('src/components/react-bits/GlideSelect.tsx', 'utf8');
  assert.match(adapter, /<GlideSelect/);
  assert.match(adapter, /menuWidth=\{240\}/);
  assert.match(
    source,
    /if\s*\(\s*!menuRef\.current\?\.contains\(\s*e\.target\s+as\s+Node\s*\)\s*\)\s*dismissAfterLayoutChange\(\)/,
  );
});

test('catalogue follows document scrolling while only commerce editors own a bounded viewport', () => {
  const css = fs
    .readFileSync('src/components/commerce/commerce.css', 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '');
  const rules = (selector) =>
    [...css.matchAll(/([^{}]+)\{([^{}]*)\}/g)]
      .filter(([, selectors]) => selectors.split(',').some((item) => item.trim() === selector))
      .map(([, , body]) => body)
      .join('\n');
  assert.doesNotMatch(
    rules('.cm-root'),
    /(?:^|[;\n])\s*height\s*:|overflow(?:-y)?\s*:\s*(?:hidden|auto|scroll)/,
  );
  assert.doesNotMatch(rules('.cm-catalogue-cache'), /overflow(?:-y)?\s*:\s*(?:hidden|auto|scroll)/);
  assert.doesNotMatch(rules('.cm-root.cm-catalogue-outlet'), /height\s*:/);
  assert.match(
    rules('.cm-root.cm-editor-outlet'),
    /height:\s*calc\(100svh - var\(--shell-pad\) \* 2 - var\(--topbar-height\)\)/,
  );
  assert.match(rules('.cm-editor-outlet'), /overflow:\s*hidden/);
  assert.match(rules('.cm-editor-outlet .cm-config-scroll'), /overflow:\s*auto/);
});
