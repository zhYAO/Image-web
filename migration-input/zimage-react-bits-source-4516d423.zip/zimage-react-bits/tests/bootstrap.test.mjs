import assert from 'node:assert/strict';
import { test } from 'node:test';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { scenes, mockSessions } from '../src/lib/demo-data.ts';
import { MAX_REFERENCE_BYTES, validateReference } from '../src/lib/reference-validation.ts';

const root = resolve(import.meta.dirname, '..');

test('framework family matches ZImage with an explicitly pinned Next security patch', () => {
  const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
  assert.equal(pkg.dependencies.next, '16.3.8');
  assert.equal(pkg.dependencies.react, '19.2.7');
  assert.equal(pkg.dependencies['react-dom'], '19.2.7');
  assert.equal(pkg.devDependencies.typescript, '6.0.3');
  assert.ok(
    !Object.keys(pkg.dependencies).some((name) =>
      /supabase|langchain|react-bits|gsap|motion/.test(name),
    ),
  );
});

test('five scene paths and images are local and distinct', () => {
  assert.deepEqual(
    scenes.map((scene) => scene.id),
    ['product-set', 'detail', 'clone', 'product-main', 'apparel-catalog'],
  );
  assert.equal(new Set(scenes.map((scene) => scene.id)).size, scenes.length);
  for (const scene of scenes) {
    assert.ok(scene.image.startsWith('/assets/'));
    assert.ok(existsSync(resolve(root, `public${scene.image}`)), scene.image);
  }
});

test('seed sessions have unique IDs, valid categories and independent messages', () => {
  assert.equal(mockSessions.length, 24);
  assert.equal(new Set(mockSessions.map((session) => session.id)).size, 24);
  for (const session of mockSessions) {
    assert.ok(['general', 'commerce'].includes(session.category));
    assert.ok(session.messages.every((message) => ['user', 'assistant'].includes(message.role)));
  }
  assert.notEqual(mockSessions[0].messages, mockSessions[1].messages);
});

test('reference validation permits the three accepted image formats and 10 MiB boundary', () => {
  for (const type of ['image/png', 'image/jpeg', 'image/webp']) {
    assert.equal(validateReference({ type, size: MAX_REFERENCE_BYTES }, 3), null);
  }
});

test('reference validation blocks over-limit, empty and unsupported files', () => {
  assert.match(validateReference({ type: 'image/png', size: 1 }, 4), /4/);
  assert.match(validateReference({ type: 'image/png', size: MAX_REFERENCE_BYTES + 1 }, 0), /10 MB/);
  assert.match(validateReference({ type: 'image/gif', size: 100 }, 0), /PNG/);
  assert.match(validateReference({ type: 'image/png', size: 0 }, 0), /空文件/);
});

test('static build configuration needs no live image optimizer or backend', () => {
  const config = readFileSync(resolve(root, 'next.config.ts'), 'utf8');
  assert.match(config, /output:\s*'export'/);
  assert.match(config, /trailingSlash:\s*true/);
  assert.match(config, /unoptimized:\s*true/);
  assert.doesNotMatch(config, /process\.env|supabase/i);
});

test('initial static HTML inlines CSS to avoid the measured render-blocking request stall', () => {
  const config = readFileSync(resolve(root, 'next.config.ts'), 'utf8');
  assert.match(config, /experimental:\s*\{\s*inlineCss:\s*true/);
});
