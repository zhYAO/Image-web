import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { gzipSync } from 'node:zlib';
import { analyzeExport, inspectBudget } from '../scripts/analyze-bundle.mjs';

const root = resolve(import.meta.dirname, '..');

function fixture() {
  const directory = mkdtempSync(join(tmpdir(), 'zimage-bundle-'));
  const files = {
    'index.html':
      '<html><head><link rel="preload" href="/_next/static/chunks/base.js" as="script"><link rel="stylesheet" href="/_next/static/main.css"></head><body><img src="/assets/hero.webp" width="100" height="200" fetchPriority="high"><img src="/assets/hero.webp" loading="lazy"><script src="/_next/static/chunks/base.js" async></script><script src="/_next/static/chunks/home.js" async></script><script>self.__next_f.push(["/unrelated-reference.js"])</script></body></html>',
    'workspace/index.html':
      '<script src="/_next/static/chunks/base.js"></script><script src="/_next/static/chunks/workspace.js"></script><img src="/assets/second.webp" loading="lazy" width="50" height="50">',
    '_next/static/chunks/base.js': '/* shared next and react runtime */'.repeat(8),
    '_next/static/chunks/home.js': '/* home */'.repeat(5),
    '_next/static/chunks/workspace.js': '/* workspace */'.repeat(5),
    '_next/static/chunks/deferred.js': '/* deferred modal */'.repeat(5),
    '_next/static/main.css': 'body { margin: 0; }',
    'assets/hero.webp': 'first image',
    'assets/second.webp': 'second image',
    'assets/duplicate.webp': 'first image',
  };
  for (const [name, content] of Object.entries(files)) {
    const path = join(directory, name);
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, content);
  }
  return { directory, files, clean: () => rmSync(directory, { recursive: true, force: true }) };
}

test('export analyzer counts only real initial resource tags and deduplicates preloads', () => {
  const sample = fixture();
  try {
    const report = analyzeExport(sample.directory);
    const home = report.routes.find((route) => route.route === '/');
    assert.deepEqual(
      home.scripts.map((file) => file.path),
      ['/_next/static/chunks/base.js', '/_next/static/chunks/home.js'],
    );
    assert.equal(
      home.jsGzipBytes,
      gzipSync(sample.files['_next/static/chunks/base.js'], { level: 9 }).length +
        gzipSync(sample.files['_next/static/chunks/home.js'], { level: 9 }).length,
    );
    assert.equal(home.images.length, 2);
    assert.equal(home.eagerImageBytes, Buffer.byteLength(sample.files['assets/hero.webp']));
    assert.equal(home.imagesWithoutIntrinsicSize.length, 1);
    assert.equal(report.javascript.length, 4);
    assert.equal(report.chunksNotInAnyInitialHtml.length, 1);
    assert.equal(report.chunksNotInAnyInitialHtml[0].path, '/_next/static/chunks/deferred.js');
    assert.equal(report.sharedInitialScripts.length, 1);
    assert.equal(report.duplicateAssets.length, 1);
    assert.equal(report.duplicateAssets[0].copies.length, 2);
    assert.equal(report.missingLocalResources.length, 0);
  } finally {
    sample.clean();
  }
});

test('budgets fail real regressions and report the exact route or asset', () => {
  const sample = fixture();
  try {
    const report = analyzeExport(sample.directory);
    const failures = inspectBudget(report, {
      maxInitialJsGzipBytes: 1,
      maxEagerImageBytes: 1,
      maxSingleImageBytes: 1,
    });
    assert.ok(
      failures.some((message) => message.includes('/workspace/') && message.includes('JavaScript')),
    );
    assert.ok(failures.some((message) => message.includes('/assets/hero.webp')));
    const stricter = inspectBudget(report, {
      routeEagerImageBytes: { '/': 0 },
      maxDuplicateAssetBytes: 0,
    });
    assert.ok(stricter.some((message) => message.startsWith('/ eager image declarations')));
    assert.ok(stricter.some((message) => message.startsWith('Duplicate image copies')));
    assert.deepEqual(
      inspectBudget(report, {
        maxInitialJsGzipBytes: 1e6,
        maxEagerImageBytes: 1e6,
        maxSingleImageBytes: 1e6,
      }),
      [],
    );
  } finally {
    sample.clean();
  }
});

test('runtime dependencies stay limited to framework and tree-shaken icons', () => {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  assert.deepEqual(Object.keys(pkg.dependencies).sort(), [
    'lucide-react',
    'next',
    'react',
    'react-dom',
  ]);
});

test('legacy noModule polyfills are measured separately from modern initial scripts', () => {
  const sample = fixture();
  try {
    writeFileSync(join(sample.directory, '_next/static/chunks/polyfill.js'), 'legacy polyfill');
    writeFileSync(
      join(sample.directory, 'index.html'),
      sample.files['index.html'] +
        '<script src="/_next/static/chunks/polyfill.js" noModule=""></script>',
    );
    const report = analyzeExport(sample.directory);
    const home = report.routes.find((route) => route.route === '/');
    assert.equal(home.scripts.length, 2);
    assert.equal(home.legacyOnlyScripts.length, 1);
    assert.equal(home.legacyOnlyJsGzipBytes, gzipSync('legacy polyfill', { level: 9 }).length);
    assert.equal(
      report.chunksNotInAnyInitialHtml.some((file) => file.path.endsWith('polyfill.js')),
      false,
    );
  } finally {
    sample.clean();
  }
});

test('async chunk evidence comes from emitted loaders and existing files, not import source strings', () => {
  const sample = fixture();
  try {
    writeFileSync(
      join(sample.directory, '_next/static/chunks/home.js'),
      'e.v(s=>Promise.all(["static/chunks/deferred.js"].map(s=>e.l(s))).then(()=>s(1))); const source = "import(unknown)";',
    );
    const report = analyzeExport(sample.directory);
    assert.deepEqual(
      report.asyncChunkReferences.map(({ from, to }) => ({ from, to })),
      [{ from: '/_next/static/chunks/home.js', to: '/_next/static/chunks/deferred.js' }],
    );
  } finally {
    sample.clean();
  }
});

test('app source avoids whole-icon imports, injected HTML, and embedded legacy app', () => {
  function visit(path) {
    return readdirSync(path, { withFileTypes: true }).flatMap((entry) =>
      entry.isDirectory() ? visit(join(path, entry.name)) : [join(path, entry.name)],
    );
  }
  for (const path of visit(join(root, 'src')).filter((path) => /\.[jt]sx?$/.test(path))) {
    const source = readFileSync(path, 'utf8');
    assert.doesNotMatch(
      source,
      /import\s+\*\s+as\s+\w+\s+from\s+['"](?:lucide-react|react-bits)/,
      path,
    );
    assert.doesNotMatch(source, /dangerouslySetInnerHTML|<iframe\b/, path);
  }
});

test('scene cards use intent prefetch without eagerly loading every editor', () => {
  for (const file of [
    'landing/LandingPage.tsx',
    'workspace/SceneCarousel.tsx',
    'commerce/CommerceCatalogue.tsx',
  ]) {
    const source = readFileSync(join(root, 'src/components', file), 'utf8');
    assert.match(source, /import \{ IntentLink \} from ['"]@\/components\/IntentLink['"]/, file);
    assert.doesNotMatch(source, /prefetch=\{false\}/, file);
    assert.match(source, /(?:<IntentLink|as=\{IntentLink\})/, file);
  }
});

test('initial stylesheet request gate detects local and remote links and keeps inline CSS in HTML budget', () => {
  const sample = fixture();
  try {
    writeFileSync(
      join(sample.directory, 'index.html'),
      '<style>body{color:red}</style><link rel="stylesheet" href="/_next/static/main.css"><link rel="stylesheet" href="https://example.test/style.css">',
    );
    const report = analyzeExport(sample.directory);
    const home = report.routes.find((route) => route.route === '/');
    assert.equal(home.initialStylesheetRequests, 2);
    assert.ok(
      inspectBudget(report, { maxInitialStylesheetRequests: 0 }).some((line) =>
        line.includes('/ initial stylesheet requests 2'),
      ),
    );
    assert.ok(
      inspectBudget(report, { maxInitialHtmlGzipBytes: 1 }).some((line) =>
        line.includes('/ initial HTML'),
      ),
    );
    writeFileSync(join(sample.directory, 'index.html'), '<style>body{color:red}</style>');
    assert.equal(
      analyzeExport(sample.directory).routes.find((route) => route.route === '/')
        .initialStylesheetRequests,
      0,
    );
  } finally {
    sample.clean();
  }
});
