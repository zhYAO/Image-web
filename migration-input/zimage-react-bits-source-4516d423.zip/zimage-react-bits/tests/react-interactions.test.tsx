import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';

const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'https://zimage.test',
  pretendToBeVisual: true,
});
for (const key of [
  'window',
  'document',
  'navigator',
  'HTMLElement',
  'HTMLInputElement',
  'HTMLDialogElement',
  'Element',
  'Node',
  'File',
  'FileList',
  'Event',
  'MouseEvent',
  'KeyboardEvent',
  'MutationObserver',
]) {
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
}
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
Object.defineProperty(dom.window, 'matchMedia', {
  value: () => ({ matches: false, media: '', addEventListener() {}, removeEventListener() {} }),
});
const { render, fireEvent, cleanup, waitFor } = await import('@testing-library/react');
const { AppProvider, usePreview, usePreviewComposer, usePreviewSessions, usePreviewNotify } =
  await import('../src/components/AppProvider');
const { Glass } = await import('../src/components/Glass');
afterEach(() => cleanup());

function Probe() {
  const state = usePreview();
  return (
    <>
      <output data-testid="mode">{state.mode}</output>
      <input
        aria-label="chat draft"
        value={state.chatDraft}
        onChange={(event) => state.setChatDraft(event.target.value)}
      />
      <input
        aria-label="image draft"
        value={state.imageDraft}
        onChange={(event) => state.setImageDraft(event.target.value)}
      />
      <button onClick={() => state.setMode((current) => (current === 'chat' ? 'image' : 'chat'))}>
        switch
      </button>
      <button
        onClick={() => {
          const id = state.createSession();
          state.appendMessage(id, { role: 'user', text: 'First idea' });
        }}
      >
        send
      </button>
      <button onClick={() => state.activeSessionId && state.deleteSession(state.activeSessionId)}>
        delete active
      </button>
      <input
        type="file"
        aria-label="reference"
        multiple
        onChange={(event) => state.addReferences(event.target.files || [])}
      />
      <button onClick={() => state.references[0] && state.removeReference(state.references[0].id)}>
        remove reference
      </button>
      <output data-testid="reference-count">{state.references.length}</output>
      <output data-testid="active-session">
        {state.sessions
          .find((session) => session.id === state.activeSessionId)
          ?.messages.map((message) => message.text)
          .join('|') || 'none'}
      </output>
    </>
  );
}

test('real React provider keeps drafts distinct and atomically records the first session message', () => {
  const view = render(
    <AppProvider>
      <Probe />
    </AppProvider>,
  );
  fireEvent.change(view.getByLabelText('chat draft'), { target: { value: 'chat idea' } });
  fireEvent.change(view.getByLabelText('image draft'), { target: { value: 'image idea' } });
  fireEvent.click(view.getByText('switch'));
  assert.equal(view.getByTestId('mode').textContent, 'image');
  assert.equal((view.getByLabelText('chat draft') as HTMLInputElement).value, 'chat idea');
  assert.equal((view.getByLabelText('image draft') as HTMLInputElement).value, 'image idea');
  fireEvent.click(view.getByText('send'));
  assert.equal(view.getByTestId('active-session').textContent, 'First idea');
  fireEvent.click(view.getByText('delete active'));
  assert.equal(view.getByTestId('active-session').textContent, 'none');
});

test('reference limits and object URL ownership survive mode changes and teardown', () => {
  let count = 0;
  const revoked: string[] = [];
  const originalCreate = URL.createObjectURL,
    originalRevoke = URL.revokeObjectURL;
  URL.createObjectURL = () => `blob:test-${++count}`;
  URL.revokeObjectURL = (value) => {
    revoked.push(value);
  };
  try {
    const view = render(
      <AppProvider>
        <Probe />
      </AppProvider>,
    );
    const files = Array.from(
      { length: 5 },
      (_, index) => new File(['png'], `${index}.png`, { type: 'image/png' }),
    );
    fireEvent.change(view.getByLabelText('reference'), { target: { files } });
    assert.equal(view.getByTestId('reference-count').textContent, '4');
    fireEvent.click(view.getByText('switch'));
    assert.equal(view.getByTestId('reference-count').textContent, '4');
    fireEvent.click(view.getByText('remove reference'));
    assert.deepEqual(revoked, ['blob:test-1']);
    view.unmount();
    assert.deepEqual(revoked, ['blob:test-1', 'blob:test-2', 'blob:test-3', 'blob:test-4']);
  } finally {
    URL.createObjectURL = originalCreate;
    URL.revokeObjectURL = originalRevoke;
  }
});

test('React Glass retains semantic elements and stable child nodes during rerenders', () => {
  const view = render(
    <Glass as="section" aria-label="Material" className="test-glass">
      <input aria-label="retained input" defaultValue="keep" />
    </Glass>,
  );
  const section = view.getByLabelText('Material'),
    input = view.getByLabelText('retained input');
  assert.equal(section.tagName, 'SECTION');
  assert.ok(section.classList.contains('liquid-glass'));
  view.rerender(
    <Glass as="section" aria-label="Material" className="new-class">
      <input aria-label="retained input" defaultValue="keep" />
    </Glass>,
  );
  assert.equal(view.getByLabelText('retained input'), input);
});

test('typing a composer draft does not rerender session or notification-only consumers', () => {
  let sessionRenders = 0,
    notifyRenders = 0;
  function Sessions() {
    sessionRenders++;
    const state = usePreviewSessions();
    return <span>{state.sessions.length}</span>;
  }
  function Notices() {
    notifyRenders++;
    const notify = usePreviewNotify();
    return <button onClick={() => notify('test')}>notify only</button>;
  }
  function Composer() {
    const state = usePreviewComposer();
    return (
      <input
        aria-label="narrow draft"
        value={state.chatDraft}
        onChange={(event) => state.setChatDraft(event.target.value)}
      />
    );
  }
  const view = render(
    <AppProvider>
      <Sessions />
      <Notices />
      <Composer />
    </AppProvider>,
  );
  const before = [sessionRenders, notifyRenders];
  fireEvent.change(view.getByLabelText('narrow draft'), { target: { value: 'a' } });
  fireEvent.change(view.getByLabelText('narrow draft'), { target: { value: 'a new idea' } });
  assert.deepEqual([sessionRenders, notifyRenders], before);
});

test('Glass preserves React 19 callback-ref cleanup on unmount', () => {
  let released = 0;
  const view = render(
    <Glass
      ref={(node) => {
        assert.ok(node instanceof HTMLElement);
        return () => {
          released++;
        };
      }}
    />,
  );
  view.unmount();
  assert.equal(released, 1);
});

test('Glass keeps refraction and child identity after class changes, without work on ordinary rerenders', async () => {
  const oldCSS = Object.getOwnPropertyDescriptor(dom.window, 'CSS');
  const oldWidth = Object.getOwnPropertyDescriptor(dom.window.HTMLElement.prototype, 'offsetWidth');
  const oldHeight = Object.getOwnPropertyDescriptor(
    dom.window.HTMLElement.prototype,
    'offsetHeight',
  );
  Object.defineProperty(dom.window, 'CSS', { configurable: true, value: { supports: () => true } });
  Object.defineProperty(dom.window.HTMLElement.prototype, 'offsetWidth', {
    configurable: true,
    get: () => 400,
  });
  Object.defineProperty(dom.window.HTMLElement.prototype, 'offsetHeight', {
    configurable: true,
    get: () => 60,
  });
  try {
    const view = render(
      <Glass refract className="nav" aria-label="Nav">
        <input aria-label="Stable glass child" />
      </Glass>,
    );
    const host = view.getByLabelText('Nav');
    const child = view.getByLabelText('Stable glass child');
    await waitFor(() => assert.ok(host.classList.contains('is-liquid-refracted')));
    const filter = document.querySelector('.liquid-glass-defs filter');
    view.rerender(
      <Glass refract className="nav" aria-label="Nav">
        <input aria-label="Stable glass child" />
      </Glass>,
    );
    assert.equal(document.querySelector('.liquid-glass-defs filter'), filter);
    view.rerender(
      <Glass refract className="nav is-open" aria-label="Nav">
        <input aria-label="Stable glass child" />
      </Glass>,
    );
    await waitFor(() => assert.ok(host.classList.contains('is-liquid-refracted')));
    assert.equal(view.getByLabelText('Stable glass child'), child);
    assert.equal(document.querySelectorAll('.liquid-glass-defs filter').length, 1);
    view.unmount();
    assert.equal(document.querySelectorAll('.liquid-glass-defs filter').length, 0);
  } finally {
    cleanup();
    if (oldCSS) Object.defineProperty(dom.window, 'CSS', oldCSS);
    else Reflect.deleteProperty(dom.window, 'CSS');
    if (oldWidth) Object.defineProperty(dom.window.HTMLElement.prototype, 'offsetWidth', oldWidth);
    if (oldHeight)
      Object.defineProperty(dom.window.HTMLElement.prototype, 'offsetHeight', oldHeight);
  }
});
