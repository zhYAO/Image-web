import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';
const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'https://zimage.test/create/product-set',
  pretendToBeVisual: true,
});
for (const key of [
  'window',
  'self',
  'document',
  'navigator',
  'HTMLElement',
  'HTMLInputElement',
  'HTMLDialogElement',
  'Element',
  'Node',
  'File',
  'FileList',
  'Event',
  'MouseEvent',
  'KeyboardEvent',
  'MutationObserver',
  'localStorage',
])
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
Object.defineProperty(window, 'matchMedia', {
  value: () => ({ matches: false, media: '', addEventListener() {}, removeEventListener() {} }),
});
Object.defineProperty(globalThis, 'getComputedStyle', {
  value: window.getComputedStyle.bind(window),
});
HTMLElement.prototype.scrollIntoView = function () {};
HTMLDialogElement.prototype.showModal = function () {
  this.setAttribute('open', '');
};
HTMLDialogElement.prototype.close = function () {
  this.removeAttribute('open');
};
class Resize {
  static created = 0;
  static disconnected = 0;
  constructor() {
    Resize.created++;
  }
  observe() {}
  disconnect() {
    Resize.disconnected++;
  }
}
Object.defineProperty(globalThis, 'ResizeObserver', { value: Resize });
let ratio = 0.75;
class TestImage {
  onload: (() => void) | null = null;
  onerror: (() => void) | null = null;
  naturalWidth = 750;
  naturalHeight = 1000;
  set src(_value: string) {
    this.naturalWidth = ratio * 1000;
    queueMicrotask(() => this.onload?.());
  }
}
Object.defineProperty(window, 'Image', { configurable: true, value: TestImage });
let sequence = 0;
const revoked: string[] = [];
URL.createObjectURL = () => `blob:commerce-${++sequence}`;
URL.revokeObjectURL = (url) => {
  revoked.push(url);
};
const { render, fireEvent, cleanup, act, waitFor, within } = await import('@testing-library/react');
const { AppRouterContext } =
  await import('next/dist/shared/lib/app-router-context.shared-runtime.js');
const { AppProvider } = await import('../src/components/AppProvider');
const { CommerceEditor } = await import('../src/components/commerce/CommerceEditor');
const { scenes } = await import('../src/components/commerce/commerce-data');
const routes: string[] = [];
const router = {
  back() {},
  forward() {},
  refresh() {},
  hmrRefresh() {},
  push(path: string) {
    routes.push(path);
  },
  replace() {},
  prefetch: async () => {},
};
function editor(id: string) {
  return render(
    <AppRouterContext.Provider value={router}>
      <AppProvider>
        <CommerceEditor scene={scenes.find((scene) => scene.id === id)!} />
      </AppProvider>
    </AppRouterContext.Provider>,
  );
}
function jpeg(name = 'product.jpg') {
  return new File(['jpeg'], name, { type: 'image/jpeg' });
}
async function upload(view: ReturnType<typeof render>, label: string, files: File[]) {
  await act(async () => {
    fireEvent.change(view.getByLabelText(label, { selector: 'input' }), { target: { files } });
    await new Promise((resolve) => setTimeout(resolve, 0));
  });
}
async function delay(ms: number) {
  await act(async () => {
    await new Promise((resolve) => setTimeout(resolve, ms));
  });
}
afterEach(() => {
  cleanup();
  localStorage.clear();
  ratio = 0.75;
  revoked.length = 0;
  routes.length = 0;
});

test('invalid stored draft cannot crash the editor or inject markup into a controlled field', () => {
  localStorage.setItem(
    'zimage-commerce-draft:product-set',
    JSON.stringify({
      modules: null,
      counts: null,
      description: '<img src=x onerror=alert(1)>',
      listing: { title: { invalid: true } },
      count: 999,
    }),
  );
  const view = editor('product-set');
  assert.equal(
    (view.getByLabelText('商品描述') as HTMLTextAreaElement).value,
    '<img src=x onerror=alert(1)>',
  );
  assert.equal(view.container.querySelector('img[src="x"]'), null);
  assert.ok(view.getByText('7 张图片'));
  assert.equal((view.getByLabelText('标题') as HTMLTextAreaElement).value, '');
});

test('saved review draft restores editable configuration with an accessible product uploader', () => {
  localStorage.setItem(
    'zimage-commerce-draft:detail',
    JSON.stringify({
      stage: 'review',
      modules: ['品牌故事', '核心卖点', '品牌故事'],
      copy: { 品牌故事: '保留文案' },
      references: [{ url: 'blob:stale' }],
    }),
  );
  const view = editor('detail');
  assert.ok(view.getByLabelText('商品原图', { selector: 'input' }));
  assert.equal((view.getByLabelText('品牌故事') as HTMLInputElement).checked, true);
  assert.ok(view.getByText('已选 2 项'));
  assert.equal(view.container.querySelector('img[src="blob:stale"]'), null);
});

test('real commerce upload validates duplicates and releases object URLs on remove and unmount', async () => {
  const view = editor('product-set');
  assert.equal(
    (view.getByRole('button', { name: '请上传产品图' }) as HTMLButtonElement).disabled,
    true,
  );
  await upload(view, '商品原图', [jpeg()]);
  assert.equal(
    (view.getByRole('button', { name: '一键生成 7 张' }) as HTMLButtonElement).disabled,
    false,
  );
  await upload(view, '商品原图', [jpeg()]);
  assert.match(view.getByRole('alert').textContent!, /重复/);
  assert.equal(view.container.querySelectorAll('.cm-upload-thumb').length, 1);
  fireEvent.click(view.getByRole('button', { name: '移除 product.jpg' }));
  assert.equal(revoked.length, 1);
  await upload(view, '商品原图', [jpeg('second.jpg')]);
  view.unmount();
  assert.equal(revoked.length, 2);
});

test('A+ review retains edited copy when button and drag reorder change the module order', async () => {
  const view = editor('detail');
  fireEvent.click(view.getByLabelText('品牌故事'));
  await upload(view, '商品原图', [jpeg()]);
  fireEvent.click(view.getByRole('button', { name: '下一步：确认模块内容（7项）' }));
  fireEvent.change(view.getByLabelText('品牌首屏文案'), { target: { value: '独立的品牌文案' } });
  fireEvent.click(view.getByRole('button', { name: '下移品牌首屏' }));
  const modules = () => Array.from(view.container.querySelectorAll('.cm-module-edit'));
  assert.match(modules()[0].textContent!, /核心卖点/);
  assert.equal(
    (view.getByLabelText('品牌首屏文案') as HTMLTextAreaElement).value,
    '独立的品牌文案',
  );
  const dataTransfer = { effectAllowed: '', setData() {} };
  fireEvent.dragStart(modules()[0], { dataTransfer });
  fireEvent.dragOver(modules()[2], { dataTransfer });
  fireEvent.drop(modules()[2], { dataTransfer });
  assert.match(modules()[2].textContent!, /核心卖点/);
  fireEvent.click(view.getByRole('button', { name: 'AI帮写' }));
  assert.match((view.getByLabelText('视觉策略') as HTMLTextAreaElement).value, /统一色调/);
  fireEvent.click(view.getByRole('button', { name: '上一步' }));
  assert.ok(view.getByLabelText('品牌故事'));
});

test('result generation is local and regeneration changes only the selected card', async () => {
  const view = editor('product-set');
  await upload(view, '商品原图', [jpeg()]);
  fireEvent.click(view.getByRole('button', { name: '一键生成 7 张' }));
  assert.equal(
    (view.getByRole('button', { name: '正在准备…' }) as HTMLButtonElement).disabled,
    true,
  );
  await delay(1450);
  await waitFor(() => assert.equal(view.container.querySelectorAll('.cm-result-card').length, 7));
  const cards = Array.from(view.container.querySelectorAll('.cm-result-card'));
  const firstImage = cards[0].querySelector('img')!;
  const oldSrc = firstImage.getAttribute('src');
  const secondImage = cards[1].querySelector('img');
  fireEvent.click(within(cards[0] as HTMLElement).getByRole('button', { name: '重新生成' }));
  assert.equal(cards[0].getAttribute('aria-busy'), 'true');
  assert.equal(cards[1].getAttribute('aria-busy'), 'false');
  assert.equal(cards[1].querySelector('img'), secondImage);
  await delay(900);
  assert.equal(cards[0].getAttribute('aria-busy'), 'false');
  assert.notEqual(firstImage.getAttribute('src'), oldSrc);
  assert.match(cards[0].textContent!, /v2/);
  fireEvent.click(view.getByRole('button', { name: '查看示例' }));
  assert.equal(view.container.querySelectorAll('.cm-result-card').length, 0);
  fireEvent.click(view.getByRole('button', { name: '查看结果' }));
  assert.equal(view.container.querySelectorAll('.cm-result-card').length, 7);
});

test('typing preserves example DOM and does not recreate its measurement observer', () => {
  const view = editor('product-set');
  const images = Array.from(view.container.querySelectorAll('.cm-preview-panel img'));
  const observers = Resize.created;
  const input = view.getByLabelText('商品描述');
  fireEvent.change(input, { target: { value: '皮革耳机' } });
  fireEvent.change(input, { target: { value: '皮革耳机，柔软头梁' } });
  assert.deepEqual(Array.from(view.container.querySelectorAll('.cm-preview-panel img')), images);
  assert.equal(view.getByLabelText('商品描述'), input);
  assert.equal(Resize.created, observers);
});

test('dropdown supports keyboard selection, own scrolling and Escape focus restoration', () => {
  const view = editor('product-main');
  const combo = view.getByRole('combobox', { name: '画面比例 1:1' });
  fireEvent.click(combo);
  const listbox = view.getByRole('listbox', { name: '画面比例' });
  fireEvent.scroll(listbox);
  assert.ok(view.getByRole('listbox'));
  fireEvent.keyDown(listbox, { key: 'ArrowDown' });
  fireEvent.keyDown(listbox, { key: 'Enter' });
  assert.match(combo.textContent!, /3:4/);
  assert.equal(view.queryByRole('listbox'), null);
  fireEvent.click(combo);
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'Escape' });
  assert.equal(document.activeElement, combo);
});

test('layout dialog remains open when Escape dismisses an inner dropdown', async () => {
  const view = editor('product-set');
  view.getByRole('button', { name: '选择卖点图版式参考' }).focus();
  fireEvent.click(view.getByRole('button', { name: '选择卖点图版式参考' }));
  const dialog = await view.findByRole('dialog', { name: '选择卖点图版式参考' });
  fireEvent.click(within(dialog).getByRole('combobox', { name: '卖点图 1 自动分配' }));
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'Escape' });
  assert.ok(view.getByRole('dialog'));
  fireEvent.click(within(dialog).getByRole('button', { name: '完成' }));
  assert.equal(view.queryByRole('dialog'), null);
  assert.equal(document.activeElement, view.getByRole('button', { name: '选择卖点图版式参考' }));
});

test('A+ output guidance follows the selected mode without conflicting generic resolution', () => {
  const view = editor('detail');
  const output = view.getByRole('combobox', { name: '输出规格 普通 A+ · 970 × 600' });
  assert.match(view.getByText(/配置输出尺寸/).textContent!, /970 × 600 px/);
  assert.equal(view.queryByRole('combobox', { name: /^分辨率/ }), null);
  assert.ok(view.getByText(/示例缩略图不代表输出尺寸/));
  fireEvent.click(output);
  fireEvent.click(view.getByRole('option', { name: '高级 A+ · 桌面 + 移动' }));
  assert.equal(view.queryByText(/配置输出尺寸/), null);
  assert.match(view.getByText(/配置输出比例/).textContent!, /桌面 16:9 · 移动 4:3/);
  assert.ok(view.getByText(/像素尺寸待接入服务后确认/));
  assert.ok(view.getByText(/示例缩略图不代表输出尺寸/));
  fireEvent.click(output);
  fireEvent.click(view.getByRole('option', { name: '普通 A+ · 970 × 600' }));
  assert.ok(view.getByText(/配置输出尺寸/));
  assert.equal(view.queryByText(/配置输出比例/), null);
});

test('apparel requires five 3:4 JPEGs, display photos, PNG logo and required fields', async () => {
  const view = editor('apparel-catalog');
  fireEvent.click(view.getByRole('button', { name: '保存整套方案' }));
  assert.match(view.getByRole('alert').textContent!, /主图 1/);
  ratio = 1;
  await upload(view, '主图 1', [jpeg('wrong.jpg')]);
  assert.match(view.getByRole('alert').textContent!, /3:4/);
  ratio = 0.75;
  for (let i = 1; i <= 5; i++) await upload(view, `主图 ${i}`, [jpeg(`main-${i}.jpg`)]);
  await upload(view, '展示照片', [jpeg('display-10.jpg'), jpeg('display-2.jpg')]);
  await upload(view, '透明 PNG Logo', [new File(['png'], 'logo.png', { type: 'image/png' })]);
  fireEvent.click(view.getByRole('button', { name: '保存整套方案' }));
  assert.match(view.getByRole('alert').textContent!, /商品名称/);
  for (const label of [
    '商品名称',
    '颜色',
    '面料成分',
    '洗涤方式',
    '上架尺码',
    '体重推荐',
    'Design',
    'Fabric',
    '衣长',
    '胸围',
    '肩宽',
    '袖长',
  ])
    fireEvent.change(view.getByLabelText(label), { target: { value: '确认资料' } });
  fireEvent.click(view.getByRole('button', { name: '保存整套方案' }));
  assert.ok(view.getByRole('button', { name: '开始整套排版' }));
  assert.match(view.container.querySelector('.cm-preview-toolbar')!.textContent!, /方案 v1/);
  const display = view.getByText('展示照片').closest('.cm-upload-group')!;
  assert.equal(display.querySelector('img')!.alt, 'display-2.jpg');
  fireEvent.change(view.getByLabelText('颜色'), { target: { value: '藏青' } });
  assert.equal(view.queryByRole('button', { name: '开始整套排版' }), null);
});

test('every commerce scene exposes an image model selector and product draft restores its choice', () => {
  for (const scene of scenes) {
    const view = editor(scene.id);
    const combo = view.getByRole('combobox', { name: /^图片模型 / });
    assert.match(view.container.textContent || '', /模型选择仅用于本地设置/);
    fireEvent.click(combo);
    const options = view.getAllByRole('option');
    assert.ok(options.length >= 2);
    const selectedText = options[1].textContent;
    fireEvent.click(options[1]);
    assert.equal(combo.textContent, selectedText);
    if (scene.id === 'product-set') {
      fireEvent.click(view.getByRole('button', { name: '保存草稿' }));
      view.unmount();
      const restored = editor(scene.id);
      assert.equal(
        restored.getByRole('combobox', { name: /^图片模型 / }).textContent,
        selectedText,
      );
      restored.unmount();
    } else view.unmount();
  }
});
