import test from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Glass } from '../src/components/Glass';

test('Glass restores CSS frosting by default without a decorative child rim', () => {
  const html = renderToStaticMarkup(
    <Glass as="section" aria-label="Glass" style={{ opacity: 0.9 }}>
      <input aria-label="Child" />
    </Glass>,
  );
  assert.match(html, /^<section/);
  assert.doesNotMatch(html, /data-liquid-glass="refract"|glass-surface__rim|--glass-frost/);
  assert.match(html, /opacity:0.9/);
  assert.match(html, /<input aria-label="Child"/);
});

test('Glass requires explicit opt-in for the restrained refraction enhancement', () => {
  assert.match(renderToStaticMarkup(<Glass refract />), /data-liquid-glass="refract"/);
  assert.doesNotMatch(
    renderToStaticMarkup(<Glass refract={false} />),
    /data-liquid-glass="refract"/,
  );
});
