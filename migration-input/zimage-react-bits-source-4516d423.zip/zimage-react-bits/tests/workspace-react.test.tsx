import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { JSDOM } from 'jsdom';
import React from 'react';

registerHooks({
  load(url, context, next) {
    if (url.endsWith('.css'))
      return {
        format: 'module',
        source: 'export default new Proxy({}, {get:(_, name)=>String(name)})',
        shortCircuit: true,
      };
    return next(url, context);
  },
});
const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'https://zimage.test/workspace',
  pretendToBeVisual: true,
});
for (const key of [
  'window',
  'self',
  'document',
  'navigator',
  'HTMLElement',
  'HTMLInputElement',
  'HTMLDialogElement',
  'Element',
  'Node',
  'File',
  'FileList',
  'Event',
  'MouseEvent',
  'KeyboardEvent',
  'MutationObserver',
  'localStorage',
])
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
class ResizeObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
}
Object.defineProperty(globalThis, 'ResizeObserver', {
  configurable: true,
  value: ResizeObserverStub,
  writable: true,
});
Object.defineProperty(dom.window, 'matchMedia', {
  configurable: true,
  writable: true,
  value: (query: string) => ({
    matches: query.includes('prefers-reduced-motion'),
    media: query,
    addEventListener() {},
    removeEventListener() {},
  }),
});
dom.window.HTMLElement.prototype.scrollIntoView = function () {};
dom.window.HTMLElement.prototype.scrollTo = function () {};
globalThis.requestAnimationFrame = dom.window.requestAnimationFrame.bind(dom.window);
globalThis.cancelAnimationFrame = dom.window.cancelAnimationFrame.bind(dom.window);
const { render, fireEvent, cleanup, act } = await import('@testing-library/react');
const { AppRouterContext } =
  await import('next/dist/shared/lib/app-router-context.shared-runtime.js');
const { AppProvider } = await import('../src/components/AppProvider');
const { WorkspacePage } = await import('../src/components/workspace/WorkspacePage');
const { CommerceLayout } = await import('../src/components/commerce/CommerceLayout');
const { default: CataloguePage } = await import('../src/app/create/page');
const { PathnameContext } =
  await import('next/dist/shared/lib/hooks-client-context.shared-runtime.js');
const { AnchoredPopover } = await import('../src/components/workspace/AnchoredPopover');
const { SceneCarousel } = await import('../src/components/workspace/SceneCarousel');
const pushes: string[] = [];
const router = {
  push: (url: string) => {
    pushes.push(url);
  },
  replace() {},
  refresh() {},
  back() {},
  forward() {},
  prefetch: async () => {},
  hmrRefresh() {},
};
function mountWorkspace() {
  return render(
    <AppRouterContext.Provider value={router}>
      <AppProvider>
        <WorkspacePage />
      </AppProvider>
    </AppRouterContext.Provider>,
  );
}
afterEach(() => {
  cleanup();
  dom.window.localStorage.clear();
  pushes.length = 0;
});

test('workspace records a user message, keeps composer mounted, and labels the simulated AI truthfully', () => {
  const view = mountWorkspace();
  assert.equal(
    view.getByRole('heading', { name: '你好，想创作什么？' }).textContent,
    '你好，想创作什么？',
  );
  const input = view.getByLabelText('创作输入') as HTMLTextAreaElement;
  const fiberHost = view.container.querySelector('[data-focused]');
  fireEvent.focus(input);
  assert.equal(fiberHost?.getAttribute('data-focused'), 'true');
  fireEvent.blur(input);
  assert.equal(fiberHost?.getAttribute('data-focused'), 'false');
  assert.equal(view.getByLabelText('创作输入'), input, 'focus decoration preserves the input');
  fireEvent.change(input, { target: { value: '柔和自然光中的陶瓷杯' } });
  fireEvent.click(view.getByRole('button', { name: '发送创作请求' }));
  assert.equal(
    view.getByLabelText('创作输入'),
    input,
    'composer input survives first-send transition',
  );
  assert.equal(input.value, '');
  const timeline = view.getByRole('log', { name: '对话时间线' });
  assert.equal(
    timeline.querySelectorAll('article').length,
    2,
    'user and explicitly labeled simulation',
  );
  assert.match(timeline.textContent || '', /模拟 AI · 本地演示，未连接模型/);
  assert.equal(timeline.getAttribute('aria-live'), 'off');
  assert.ok(view.getByRole('button', { name: '停止模拟回复' }));
  assert.match(timeline.textContent || '', /柔和自然光中的陶瓷杯/);
  assert.match(view.getByRole('status').textContent || '', /未调用真实模型/);
  assert.equal(view.queryByRole('heading', { name: '你好，想创作什么？' }), null);
});

test('workspace mode toggles keep two drafts and a single reference while chat hides reference controls', () => {
  let objectId = 0;
  const revoke: string[] = [];
  const originalCreate = URL.createObjectURL,
    originalRevoke = URL.revokeObjectURL;
  URL.createObjectURL = () => `blob:workspace-${++objectId}`;
  URL.revokeObjectURL = (url) => {
    revoke.push(url);
  };
  try {
    const view = mountWorkspace();
    const input = view.getByLabelText('创作输入') as HTMLTextAreaElement;
    fireEvent.change(input, { target: { value: '对话草稿' } });
    fireEvent.click(view.getByRole('button', { name: '创建图片' }));
    assert.equal(input.value, '');
    fireEvent.change(input, { target: { value: '图片草稿' } });
    fireEvent.change(view.getByLabelText('上传参考图'), {
      target: { files: [new File(['image'], 'cup.png', { type: 'image/png' })] },
    });
    assert.ok(view.getByRole('button', { name: '查看参考图 cup.png' }));
    fireEvent.click(view.getByRole('button', { name: '创建图片' }));
    assert.equal(input.value, '对话草稿');
    assert.equal(view.queryByRole('button', { name: '查看参考图 cup.png' }) === null, true);
    assert.deepEqual(revoke, []);
    fireEvent.click(view.getByRole('button', { name: '创建图片' }));
    assert.equal(input.value, '图片草稿');
    assert.ok(view.getByRole('button', { name: '查看参考图 cup.png' }));
    fireEvent.click(view.getByRole('button', { name: '发送创作请求' }));
    assert.ok(
      view.getByRole('button', { name: '查看参考图 cup.png' }),
      'recording a local message retains the reference',
    );
    assert.match(view.getByRole('status').textContent || '', /图片生成服务暂不可用/);
    view.unmount();
    assert.deepEqual(revoke, ['blob:workspace-1']);
  } finally {
    URL.createObjectURL = originalCreate;
    URL.revokeObjectURL = originalRevoke;
  }
});

test('sidebar keeps 24 fixture sessions, supports compact rename/delete confirmation and category filters', () => {
  const view = mountWorkspace();
  const list = view.getByRole('region', { name: '会话列表' });
  assert.equal(list.querySelectorAll('button[aria-current], button.sessionMain').length, 24);
  fireEvent.click(view.getByRole('button', { name: '重命名 光影与材质练习' }));
  fireEvent.change(view.getByLabelText('会话名称'), { target: { value: '新的会话名称' } });
  fireEvent.click(view.getByRole('button', { name: '保存', exact: true }));
  assert.ok(view.getByRole('button', { name: '新的会话名称', exact: true }));
  fireEvent.click(view.getByRole('button', { name: '删除 新的会话名称' }));
  fireEvent.click(view.getByRole('button', { name: '取消', exact: true }));
  assert.ok(view.getByRole('button', { name: '新的会话名称', exact: true }));
  fireEvent.click(view.getByRole('button', { name: '删除 新的会话名称' }));
  fireEvent.click(view.getByRole('button', { name: '删除', exact: true }));
  assert.equal(view.queryByRole('button', { name: '新的会话名称', exact: true }) === null, true);
  fireEvent.click(view.getByRole('button', { name: '电商生图', exact: true }));
  assert.equal(list.querySelectorAll('.sessionItem:not([hidden]) button.sessionMain').length, 8);
  fireEvent.click(view.getByRole('button', { name: '商品套图创作', exact: true }));
  assert.equal(pushes.at(-1), '/workspace');
  assert.ok(view.getByRole('log', { name: '对话时间线' }));
});

test('collapsed sidebar tooltips dismiss with Escape and restore after hover', () => {
  const view = mountWorkspace();
  fireEvent.click(view.getByRole('button', { name: '折叠会话侧栏' }));
  const newConversation = view.getByRole('button', { name: '新对话' });
  fireEvent.mouseEnter(newConversation);
  assert.equal(view.getByRole('tooltip').textContent, '新对话');
  fireEvent.keyDown(document, { key: 'Escape' });
  assert.equal(view.queryByRole('tooltip') === null, true);
  fireEvent.mouseLeave(newConversation);
  fireEvent.mouseEnter(newConversation);
  assert.equal(view.getByRole('tooltip').textContent, '新对话');
});

test('carousel shows three desktop scenes and keyboard navigation updates link focusability', () => {
  const view = render(<SceneCarousel />);
  const region = view.getByRole('region', { name: '电商生图' });
  assert.equal(view.getAllByRole('link').length, 3);
  assert.equal(
    (view.getByRole('button', { name: '上一组创作场景' }) as HTMLButtonElement).disabled,
    true,
  );
  fireEvent.keyDown(region, { key: 'End' });
  assert.equal(
    (view.getByRole('button', { name: '下一组创作场景' }) as HTMLButtonElement).disabled,
    true,
  );
  assert.equal(view.getAllByRole('link')[2].getAttribute('href'), '/create/apparel-catalog');
  fireEvent.keyDown(region, { key: 'Home' });
  assert.equal(view.getAllByRole('link')[0].getAttribute('href'), '/create/product-set');
});

test('first send animates welcome before revealing the timeline without replacing the composer', async () => {
  const original = dom.window.matchMedia;
  dom.window.matchMedia = (query: string) =>
    ({
      matches: false,
      media: query,
      addEventListener() {},
      removeEventListener() {},
    }) as MediaQueryList;
  try {
    const view = mountWorkspace();
    const input = view.getByLabelText('创作输入') as HTMLTextAreaElement;
    fireEvent.change(input, { target: { value: '第一条创作想法' } });
    fireEvent.click(view.getByRole('button', { name: '发送创作请求' }));
    assert.ok(view.getByRole('heading', { name: '你好，想创作什么？' }));
    assert.equal(view.queryByRole('log', { name: '对话时间线' }) === null, true);
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 220));
    });
    assert.ok(view.getByRole('log', { name: '对话时间线' }));
    assert.equal(view.getByLabelText('创作输入') === input, true);
  } finally {
    dom.window.matchMedia = original;
  }
});

test('carousel autoplay sleeps outside the viewport and resumes when visible', (context) => {
  context.mock.timers.enable({ apis: ['setTimeout'] });
  const original = dom.window.matchMedia;
  const originalObserver = globalThis.IntersectionObserver;
  const observers: {
    callback: IntersectionObserverCallback;
    target?: Element;
    disconnected: boolean;
  }[] = [];
  class Observer {
    state: (typeof observers)[number];
    constructor(callback: IntersectionObserverCallback) {
      this.state = { callback, disconnected: false };
      observers.push(this.state);
    }
    observe(target: Element) {
      this.state.target = target;
    }
    unobserve() {}
    disconnect() {
      this.state.disconnected = true;
    }
  }
  Object.defineProperty(globalThis, 'IntersectionObserver', {
    configurable: true,
    value: Observer,
  });
  dom.window.matchMedia = (query: string) =>
    ({
      matches: false,
      media: query,
      addEventListener() {},
      removeEventListener() {},
    }) as MediaQueryList;
  try {
    const view = render(<SceneCarousel />);
    const observer = observers.find((item) => item.target?.classList.contains('carouselViewport'))!;
    assert.ok(observer);
    act(() => context.mock.timers.tick(6500));
    assert.equal(view.getAllByRole('link')[0].getAttribute('href'), '/create/product-set');
    act(() =>
      observer.callback(
        [{ isIntersecting: true } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      ),
    );
    act(() => context.mock.timers.tick(6000));
    assert.equal(view.getAllByRole('link')[0].getAttribute('href'), '/create/clone');
    act(() =>
      observer.callback(
        [{ isIntersecting: false } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      ),
    );
    act(() => context.mock.timers.tick(12000));
    assert.equal(view.getAllByRole('link')[0].getAttribute('href'), '/create/clone');
    view.unmount();
    assert.equal(observer.disconnected, true);
  } finally {
    dom.window.matchMedia = original;
    Object.defineProperty(globalThis, 'IntersectionObserver', {
      configurable: true,
      value: originalObserver,
    });
    context.mock.timers.reset();
  }
});

test('anchored popover dismissal reads the latest committed close callback', () => {
  const anchor = document.createElement('button');
  document.body.append(anchor);
  const calls: string[] = [];
  const view = render(
    <AnchoredPopover anchor={anchor} label="会话操作" onClose={() => calls.push('initial')}>
      <button>操作</button>
    </AnchoredPopover>,
  );
  view.rerender(
    <AnchoredPopover anchor={anchor} label="会话操作" onClose={() => calls.push('updated')}>
      <button>操作</button>
    </AnchoredPopover>,
  );
  fireEvent.keyDown(document, { key: 'Escape' });
  assert.deepEqual(calls, ['updated']);
  assert.equal(document.activeElement === anchor, true);
  view.unmount();
  anchor.remove();
});

test('renaming the current session does not scroll the conversation again', () => {
  const original = dom.window.HTMLElement.prototype.scrollIntoView;
  let scrolls = 0;
  dom.window.HTMLElement.prototype.scrollIntoView = function () {
    scrolls++;
  };
  try {
    const view = mountWorkspace();
    fireEvent.click(view.getByRole('button', { name: '光影与材质练习', exact: true }));
    const afterSelection = scrolls;
    assert.ok(afterSelection > 0);
    fireEvent.click(view.getByRole('button', { name: '重命名 光影与材质练习' }));
    fireEvent.change(view.getByLabelText('会话名称'), { target: { value: '自然光练习' } });
    fireEvent.click(view.getByRole('button', { name: '保存', exact: true }));
    assert.equal(scrolls, afterSelection);
  } finally {
    dom.window.HTMLElement.prototype.scrollIntoView = original;
  }
});

test('topbar omits the duplicate brand mark while the sidebar retains its brand', () => {
  const view = mountWorkspace();
  const header = view.container.querySelector('header')!;
  assert.equal(!!header.querySelector('.topbarSymbol'), false);
  assert.ok(view.getByRole('link', { name: 'ZImage 品牌首页' }).querySelector('svg'));
});

test('long demo conversation follows HTML document scrolling and keeps composer identity', () => {
  const originalScroll = dom.window.HTMLElement.prototype.scrollTo;
  const originalIntoView = dom.window.HTMLElement.prototype.scrollIntoView;
  const targets: HTMLElement[] = [];
  const revealed: HTMLElement[] = [];
  dom.window.HTMLElement.prototype.scrollTo = function () {
    targets.push(this);
  };
  dom.window.HTMLElement.prototype.scrollIntoView = function () {
    revealed.push(this);
  };
  try {
    const view = mountWorkspace();
    const composer = view.getByLabelText('创作输入');
    fireEvent.click(view.getByRole('button', { name: '长对话滚动示例', exact: true }));
    const timeline = view.getByRole('log', { name: '对话时间线' });
    assert.ok(timeline.querySelectorAll('article').length >= 24);
    assert.match(timeline.textContent || '', /静态示例/);
    assert.equal(view.getByLabelText('创作输入'), composer);
    assert.equal(targets.length, 0, 'the shell must not create a separate content scroller');
    assert.equal(revealed.at(-1) === timeline.lastElementChild, true);
    const message = timeline.querySelector('article');
    fireEvent.click(view.getByRole('button', { name: '折叠会话侧栏' }));
    assert.equal(timeline.querySelector('article'), message);
    assert.equal(view.getByLabelText('创作输入'), composer);
  } finally {
    dom.window.HTMLElement.prototype.scrollTo = originalScroll;
    dom.window.HTMLElement.prototype.scrollIntoView = originalIntoView;
  }
});

test('busy chat preserves the next draft, blocks Enter duplicates, and stops with accessible feedback', () => {
  const view = mountWorkspace();
  const input = view.getByLabelText('创作输入') as HTMLTextAreaElement;
  fireEvent.change(input, { target: { value: '第一条' } });
  fireEvent.click(view.getByRole('button', { name: '发送创作请求' }));
  fireEvent.change(input, { target: { value: '下一条草稿' } });
  fireEvent.keyDown(input, { key: 'Enter' });
  assert.equal(view.getByRole('log').querySelectorAll('article').length, 2);
  assert.equal(input.value, '下一条草稿');
  fireEvent.click(view.getByRole('button', { name: '停止模拟回复' }));
  assert.match(view.getByRole('status').textContent || '', /模拟回复已停止/);
  assert.ok(view.getByRole('button', { name: '发送创作请求' }));
  assert.equal(input.value, '下一条草稿');
});

test('growing output follows only while the reader stays near the document bottom', () => {
  const OriginalObserver = globalThis.ResizeObserver;
  const originalScroll = dom.window.HTMLElement.prototype.scrollIntoView;
  const resize: { target?: Element; callback: ResizeObserverCallback }[] = [];
  let scrolls = 0;
  class Observer {
    item: (typeof resize)[number];
    constructor(callback: ResizeObserverCallback) {
      this.item = { callback };
      resize.push(this.item);
    }
    observe(target: Element) {
      this.item.target = target;
    }
    unobserve() {}
    disconnect() {}
  }
  Object.defineProperty(globalThis, 'ResizeObserver', { configurable: true, value: Observer });
  dom.window.HTMLElement.prototype.scrollIntoView = () => {
    scrolls++;
  };
  Object.defineProperty(document.documentElement, 'scrollHeight', {
    configurable: true,
    value: 5000,
  });
  try {
    const view = mountWorkspace();
    fireEvent.change(view.getByLabelText('创作输入'), { target: { value: '滚动测试' } });
    fireEvent.click(view.getByRole('button', { name: '发送创作请求' }));
    const timeline = view.getByRole('log');
    const observer = resize.find((item) => item.target === timeline)!;
    assert.ok(observer);
    fireEvent.scroll(window);
    const before = scrolls;
    act(() => observer.callback([], {} as ResizeObserver));
    assert.equal(scrolls, before, 'reading above must not force document scroll');
    Object.defineProperty(window, 'scrollY', { configurable: true, value: 4500 });
    fireEvent.scroll(window);
    act(() => observer.callback([], {} as ResizeObserver));
    assert.equal(scrolls, before + 1);
  } finally {
    Object.defineProperty(globalThis, 'ResizeObserver', {
      configurable: true,
      value: OriginalObserver,
    });
    dom.window.HTMLElement.prototype.scrollIntoView = originalScroll;
    Object.defineProperty(document.documentElement, 'scrollHeight', {
      configurable: true,
      value: 0,
    });
    Object.defineProperty(window, 'scrollY', { configurable: true, value: 0 });
  }
});

test('only newly inserted messages reveal; historic and revisited messages do not replay entry motion', async () => {
  const originalMedia = window.matchMedia;
  const originalAnimate = HTMLElement.prototype.animate;
  let animations = 0;
  window.matchMedia = (query: string) =>
    ({
      matches: false,
      media: query,
      addEventListener() {},
      removeEventListener() {},
    }) as MediaQueryList;
  HTMLElement.prototype.animate = () => {
    animations++;
    return { cancel() {}, pause() {}, play() {}, onfinish: null } as unknown as Animation;
  };
  try {
    const view = mountWorkspace();
    fireEvent.change(view.getByLabelText('创作输入'), { target: { value: 'entry replay probe' } });
    fireEvent.click(view.getByRole('button', { name: '发送创作请求' }));
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 220));
    });
    assert.equal(animations, 2, 'new user and assistant entries each reveal once');
    fireEvent.click(view.getByRole('button', { name: '停止模拟回复' }));
    fireEvent.click(view.getByRole('button', { name: '光影与材质练习', exact: true }));
    assert.equal(animations, 2, 'fixtures are already historical');
    fireEvent.click(view.getByRole('button', { name: 'entry replay probe', exact: true }));
    assert.equal(animations, 2, 'returning to a session must not replay entry effects');
  } finally {
    window.matchMedia = originalMedia;
    HTMLElement.prototype.animate = originalAnimate;
  }
});

test('category changes retain session DOM, scroll host and accessible pressed buttons without navigation', () => {
  const view = mountWorkspace();
  const list = view.getByRole('region', { name: '会话列表' });
  const rows = Array.from(list.querySelectorAll('.sessionItem'));
  list.scrollTop = 120;
  const group = view.getByRole('group', { name: '会话分类' });
  assert.ok(
    group.querySelector('[data-gooey-indicator]'),
    'selected background has one stable host',
  );
  fireEvent.click(view.getByRole('button', { name: '电商生图', exact: true }));
  assert.deepEqual(Array.from(list.querySelectorAll('.sessionItem')), rows);
  assert.equal(list.querySelectorAll('.sessionItem:not([hidden])').length, 8);
  fireEvent.click(view.getByRole('button', { name: '普通创作', exact: true }));
  fireEvent.click(view.getByRole('button', { name: '全部', exact: true }));
  assert.deepEqual(Array.from(list.querySelectorAll('.sessionItem')), rows);
  assert.equal(list.querySelectorAll('.sessionItem:not([hidden])').length, 24);
  assert.equal(list.scrollTop, 120);
  assert.equal(group.querySelectorAll('[aria-pressed="true"]').length, 1);
  assert.equal(pushes.length, 0);
});

test('category indicator measures current bounds, retargets rapid clicks and cleans its resize observer', () => {
  const originalRect = HTMLElement.prototype.getBoundingClientRect;
  const originalObserver = globalThis.ResizeObserver;
  const observers: { targets: Element[]; callback: () => void; disconnected: boolean }[] = [];
  let width = 70;
  HTMLElement.prototype.getBoundingClientRect = function () {
    const isGroup = this.getAttribute('aria-label') === '会话分类';
    const index =
      this.parentElement?.getAttribute('aria-label') === '会话分类'
        ? Array.from(this.parentElement.querySelectorAll('button')).indexOf(
            this as HTMLButtonElement,
          )
        : -1;
    if (isGroup || index >= 0)
      return {
        x: 10,
        y: 20,
        left: 10 + (index >= 0 ? 3 + index * (width + 3) : 0),
        top: 20 + (index >= 0 ? 3 : 0),
        width: isGroup ? 240 : width,
        height: isGroup ? 37 : 31,
        right: 250,
        bottom: 57,
        toJSON() {},
      };
    return originalRect.call(this);
  };
  globalThis.ResizeObserver = class {
    record: (typeof observers)[number];
    constructor(callback: () => void) {
      this.record = { targets: [], callback, disconnected: false };
      observers.push(this.record);
    }
    observe(target: Element) {
      this.record.targets.push(target);
    }
    unobserve() {}
    disconnect() {
      this.record.disconnected = true;
    }
  } as unknown as typeof ResizeObserver;
  try {
    const view = mountWorkspace();
    const group = view.getByRole('group', { name: '会话分类' });
    const indicator = group.querySelector<HTMLElement>('[data-gooey-indicator]');
    assert.ok(indicator);
    assert.equal(indicator.style.transform, 'translate(3px, 3px)');
    assert.equal(indicator.style.width, '70px');
    fireEvent.click(view.getByRole('button', { name: '普通创作', exact: true }));
    fireEvent.click(view.getByRole('button', { name: '电商生图', exact: true }));
    assert.equal(indicator.style.transform, 'translate(149px, 3px)');
    const observer = observers.find((entry) => entry.targets.includes(group));
    assert.ok(observer);
    assert.equal(observer.targets.length, 4, 'only group and its three buttons are observed');
    width = 60;
    act(() => observer.callback());
    assert.equal(indicator.style.transform, 'translate(129px, 3px)');
    assert.equal(indicator.style.width, '60px');
    view.unmount();
    assert.equal(observer.disconnected, true);
  } finally {
    HTMLElement.prototype.getBoundingClientRect = originalRect;
    globalThis.ResizeObserver = originalObserver;
  }
});

test('workspace composer exposes independent chat and image model choices with local-only provenance', () => {
  const view = mountWorkspace();
  const input = view.getByLabelText('创作输入');
  const chatModel = view.getByRole('combobox', { name: /^对话模型 / });
  assert.match(view.container.textContent || '', /模型选择仅保留在本地/);
  fireEvent.click(chatModel);
  const chatOptions = view.getAllByRole('option');
  assert.ok(chatOptions.length >= 2);
  const chosenChat = chatOptions[1].textContent;
  fireEvent.click(chatOptions[1]);
  fireEvent.click(view.getByRole('button', { name: '创建图片' }));
  const imageModel = view.getByRole('combobox', { name: /^图片模型 / });
  fireEvent.click(imageModel);
  const imageOptions = view.getAllByRole('option');
  assert.ok(imageOptions.length >= 2);
  assert.ok(
    imageOptions.every(
      (option) => !chatOptions.some((chat) => chat.textContent === option.textContent),
    ),
  );
  const chosenImage = imageOptions[1].textContent;
  fireEvent.click(imageOptions[1]);
  fireEvent.click(view.getByRole('button', { name: '创建图片' }));
  assert.equal(view.getByRole('combobox', { name: /^对话模型 / }).textContent, chosenChat);
  fireEvent.click(view.getByRole('button', { name: '创建图片' }));
  assert.equal(view.getByRole('combobox', { name: /^图片模型 / }).textContent, chosenImage);
  assert.equal(view.getByLabelText('创作输入'), input);
});

test('double-clicking send does not reinterpret the second click as stop', () => {
  const view = mountWorkspace();
  fireEvent.change(view.getByLabelText('创作输入'), { target: { value: '双击提交' } });
  fireEvent.click(view.getByRole('button', { name: '发送创作请求' }), { detail: 1 });
  const stop = view.getByRole('button', { name: '停止模拟回复' });
  fireEvent.click(stop, { detail: 2 });
  assert.equal(view.getByRole('log').querySelectorAll('article').length, 2);
  assert.ok(view.getByRole('button', { name: '停止模拟回复' }));
  assert.match(view.getByRole('status').textContent || '', /正在演示思考步骤/);
  fireEvent.click(stop, { detail: 1 });
  assert.match(view.getByRole('status').textContent || '', /模拟回复已停止/);
});

test('keyboard and assistive activation can stop a simulation immediately', () => {
  const view = mountWorkspace();
  fireEvent.change(view.getByLabelText('创作输入'), { target: { value: '键盘提交' } });
  fireEvent.keyDown(view.getByLabelText('创作输入'), { key: 'Enter' });
  fireEvent.click(view.getByRole('button', { name: '停止模拟回复' }), { detail: 0 });
  assert.match(view.getByRole('status').textContent || '', /模拟回复已停止/);
});

test('catalogue page exposes a scroll target ahead of the stable cached catalogue', () => {
  const tree = (path: string) => (
    <AppRouterContext.Provider value={router}>
      <PathnameContext.Provider value={path}>
        <AppProvider>
          <CommerceLayout>
            {path === '/create' ? <CataloguePage /> : <div>Editor</div>}
          </CommerceLayout>
        </AppProvider>
      </PathnameContext.Provider>
    </AppRouterContext.Provider>
  );
  const view = render(tree('/create'));
  const anchor = view.container.querySelector('[data-catalogue-scroll-anchor]');
  const cache = view.container.querySelector('.cm-catalogue-cache')!;
  assert.ok(anchor, 'a null Page cannot participate in Next route scroll handling');
  assert.equal(anchor.parentElement, cache.parentElement);
  assert.equal(anchor.nextElementSibling, cache);
  const images = [...cache.querySelectorAll('img')];
  assert.ok(images.length > 0);
  view.rerender(tree('/create/product-set'));
  assert.equal(cache.hasAttribute('hidden'), true);
  assert.deepEqual([...cache.querySelectorAll('img')], images);
  view.rerender(tree('/create'));
  assert.equal(cache.hasAttribute('hidden'), false);
  assert.deepEqual([...cache.querySelectorAll('img')], images);
});

test('double-clicking stop does not submit the queued next draft', () => {
  const view = mountWorkspace();
  const input = view.getByLabelText('创作输入') as HTMLTextAreaElement;
  fireEvent.change(input, { target: { value: '当前请求' } });
  fireEvent.click(view.getByRole('button', { name: '发送创作请求' }), { detail: 1 });
  fireEvent.change(input, { target: { value: '下一条草稿' } });
  assert.equal(
    fireEvent.click(view.getByRole('button', { name: '停止模拟回复' }), { detail: 1 }),
    false,
    'cancel native click default before the same DOM button becomes a submit button',
  );
  fireEvent.click(view.getByRole('button', { name: '发送创作请求' }), { detail: 2 });
  assert.equal(view.getByRole('log').querySelectorAll('article').length, 2);
  assert.equal(input.value, '下一条草稿');
  assert.match(view.getByRole('status').textContent || '', /模拟回复已停止/);
  fireEvent.click(view.getByRole('button', { name: '发送创作请求' }), { detail: 1 });
  assert.equal(view.getByRole('log').querySelectorAll('article').length, 4);
  assert.equal(input.value, '');
});
