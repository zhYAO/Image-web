import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';

const path = new URL('../src/components/landing/motion.ts', import.meta.url);
test('landing motion has a native, independently testable React implementation', () => {
  assert.equal(existsSync(path), true, 'React motion functions must exist');
});

test('header preserves the 64px/24px hysteresis boundaries', async () => {
  const { nextCondensed } = await import(path);
  assert.equal(nextCondensed(false, 64), false);
  assert.equal(nextCondensed(false, 65), true);
  assert.equal(nextCondensed(true, 24), true);
  assert.equal(nextCondensed(true, 23), false);
  assert.equal(nextCondensed(false, -50), false);
});

test('scroll reel slides continuously, clamps both ends and handles one frame', async () => {
  const { reelFrameState } = await import(path);
  assert.deepEqual(reelFrameState(-20, 1000, 3), { active: 0, offsets: [0, 100, 100] });
  assert.deepEqual(reelFrameState(250, 1000, 3), { active: 1, offsets: [0, 50, 100] });
  assert.deepEqual(reelFrameState(500, 1000, 3), { active: 1, offsets: [0, 0, 100] });
  assert.deepEqual(reelFrameState(2000, 1000, 3), { active: 2, offsets: [0, 0, 0] });
  assert.deepEqual(reelFrameState(100, 0, 1), { active: 0, offsets: [0] });
  assert.deepEqual(reelFrameState(100, 0, 0), { active: 0, offsets: [] });
});

test('statement words light sequentially from the 82% to 22% viewport band', async () => {
  const { statementOpacity } = await import(path);
  assert.deepEqual(statementOpacity(820, 1000, 4), [0.18, 0.18, 0.18, 0.18]);
  assert.deepEqual(statementOpacity(520, 1000, 4), [1, 1, 0.18, 0.18]);
  assert.deepEqual(statementOpacity(220, 1000, 4), [1, 1, 1, 1]);
});

test('gallery cycling requires visibility and pauses for every interruption', async () => {
  const { canCycleGallery, GALLERY_INTERVAL_MS } = await import(path);
  const ready = {
    visible: true,
    hovered: false,
    focused: false,
    manual: false,
    paused: false,
    hidden: false,
    reducedMotion: false,
  };
  assert.equal(GALLERY_INTERVAL_MS, 10_000);
  assert.equal(canCycleGallery(ready), true);
  for (const key of ['hovered', 'focused', 'manual', 'paused', 'hidden', 'reducedMotion']) {
    assert.equal(canCycleGallery({ ...ready, [key]: true }), false, key);
  }
  assert.equal(canCycleGallery({ ...ready, visible: false }), false);
});

test('reel falls back on narrow, short and reduced-motion viewports', async () => {
  const { isReelPinned } = await import(path);
  assert.equal(isReelPinned(881, 681, false), true);
  assert.equal(isReelPinned(880, 900, false), false);
  assert.equal(isReelPinned(1400, 680, false), false);
  assert.equal(isReelPinned(1400, 900, true), false);
});

test('homepage uses a server composition with normal Next routes and no HTML injection', () => {
  const component = new URL('../src/components/landing/LandingPage.tsx', import.meta.url);
  assert.equal(existsSync(component), true, 'React page composition must exist');
  if (!existsSync(component)) return;
  const source = readFileSync(component, 'utf8');
  assert.doesNotMatch(source, /dangerouslySetInnerHTML|iframe|#\/|innerHTML|use client/);
  assert.match(source, /next\/link/);
  for (const route of ['/workspace', '/create', '/assets', '/account'])
    assert.ok(source.includes(route));
});

test('hero entrance keyframes keep server-rendered content visible and unblurred', () => {
  const css = readFileSync(
    new URL('../src/components/landing/landing.css', import.meta.url),
    'utf8',
  );
  for (const name of ['zl-hero-enter', 'zl-title-enter']) {
    const start = css.indexOf(`@keyframes ${name} {`);
    assert.notEqual(start, -1, `${name} must exist`);
    const nextRule = css.indexOf('\n}', start);
    const keyframes = css.slice(start, nextRule + 2);
    assert.match(keyframes, /transform:/, 'retain the modest entrance movement');
    assert.doesNotMatch(keyframes, /opacity:|filter:/, 'never mask initial server content');
  }
});
