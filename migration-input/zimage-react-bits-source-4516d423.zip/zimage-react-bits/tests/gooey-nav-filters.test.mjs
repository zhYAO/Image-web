import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { registerHooks } from 'node:module';
registerHooks({
  load(url, context, next) {
    if (url.endsWith('.css'))
      return { format: 'module', source: 'export default {}', shortCircuit: true };
    return next(url, context);
  },
});
const { CategoryFilters } = await import('../src/components/workspace/CategoryFilters.tsx');

const css = fs.readFileSync('src/components/workspace/workspace.module.css', 'utf8');
test('GooeyNav category adaptation serves pressed native buttons and a decorative host in SSR', () => {
  const html = renderToStaticMarkup(
    React.createElement(CategoryFilters, { value: 'general', onChange() {}, inert: false }),
  );
  assert.equal((html.match(/<button/g) || []).length, 3);
  assert.match(html, /aria-pressed="true">普通创作/);
  assert.match(html, /data-gooey-indicator="" aria-hidden="true"/);
  assert.doesNotMatch(html, /data-indicator-ready|<a |<canvas|<svg/);
  assert.match(css, /\.categories button\[aria-pressed='true'\] \{\s*background: var\(--soft\)/);
});
test('indicator motion is bounded, reduced-motion instant and forced-color decoration absent', () => {
  assert.match(css, /transform 200ms var\(--ease\)/);
  assert.match(
    css,
    /@media \(prefers-reduced-motion: reduce\) \{\s*\.categoryIndicator \{\s*transition: none/,
  );
  assert.match(
    css,
    /@media \(forced-colors: active\) \{\s*\.categories\[data-indicator-ready='true'\] \.categoryIndicator \{\s*display: none/,
  );
});
