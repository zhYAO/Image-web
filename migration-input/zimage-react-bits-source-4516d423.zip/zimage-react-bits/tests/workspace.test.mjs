import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';

test('workspace port uses native client components and framework links', () => {
  const path = new URL('../src/components/workspace/WorkspaceShell.tsx', import.meta.url);
  assert.equal(existsSync(path), true, 'WorkspaceShell is implemented');
  const shell = readFileSync(path, 'utf8');
  assert.match(shell, /export function WorkspaceShell/);
  assert.match(shell, /from ['"]next\/link['"]/);
  assert.doesNotMatch(shell, /dangerouslySetInnerHTML|<iframe|#\//);
});

test('workspace shell does not add a composer to other pages', () => {
  const path = new URL('../src/components/workspace/WorkspaceShell.tsx', import.meta.url);
  assert.equal(existsSync(path), true, 'WorkspaceShell is implemented');
  assert.doesNotMatch(readFileSync(path, 'utf8'), /<WorkspaceComposer/);
});

test('workspace composer retains separate canonical drafts and hides references in chat mode', () => {
  const path = new URL('../src/components/workspace/WorkspaceComposer.tsx', import.meta.url);
  assert.equal(existsSync(path), true, 'WorkspaceComposer is implemented');
  const source = readFileSync(path, 'utf8');
  assert.match(source, /usePreview/);
  assert.match(source, /chatDraft/);
  assert.match(source, /imageDraft/);
  assert.match(source, /setMode/);
  assert.match(source, /ModelSelector/);
  assert.match(source, /模型选择仅保留在本地，未连接服务/);
  assert.doesNotMatch(source, /clearReferences\(/);
  assert.doesNotMatch(source, /fetch\(|XMLHttpRequest|前端|预览/);
});

test('carousel supports keyboard, swipe, pause, and reduced motion without imperatively replacing DOM', () => {
  const path = new URL('../src/components/workspace/SceneCarousel.tsx', import.meta.url);
  assert.equal(existsSync(path), true, 'SceneCarousel is implemented');
  const source = readFileSync(path, 'utf8');
  assert.match(source, /ArrowLeft/);
  assert.match(source, /onPointerMove/);
  assert.match(source, /prefers-reduced-motion/);
  assert.match(source, /visibilitychange/);
  assert.doesNotMatch(source, /innerHTML|insertAdjacentHTML/);
});

test('shared shell matches HTML document scrolling behind sticky navigation without layout-per-frame collapse', () => {
  const css = readFileSync(
    new URL('../src/components/workspace/workspace.module.css', import.meta.url),
    'utf8',
  );
  const workspace = css.match(/\.workspace\s*\{([^}]*)\}/s)[1];
  const content = css.match(/\.pageContent\s*\{([^}]*)\}/s)[1];
  assert.match(workspace, /min-height: 100svh;/);
  assert.doesNotMatch(workspace, /(?:^|;)\s*height:|overflow:/);
  assert.doesNotMatch(content, /overflow(?:-y)?:/);
  assert.match(css, /\.topbar\s*\{[^}]*position: sticky;[^}]*top: var\(--shell-pad\);/s);
  assert.match(css, /:global\(html\):has\(\.workspace\)\s*\{\s*scroll-padding-top: 108px;/);
  assert.match(css, /\.mainContent\s*\{[^}]*flex: 1;/s);
  assert.doesNotMatch(css, /transition:\s*(?:grid-template-columns|left)\s/);
  assert.doesNotMatch(css, /width 240ms/);
});
