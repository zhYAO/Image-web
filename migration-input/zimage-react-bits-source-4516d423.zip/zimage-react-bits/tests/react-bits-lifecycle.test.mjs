import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import vm from 'node:vm';
import ts from 'typescript';

const base = resolve(import.meta.dirname, '../src/components/react-bits');

test('React Bits full license is retained identically in source and static distribution', () => {
  const project = resolve(import.meta.dirname, '..');
  const sourceLicense = readFileSync(resolve(project, 'licenses/react-bits-LICENSE.md'), 'utf8');
  const distributedLicense = readFileSync(
    resolve(project, 'public/licenses/react-bits-LICENSE.md'),
    'utf8',
  );
  assert.equal(distributedLicense, sourceLicense);
  assert.match(distributedLicense, /Copyright \(c\) 2026 David Haz/);
  assert.match(distributedLicense, /Commons Clause Restriction/);
  assert.match(distributedLicense, /THE SOFTWARE IS PROVIDED/);
});

test('catalogue keeps semantic intent links without a global border animation', () => {
  const source = readFileSync(resolve(base, '../commerce/CommerceCatalogue.tsx'), 'utf8');
  const layout = readFileSync(resolve(base, '../../app/layout.tsx'), 'utf8');
  assert.match(source, /<IntentLink/);
  assert.doesNotMatch(source, /BorderGlow|StarBorder|data-border-glow/);
  assert.doesNotMatch(layout, /BorderGlow/);
  for (const file of ['BorderGlow.tsx', 'BorderGlowController.tsx', 'BorderGlow.css']) {
    assert.equal(existsSync(resolve(base, file)), false);
  }
});

function target(extra = {}) {
  const listeners = new Map();
  return {
    ...extra,
    listeners,
    addEventListener(name, fn) {
      listeners.set(name, fn);
    },
    removeEventListener(name, fn) {
      if (listeners.get(name) === fn) listeners.delete(name);
    },
    emit(name, event = {}) {
      listeners.get(name)?.(event);
    },
  };
}

// Execute actual TSX effects with a deterministic DOM/canvas scheduler. This is
// a lifecycle unit test, not a substitute for the app's real-browser visual QA.
function mount(
  name,
  props = {},
  {
    reduced = false,
    observers = true,
    waapi = true,
    controller = false,
    initiallyHovered = false,
  } = {},
) {
  const refs = [],
    effects = [],
    frames = new Map(),
    observersCreated = [],
    animations = [],
    strokes = [];
  let frameId = 0,
    clock = 0,
    drawCount = 0;
  const gradient = { addColorStop() {} };
  const context = new Proxy(
    { fillStyle: '#000000' },
    {
      get(object, key) {
        if (key in object) return object[key];
        if (key === 'clearRect')
          return () => {
            drawCount++;
            strokes.length = 0;
          };
        if (key === 'moveTo')
          return (x, y) => {
            object.start = [x, y];
          };
        if (key === 'lineTo')
          return (x, y) => {
            object.end = [x, y];
          };
        if (key === 'stroke')
          return () =>
            strokes.push({
              start: object.start,
              end: object.end,
              width: object.lineWidth,
              color: object.strokeStyle,
            });
        if (key === 'createRadialGradient' || key === 'createLinearGradient') return () => gradient;
        return () => {};
      },
      set(object, key, value) {
        object[key] = value;
        return true;
      },
    },
  );
  const preference = target({ matches: reduced });
  const document = target({ hidden: false, createElement: () => ({ getContext: () => context }) });
  const root = target({
    offsetWidth: 460,
    offsetHeight: 270,
    clientWidth: 458,
    clientHeight: 268,
    clientLeft: 1,
    clientTop: 1,
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 460, height: 270 }),
    matches: (selector) => selector === ':hover' && initiallyHovered,
    querySelector: () => null,
    contains: (node) => node === root,
  });
  if (waapi)
    root.animate = (keyframes, options) => {
      const animation = {
        keyframes,
        options,
        paused: 0,
        played: 0,
        cancelled: 0,
        pause() {
          this.paused++;
        },
        play() {
          this.played++;
        },
        cancel() {
          this.cancelled++;
        },
      };
      animations.push(animation);
      return animation;
    };
  const window = target({
    devicePixelRatio: 2,
    matchMedia: (query) => (query.includes('pointer: fine') ? { matches: true } : preference),
  });
  class Observer {
    constructor(fn, options) {
      this.callback = fn;
      this.options = options;
      this.disconnected = false;
      observersCreated.push(this);
    }
    observe(node) {
      this.node = node;
    }
    disconnect() {
      this.disconnected = true;
    }
    intersect(visible) {
      this.callback([{ isIntersecting: visible, target: this.node }]);
    }
  }
  const react = {
    useRef(initial) {
      const ref = { current: initial };
      refs.push(ref);
      return ref;
    },
    useEffect(fn) {
      effects.push(fn);
    },
  };
  const jsx = (type, properties) => ({ type, props: properties });
  const testModule = { exports: {} };
  const source = readFileSync(resolve(base, `${name}.tsx`), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      jsx: ts.JsxEmit.ReactJSX,
      target: ts.ScriptTarget.ES2020,
      esModuleInterop: true,
    },
  }).outputText;
  vm.runInNewContext(compiled, {
    exports: testModule.exports,
    module: testModule,
    document,
    window,
    performance: { now: () => clock },
    ResizeObserver: observers ? Observer : undefined,
    IntersectionObserver: observers ? Observer : undefined,
    requestAnimationFrame: (fn) => {
      frames.set(++frameId, fn);
      return frameId;
    },
    cancelAnimationFrame: (id) => frames.delete(id),
    require(path) {
      if (path === 'react') return react;
      if (path === 'react/jsx-runtime') return { jsx, jsxs: jsx };
      if (path.endsWith('.css')) return {};
      throw new Error(`Unexpected component dependency: ${path}`);
    },
  });
  const tree = controller
    ? testModule.exports.FadeContentEffect({ targetRef: { current: root }, ...props })
    : testModule.exports.default({ children: 'Readable content', ...props });
  if (!controller) refs[0].current = root;
  if (name === 'StarBorder') refs[1].current = { getContext: () => context, width: 0, height: 0 };
  const cleanups = effects.map((effect) => effect()).filter(Boolean);
  return {
    tree,
    root,
    preference,
    document,
    window,
    frames,
    observers: observersCreated,
    animations,
    strokes,
    get canvas() {
      return refs[1].current;
    },
    get drawCount() {
      return drawCount;
    },
    pump(count = 1) {
      for (let i = 0; i < count; i++) {
        clock += 16.7;
        const current = [...frames.values()];
        frames.clear();
        current.forEach((fn) => fn(clock));
      }
    },
    cleanup() {
      cleanups.forEach((fn) => fn());
    },
  };
}

test('StarBorder defaults to idle; hover starts one RAF chain; offscreen/hidden tabs stop it', () => {
  const view = mount('StarBorder');
  view.pump(3);
  assert.equal(view.frames.size, 0, 'default reveal mode idles before interaction');
  view.root.emit('pointerenter', { clientX: 100, clientY: 50 });
  view.pump(3);
  assert.equal(view.frames.size, 1);
  assert.ok(view.drawCount > 0);
  const intersection = view.observers[1];
  intersection.intersect(false);
  assert.equal(view.frames.size, 0);
  intersection.intersect(true);
  assert.equal(view.frames.size, 1);
  view.document.hidden = true;
  view.document.emit('visibilitychange');
  assert.equal(view.frames.size, 0);
  view.document.hidden = false;
  view.document.emit('visibilitychange');
  assert.equal(view.frames.size, 1);
  view.root.emit('pointerleave');
  view.pump(240);
  assert.equal(view.frames.size, 0, 'hover exit has a bounded fade-out and then idles');
  view.root.emit('pointerenter', { pointerType: 'touch', clientX: 50, clientY: 50 });
  assert.equal(view.frames.size, 0, 'touch pointerenter must not latch a hover effect');
  view.cleanup();
  assert.equal(view.frames.size, 0);
  assert.equal(view.root.listeners.size, 0);
  assert.equal(view.document.listeners.size, 0);
  assert.equal(view.preference.listeners.size, 0);
  assert.ok(view.observers.every((observer) => observer.disconnected));
});

test('StarBorder bitmap matches the clipped padding box, including a bordered card', () => {
  const view = mount('StarBorder', { thickness: 2 });
  assert.equal(view.canvas.width, (view.root.clientWidth + 96) * 2);
  assert.equal(view.canvas.height, (view.root.clientHeight + 96) * 2);
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(120);
  const first = view.strokes.filter((stroke) => stroke.width === 2);
  assert.ok(first.length > 0, 'hover paints actual trail strokes, not only a cleared bitmap');
  for (const stroke of first) {
    for (const [x, y] of [stroke.start, stroke.end]) {
      assert.ok(x >= 0 && x <= view.root.clientWidth - 2);
      assert.ok(y >= 0 && y <= view.root.clientHeight - 2);
    }
  }
  view.cleanup();
});

test('StarBorder advances clockwise along the top edge and paints a silver keyline', () => {
  const view = mount('StarBorder', {
    theme: 'light',
    color: '#ffffff',
    trailColor: '#8896a8',
    thickness: 2,
    duration: 3.8,
    breath: 0.24,
    trailLength: 0.18,
  });
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(15);
  const headBefore = view.strokes.find((stroke) => stroke.width === 2).start;
  view.pump(15);
  const headAfter = view.strokes.find((stroke) => stroke.width === 2).start;
  assert.equal(headBefore[1], 0);
  assert.equal(headAfter[1], 0);
  assert.ok(headAfter[0] > headBefore[0], 'clockwise head moves right along the top edge');
  assert.ok(
    view.strokes.some(
      (stroke) => stroke.width === 3 && stroke.color.startsWith('rgba(136, 150, 168,'),
    ),
    'silver keyline separates the white head from white content',
  );
  view.root.emit('pointerleave');
  view.pump(240);
  assert.equal(view.frames.size, 0);
  view.root.matches = () => true;
  view.root.emit('focusin');
  view.pump(15);
  assert.ok(view.strokes.length > 0, 'keyboard focus reveals the same perimeter');
  view.root.emit('focusout', { relatedTarget: null });
  view.pump(240);
  assert.equal(view.frames.size, 0);
  view.cleanup();
});

test('StarBorder reveal completes exactly one clockwise circuit and stays idle until reentry', () => {
  const view = mount('StarBorder', { duration: 1, thickness: 2, clickPulse: false });
  view.pump(3);
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  const sides = new Set();
  for (let frame = 0; frame < 60; frame++) {
    view.pump();
    const [x, y] = view.strokes.find((stroke) => stroke.width === 2).start;
    if (y === 0) sides.add('top');
    if (x === view.root.clientWidth - 2) sides.add('right');
    if (y === view.root.clientHeight - 2) sides.add('bottom');
    if (x === 0) sides.add('left');
  }
  assert.equal(sides.size, 4, 'the head travels the entire perimeter');
  const [x, y] = view.strokes.find((stroke) => stroke.width === 2).start;
  assert.ok(Math.abs(x - 98) < 0.001, 'one circuit ends at the pointer-projected origin');
  assert.equal(y, 0);
  view.pump(240);
  assert.equal(view.frames.size, 0, 'holding hover cannot loop or keep breathing RAF alive');
  const draws = view.drawCount;
  view.pump(600);
  assert.equal(view.drawCount, draws);
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(3);
  assert.equal(view.frames.size, 0, 'duplicate entry does not restart a completed circuit');
  view.root.emit('pointerleave');
  view.pump(240);
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(15);
  assert.equal(view.frames.size, 1, 'a genuinely new hover starts another circuit');
  view.cleanup();
});

test('StarBorder reveal keyboard focus plays once and can restart after blur', () => {
  const view = mount('StarBorder', { duration: 0.5, clickPulse: false });
  view.root.matches = (selector) => selector === ':focus-visible';
  view.root.emit('focusin');
  view.pump(10);
  assert.equal(view.frames.size, 1);
  view.pump(240);
  assert.equal(view.frames.size, 0);
  view.root.emit('focusin');
  view.pump(3);
  assert.equal(view.frames.size, 0);
  view.root.emit('focusout', { relatedTarget: null });
  view.pump(240);
  view.root.emit('focusin');
  view.pump(10);
  assert.equal(view.frames.size, 1);
  view.cleanup();
});

test('StarBorder reveal pauses its single circuit while hidden or offscreen', () => {
  const view = mount('StarBorder', { duration: 1, thickness: 2 });
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(20);
  const before = view.drawCount;
  view.observers[1].intersect(false);
  view.pump(600);
  assert.equal(view.drawCount, before);
  view.observers[1].intersect(true);
  view.pump(20);
  view.document.hidden = true;
  view.document.emit('visibilitychange');
  const paused = view.drawCount;
  view.pump(600);
  assert.equal(view.drawCount, paused);
  view.document.hidden = false;
  view.document.emit('visibilitychange');
  view.pump(20);
  const [x, y] = view.strokes.find((stroke) => stroke.width === 2).start;
  assert.ok(Math.abs(x - 98) < 0.001, 'visible playback still completes exactly one circuit');
  assert.equal(y, 0);
  view.pump(240);
  assert.equal(view.frames.size, 0);
  view.cleanup();
});

test('StarBorder reveal cancels an active circuit when reduced motion is enabled', () => {
  const view = mount('StarBorder', { duration: 1 });
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(10);
  view.preference.emit('change', { matches: true });
  view.pump();
  assert.equal(view.frames.size, 0);
  view.preference.emit('change', { matches: false });
  view.pump(3);
  assert.equal(view.frames.size, 0, 'changing preferences is not a new hover');
  view.root.emit('pointerleave');
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(10);
  assert.equal(view.frames.size, 1);
  view.cleanup();
});

test('StarBorder completed reveal does not restart after visibility or motion preference changes', () => {
  const view = mount('StarBorder', { duration: 0.5 });
  view.root.emit('pointerenter', { clientX: 100, clientY: 1 });
  view.pump(240);
  assert.equal(view.frames.size, 0);
  view.observers[1].intersect(false);
  view.observers[1].intersect(true);
  view.document.hidden = true;
  view.document.emit('visibilitychange');
  view.document.hidden = false;
  view.document.emit('visibilitychange');
  view.pump(3);
  assert.equal(view.frames.size, 0);
  view.preference.emit('change', { matches: true });
  view.pump();
  assert.equal(view.frames.size, 0);
  view.preference.emit('change', { matches: false });
  view.pump(3);
  assert.equal(view.frames.size, 0);
  view.cleanup();
});

test('StarBorder activates when hydration mounts beneath an already-hovering fine pointer', () => {
  const view = mount('StarBorder', {}, { initiallyHovered: true });
  view.pump(30);
  assert.ok(view.strokes.length > 0, 'hydration must not require leaving and reentering the card');
  assert.equal(view.frames.size, 1);
  view.cleanup();
});

test('StarBorder responds live to reduced motion and does not spin on hover/click', () => {
  const view = mount('StarBorder', { hover: 'brighten' });
  view.pump(5);
  assert.equal(view.frames.size, 1);
  view.preference.emit('change', { matches: true });
  view.pump();
  assert.equal(view.frames.size, 0);
  view.root.emit('pointerenter', { clientX: 50, clientY: 50 });
  view.pump();
  assert.equal(view.frames.size, 0);
  view.root.emit('click', { detail: 0 });
  assert.equal(view.frames.size, 0);
  view.preference.emit('change', { matches: false });
  view.pump();
  assert.equal(view.frames.size, 1);
  view.cleanup();
});

test('StarBorder preserves actual semantic links and observer fallback cleanup', () => {
  const view = mount('StarBorder', { as: 'a', href: '/commerce/' }, { observers: false });
  assert.equal(view.tree.type, 'a');
  assert.equal(view.tree.props.href, '/commerce/');
  assert.equal(view.tree.props.type, undefined);
  assert.ok(view.window.listeners.has('resize'));
  view.cleanup();
  assert.equal(view.window.listeners.size, 0);
});

test('FadeContent server markup is visible and keeps children without a loading placeholder', () => {
  const view = mount('FadeContent');
  assert.equal(view.tree.props.children, 'Readable content');
  assert.equal(view.tree.props.style, undefined);
  assert.equal(view.animations.length, 0);
  view.cleanup();
});

test('FadeContentEffect adds no DOM and enhances an existing stable host', () => {
  const view = mount('FadeContent', { duration: 900 }, { controller: true });
  assert.equal(view.tree, null);
  assert.equal(view.observers[0].node, view.root);
  view.observers[0].intersect(true);
  assert.equal(view.animations.length, 1);
  assert.equal(view.animations[0].options.duration, 900);
  view.cleanup();
  assert.equal(view.root.listeners.size, 0);
});

test('FadeContent reveals once, passes observer geometry, and pauses while the tab is hidden', () => {
  let completed = 0;
  const view = mount('FadeContent', {
    rootMargin: '0px 0px -8% 0px',
    onComplete: () => completed++,
  });
  assert.equal(view.observers[0].options.rootMargin, '0px 0px -8% 0px');
  view.observers[0].intersect(true);
  view.observers[0].intersect(true);
  assert.equal(view.animations.length, 1);
  view.document.hidden = true;
  view.document.emit('visibilitychange');
  assert.equal(view.animations[0].paused, 1);
  view.document.hidden = false;
  view.document.emit('visibilitychange');
  assert.equal(view.animations[0].played, 1);
  view.animations[0].onfinish();
  view.animations[0].onfinish();
  assert.equal(completed, 1);
  view.cleanup();
  assert.equal(view.root.listeners.size, 0);
  assert.equal(view.preference.listeners.size, 0);
  assert.equal(view.document.listeners.size, 0);
});

test('FadeContent live reduced motion and keyboard focus cancel a pending reveal', () => {
  const view = mount('FadeContent');
  view.observers[0].intersect(true);
  view.preference.emit('change', { matches: true });
  assert.equal(view.animations[0].cancelled, 1);
  view.cleanup();
  const keyboard = mount('FadeContent');
  keyboard.root.emit('focusin');
  keyboard.observers[0].intersect(true);
  assert.equal(keyboard.animations.length, 0);
  keyboard.cleanup();
});

test('FadeContent remains available with reduced motion or without browser animation APIs', () => {
  for (const options of [{ reduced: true }, { observers: false, waapi: false }]) {
    let completed = 0;
    const view = mount('FadeContent', { onComplete: () => completed++ }, options);
    assert.equal(view.animations.length, 0);
    assert.equal(completed, 1);
    view.cleanup();
  }
});
