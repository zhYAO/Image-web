import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('chat selections pin provenance and export the exact matching license copy', () => {
  const provenance = read('docs/react-bits-chat.md');
  assert.match(provenance, /c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/);
  assert.match(provenance, /narrower adaptations/);
  const license = read('licenses/react-bits-chat-LICENSE.md');
  assert.match(license, /MIT \+ Commons Clause/);
  assert.equal(license, read('public/licenses/react-bits-chat-LICENSE.md'));
  for (const name of ['ThoughtLine', 'LatticeLoader', 'ShinyText', 'TextType']) {
    assert.match(provenance, new RegExp(name));
    assert.doesNotMatch(
      read(`src/components/react-bits/chat/${name}.tsx`),
      /from ['"](?:gsap|motion|@hugeicons)/,
    );
  }
});

test('motion styling has static reduced-motion and readable forced-color fallbacks', () => {
  const css = read('src/components/react-bits/chat/chat-effects.css');
  assert.match(css, /prefers-reduced-motion: reduce/);
  assert.match(css, /animation: none !important/);
  assert.match(css, /forced-colors: active/);
  assert.match(css, /-webkit-text-fill-color: CanvasText !important/);
  assert.match(css, /\.zi-chat-shiny-text\[data-running='true'\]/);
  assert.match(
    css,
    /\.thought-line__step\[data-done\] \.thought-line__step-text\s*\{\s*opacity: 1/,
  );
  assert.match(css, /focus-visible/);
});
