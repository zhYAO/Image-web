import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {
  buildLiquidGlassMap,
  resolveGlassRadii,
  enhanceLiquidGlass,
  initLiquidGlass,
} from '../src/components/react-bits/GlassSurfaceEffect.js';
const initLiquidNav = enhanceLiquidGlass;
const read = (path) => readFile(new URL('../' + path, import.meta.url), 'utf8');
const [css, engine] = await Promise.all(
  ['src/styles/liquid-glass.css', 'src/components/react-bits/GlassSurfaceEffect.js'].map(read),
);

class Node {
  constructor(document, name = 'div') {
    this.ownerDocument = document;
    this.name = name;
    this.children = [];
    this.attributes = {};
    this.isConnected = true;
    const classes = new Set(),
      properties = new Map();
    this.classList = {
      add: (...xs) => xs.forEach((x) => classes.add(x)),
      remove: (...xs) => xs.forEach((x) => classes.delete(x)),
      contains: (x) => classes.has(x),
    };
    this.style = {
      setProperty: (k, v, p = '') => properties.set(k, [v, p]),
      getPropertyValue: (k) => properties.get(k)?.[0] || '',
      getPropertyPriority: (k) => properties.get(k)?.[1] || '',
      removeProperty: (k) => properties.delete(k),
    };
    this.rect = { width: 400, height: 60 };
    this.corners = ['30px', '30px', '30px', '30px'];
    this.measurements = 0;
  }
  setAttribute(key, value) {
    this.attributes[key] = String(value);
  }
  append(...nodes) {
    nodes.forEach((node) => {
      node.parent = this;
      this.children.push(node);
    });
  }
  remove() {
    if (this.parent) this.parent.children = this.parent.children.filter((node) => node !== this);
    this.parent = null;
  }
  get childElementCount() {
    return this.children.length;
  }
  getBoundingClientRect() {
    this.measurements++;
    return this.rect;
  }
  matches(selector) {
    if (selector.includes('.surface-white') && this.classList.contains('surface-white'))
      return true;
    if (
      selector.includes('[data-liquid-glass="off"]') &&
      this.attributes['data-liquid-glass'] === 'off'
    )
      return true;
    return (
      selector === '[data-liquid-glass="refract"]' &&
      this.attributes['data-liquid-glass'] === 'refract'
    );
  }
  querySelectorAll(selector) {
    return this.children.flatMap((child) => [
      ...(child.matches(selector) ? [child] : []),
      ...child.querySelectorAll(selector),
    ]);
  }
}
function fixture({ supported = true, reduced = false, observer = true } = {}) {
  const timers = new Map(),
    events = new Map(),
    queries = [],
    observers = [];
  let nextTimer = 0;
  const document = {};
  document.createElementNS = (_, name) => new Node(document, name);
  const view = {
    CSS: { supports: () => supported },
    getComputedStyle: (el) =>
      Object.fromEntries(
        [
          'borderTopLeftRadius',
          'borderTopRightRadius',
          'borderBottomRightRadius',
          'borderBottomLeftRadius',
        ].map((key, index) => [key, el.corners[index]]),
      ),
    setTimeout: (fn, delay) => {
      timers.set(++nextTimer, { fn, delay });
      return nextTimer;
    },
    clearTimeout: (id) => timers.delete(id),
    addEventListener: (key, fn) => {
      if (!events.has(key)) events.set(key, new Set());
      events.get(key).add(fn);
    },
    removeEventListener: (key, fn) => events.get(key)?.delete(fn),
    matchMedia: (query) => {
      const listeners = new Set();
      const media = {
        media: query,
        matches: reduced && query.includes('reduced-transparency'),
        addEventListener: (_, fn) => listeners.add(fn),
        removeEventListener: (_, fn) => listeners.delete(fn),
        change(value) {
          this.matches = value;
          listeners.forEach((fn) => fn());
        },
        listeners,
      };
      queries.push(media);
      return media;
    },
  };
  if (observer)
    view.ResizeObserver = class {
      constructor(callback) {
        this.callback = callback;
        this.targets = new Set();
        this.disconnects = 0;
        observers.push(this);
      }
      observe(el) {
        this.targets.add(el);
      }
      unobserve(el) {
        this.targets.delete(el);
      }
      disconnect() {
        this.disconnects++;
        this.targets.clear();
      }
      notify(...targets) {
        this.callback(targets.map((target) => ({ target })));
      }
    };
  document.defaultView = view;
  document.body = new Node(document, 'body');
  document.documentElement = new Node(document, 'html');
  return {
    document,
    view,
    events,
    queries,
    observers,
    timers,
    element() {
      return new Node(document);
    },
    flush() {
      const pending = [...timers.values()];
      timers.clear();
      pending.forEach((timer) => timer.fn());
    },
    emit(key) {
      events.get(key)?.forEach((fn) => fn());
    },
    filters() {
      return document.body.children[0]?.children[0]?.children || [];
    },
  };
}
const decode = (uri) => decodeURIComponent(uri.slice('data:image/svg+xml,'.length));

test('maps use source RGB ramps and real corner geometry instead of a universal pill', () => {
  const rectangle = decode(buildLiquidGlassMap(400, 240, ['16px', '20px', '24px', '12px']));
  const capsule = decode(buildLiquidGlassMap(400, 60, ['999px', '999px', '999px', '999px']));
  assert.match(rectangle, /viewBox="0 0 400 240"/);
  assert.match(rectangle, /M16 0H380A20 20/);
  assert.match(capsule, /M30 0H370A30 30/);
  assert.doesNotMatch(rectangle, /A120 120/);
  assert.equal((rectangle.match(/stop-color="#0000"/g) || []).length, 2);
  assert.match(rectangle, /filterUnits="userSpaceOnUse"/);
  assert.match(rectangle, /mix-blend-mode:difference/);
  assert.match(rectangle, /50% \/ .93/);
  assert.match(rectangle, /feGaussianBlur stdDeviation="11"/);
  assert.deepEqual(resolveGlassRadii(200, 100, ['20% 30%', '0', '0', '0']), [
    [40, 30],
    [0, 0],
    [0, 0],
    [0, 0],
  ]);
  assert.deepEqual(resolveGlassRadii(200, 100, ['999px', '999px', '999px', '999px']), [
    [50, 50],
    [50, 50],
    [50, 50],
    [50, 50],
  ]);
});

test('fallbacks cover pseudo-tooltips, reduced transparency, forced colors and white exceptions', () => {
  const compact = css.replace(/\s+/g, '').replace(/'/g, '"');
  assert.ok(compact.includes('@supportsnot((backdrop-filter:blur(1px))'));
  for (const media of [
    'prefers-reduced-transparency:reduce',
    'prefers-contrast:more',
    'forced-colors:active',
    'prefers-reduced-motion:reduce',
  ])
    assert.ok(compact.includes(media));
  assert.ok(compact.includes('.surface-white{background:#fff;background-image:none;'));
  assert.ok(compact.includes(':not(.surface-white):not([data-liquid-glass="off"])'));
  assert.match(compact, /\.zp-ai-help::after\{[\s\S]*?background:var\(--glass-fallback\)/);
  assert.doesNotMatch(engine, /requestAnimationFrame|setInterval|fetch\(/);
});

test('each refraction target owns its sized filter while sharing one observer and holder', () => {
  const f = fixture(),
    nav = f.element(),
    card = f.element();
  card.rect = { width: 300, height: 240 };
  card.corners = ['18px', '18px', '18px', '18px'];
  const releaseNav = initLiquidNav(nav),
    releaseCard = enhanceLiquidGlass(card);
  assert.equal(f.observers.length, 1);
  assert.equal(f.observers[0].targets.size, 2);
  assert.equal(f.document.body.children.length, 1);
  const [first, second] = f.filters();
  assert.notEqual(first.attributes.id, second.attributes.id);
  assert.equal(first.attributes.width, '400');
  assert.equal(second.attributes.height, '240');
  assert.equal(first.attributes.filterUnits, 'userSpaceOnUse');
  assert.equal(first.children[0].attributes.width, '400');
  assert.match(decode(second.children[0].attributes.href), /M18 0H282A18 18/);
  assert.deepEqual(
    first.children
      .filter((node) => node.name === 'feDisplacementMap')
      .map((node) => node.attributes.scale),
    ['-50', '-47', '-44'],
  );
  assert.ok(nav.classList.contains('is-liquid-refracted'));
  assert.match(nav.style.getPropertyValue('--liquid-glass-filter'), /url\("#liquid-glass-\d+"\)/);
  releaseNav();
  assert.equal(f.filters().length, 1);
  assert.equal(f.observers[0].targets.size, 1);
  releaseCard();
  assert.equal(f.document.body.children.length, 0);
  assert.equal(f.observers[0].targets.size, 0);
  assert.equal(f.timers.size, 0);
  assert.ok([...f.events.values()].every((set) => set.size === 0));
  assert.ok(f.queries.every((query) => query.listeners.size === 0));
});

test('resize bursts rebuild after 140ms settling and identical geometry never rewrites map', () => {
  const f = fixture(),
    el = f.element(),
    dispose = enhanceLiquidGlass(el);
  const image = f.filters()[0].children[0],
    initial = image.attributes.href;
  let writes = 0;
  const set = image.setAttribute.bind(image);
  image.setAttribute = (k, v) => {
    if (k === 'href') writes++;
    set(k, v);
  };
  el.rect.width = 500;
  for (let i = 0; i < 20; i++) f.observers[0].notify(el);
  assert.equal(el.measurements, 1);
  assert.equal(f.timers.size, 1);
  assert.equal([...f.timers.values()][0].delay, 140);
  assert.equal(image.attributes.href, initial);
  f.flush();
  assert.equal(el.measurements, 2);
  assert.equal(writes, 1);
  assert.match(decode(image.attributes.href), /viewBox="0 0 500 60"/);
  f.observers[0].notify(el);
  f.flush();
  assert.equal(writes, 1);
  el.corners = ['12px', '12px', '12px', '12px'];
  dispose.refresh();
  f.flush();
  assert.equal(writes, 2);
  assert.match(decode(image.attributes.href), /M12 0H488A12 12/);
  dispose();
});

test('repeat initialization is reference-counted and cleanup restores the preexisting inline property', () => {
  const f = fixture(),
    el = f.element();
  el.classList.add('liquid-glass');
  el.style.setProperty('--liquid-glass-filter', 'none', 'important');
  const a = enhanceLiquidGlass(el),
    b = enhanceLiquidGlass(el);
  assert.equal(f.filters().length, 1);
  assert.equal(f.observers.length, 1);
  a();
  a();
  assert.equal(f.filters().length, 1);
  b();
  b();
  assert.equal(f.filters().length, 0);
  assert.ok(el.classList.contains('liquid-glass'));
  assert.equal(el.style.getPropertyValue('--liquid-glass-filter'), 'none');
  assert.equal(el.style.getPropertyPriority('--liquid-glass-filter'), 'important');
});

test('preference changes and BFCache suspension remove refraction and restore it safely', () => {
  const f = fixture(),
    el = f.element(),
    dispose = enhanceLiquidGlass(el);
  f.queries[0].change(true);
  assert.equal(f.filters().length, 0);
  assert.equal(f.observers[0].targets.size, 0);
  assert.equal(el.classList.contains('is-liquid-refracted'), false);
  f.queries[0].change(false);
  assert.equal(f.filters().length, 1);
  assert.equal(f.observers.length, 1);
  f.emit('pagehide');
  assert.equal(f.filters().length, 0);
  f.emit('pageshow');
  assert.equal(f.filters().length, 1);
  dispose();
});

test('unsupported, reduced, hidden and explicitly white surfaces remain safe CSS fallbacks', () => {
  for (const config of [{ supported: false }, { reduced: true }]) {
    const f = fixture(config),
      el = f.element(),
      dispose = enhanceLiquidGlass(el);
    assert.ok(el.classList.contains('liquid-glass'));
    assert.equal(f.observers.length, 0);
    assert.equal(f.filters().length, 0);
    dispose();
  }
  const f = fixture(),
    white = f.element();
  white.classList.add('surface-white');
  enhanceLiquidGlass(white)();
  assert.equal(f.queries.length, 0);
  const hidden = f.element();
  hidden.rect = { width: 0, height: 0 };
  const dispose = enhanceLiquidGlass(hidden);
  assert.equal(f.filters().length, 0);
  hidden.rect = { width: 200, height: 80 };
  f.observers[0].notify(hidden);
  f.flush();
  assert.equal(f.filters().length, 1);
  hidden.isConnected = false;
  f.observers[0].notify(hidden);
  f.flush();
  assert.equal(f.filters().length, 0);
  dispose();
});

test('route initializer only enhances explicit opt-ins and detaches all owned resources', () => {
  const f = fixture(),
    root = f.element(),
    plain = f.element(),
    refract = f.element();
  plain.classList.add('liquid-glass');
  refract.setAttribute('data-liquid-glass', 'refract');
  root.append(plain, refract);
  const dispose = initLiquidGlass(root);
  assert.equal(f.filters().length, 1);
  assert.equal(plain.classList.contains('is-liquid-refracted'), false);
  f.observers[0].notify(refract);
  dispose();
  dispose();
  f.flush();
  assert.equal(f.filters().length, 0);
  assert.equal(f.observers[0].targets.size, 0);
  assert.equal(f.timers.size, 0);
  assert.doesNotThrow(() => initLiquidGlass({ querySelectorAll: () => [] })());
  assert.doesNotThrow(() => initLiquidGlass(null)());
  assert.doesNotThrow(() => initLiquidNav(null)());
});

test('resize events provide a bounded fallback when ResizeObserver is unavailable', () => {
  const f = fixture({ observer: false }),
    el = f.element(),
    dispose = enhanceLiquidGlass(el);
  el.rect.width = 600;
  f.emit('resize');
  assert.equal(f.timers.size, 1);
  f.flush();
  assert.equal(f.filters()[0].attributes.width, '600');
  dispose();
});

test('rotated and scaled surfaces use local border-box geometry for their maps', () => {
  const f = fixture(),
    el = f.element();
  el.offsetWidth = 155;
  el.offsetHeight = 184;
  el.rect = { width: 190, height: 215 };
  el.corners = ['18px', '18px', '18px', '18px'];
  const dispose = enhanceLiquidGlass(el);
  const filter = f.filters()[0];
  assert.equal(filter.attributes.width, '155');
  assert.equal(filter.attributes.height, '184');
  assert.match(decode(filter.children[0].attributes.href), /viewBox="0 0 155 184"/);
  assert.match(decode(filter.children[0].attributes.href), /M18 0H137A18 18/);
  assert.equal(el.measurements, 0);
  dispose();
});

test('scoped light material remains readable on dark OS and full opt-out survives fallback modes', () => {
  const compact = css.replace(/\s+/g, '').replace(/'/g, '"');
  assert.match(
    compact,
    /\.liquid-glass-theme-light,\[data-glass-theme="light"\]\{[^}]*--glass-surface:rgba\(255,255,255,0?\.28\)[^}]*--glass-text:#292630/s,
  );
  const fallback = compact.slice(compact.indexOf('@supportsnot'));
  assert.doesNotMatch(fallback, /:is\([^)]*\)(?::not\(\.surface-white\))?,\.zp-ai-help/);
  assert.match(fallback, /:not\(\[data-liquid-glass="off"\]\),\.zp-ai-help::after/);
});

test('React wrapper loads optional refraction only in a cleaned-up effect', async () => {
  const wrapper = await read('src/components/react-bits/GlassSurface.tsx');
  assert.match(wrapper, /useEffect/);
  assert.match(wrapper, /if \(!refract \|\| !element.current\) return/);
  assert.match(wrapper, /import\('\.\/GlassSurfaceEffect.js'\)/);
  assert.match(wrapper, /if \(!disposed\) cleanup = enhanceLiquidGlass\(target\)/);
  assert.match(wrapper, /disposed = true;\s*cleanup\?\.\(\)/);
});

// CSS syntax acceptance alone does not mean SVG backdrop filtering renders.
test('Safari and Firefox use the readable CSS fallback', () => {
  for (const userAgent of ['Mozilla Safari/605.1.15', 'Mozilla Firefox/143.0']) {
    const f = fixture();
    f.view.navigator = { userAgent };
    const dispose = enhanceLiquidGlass(f.element());
    assert.equal(f.filters().length, 0);
    assert.equal(f.observers.length, 0);
    dispose();
  }
});

test('shared material uses the React Bits frosted fallback highlights without a layout wrapper', async () => {
  assert.match(css, /brightness\(1\.04\)/);
  assert.match(css, /inset 0 1px 0 0/);
  const host = await read('src/components/react-bits/GlassSurface.tsx');
  assert.match(host, /glass-surface glass-surface--fallback/);
  assert.doesNotMatch(host, /glass-surface__content/);
});

test('all shared light and dark glass shadows soften only the three outer layers', () => {
  const shadows = [...css.matchAll(/--glass-shadow:\s*([^;]+);/g)].map((match) =>
    match[1].replace(/\s+/g, ' ').trim(),
  );
  const outer = (color) => `0 4px 16px ${color}, 0 8px 24px ${color}, 0 16px 56px ${color}`;
  const light =
    'inset 0 1px 0 0 rgb(255 255 255 / 85%), inset 0 -1px 0 0 rgb(255 255 255 / 35%), ' +
    'inset 0 0 2px 1px rgb(0 0 0 / 12%), inset 0 0 12px 3px rgb(255 255 255 / 28%), ' +
    outer('rgb(70 70 86 / 3%)');
  const dark =
    'inset 0 1px 0 0 rgb(255 255 255 / 30%), inset 0 -1px 0 0 rgb(255 255 255 / 8%), ' +
    'inset 0 0 2px 1px rgb(255 255 255 / 28%), inset 0 0 12px 3px rgb(255 255 255 / 10%), ' +
    outer('rgb(24 22 30 / 6%)');
  assert.deepEqual(shadows, [light, dark, dark, light]);
  // SVG enhancement and the no-backdrop fallback inherit the same box shadow.
  const svg = css.slice(
    css.indexOf('@supports (backdrop-filter:'),
    css.indexOf('.liquid-glass-defs'),
  );
  const fallback = css.slice(
    css.indexOf('@supports not'),
    css.indexOf('@media (prefers-reduced-motion'),
  );
  assert.doesNotMatch(svg + fallback, /box-shadow:/);
  assert.match(css, /box-shadow: var\(--glass-shadow\)/);
});
