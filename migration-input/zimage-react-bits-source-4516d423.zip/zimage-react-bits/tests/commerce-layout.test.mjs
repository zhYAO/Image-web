import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';

const dom = new JSDOM(
  `<style>${readFileSync('src/components/commerce/commerce.css', 'utf8')}</style>`,
);
const css = dom.window.document.styleSheets[0];

// Resolve the final declarations for an exact selector and viewport, including
// later overrides. These are CSS contracts, not a pixel-layout substitute.
function declarations(selector, width, height = 844) {
  const values = {};
  function visit(rules) {
    for (const rule of rules) {
      if (rule.type === 4) {
        const conditions = [
          ...rule.conditionText.matchAll(/\((min|max)-(width|height):\s*(\d+)px\)/g),
        ];
        if (
          conditions.length &&
          conditions.every(([, bound, axis, pixels]) => {
            const size = axis === 'width' ? width : height;
            return bound === 'max' ? size <= Number(pixels) : size >= Number(pixels);
          })
        )
          visit(rule.cssRules);
      } else if (rule.type === 1 && rule.selectorText === selector) {
        for (let index = 0; index < rule.style.length; index++) {
          const property = rule.style[index];
          values[property] = rule.style.getPropertyValue(property);
        }
      }
    }
  }
  visit(css.cssRules);
  return values;
}

test('commerce dialog animation never establishes a transformed fixed-menu containing block', () => {
  const animation = declarations('.cm-dialog[open]', 1440).animation;
  const name = animation.split(/\s+/)[0];
  const frames = [...css.cssRules].find((rule) => rule.type === 7 && rule.name === name);
  assert.ok(frames, 'dialog entrance keyframes exist');
  const properties = [...frames.cssRules].flatMap((frame) => Array.from(frame.style));
  assert.ok(properties.includes('opacity'));
  assert.equal(properties.includes('transform'), false);
  assert.equal(properties.includes('filter'), false);
});

test('mobile apparel has continuous form flow rather than a fractional inner scroll window', () => {
  const outlet = declarations('.cm-root.cm-editor-outlet:has(.cm-apparel-grid)', 390);
  assert.equal(outlet.height, 'auto');
  assert.equal(outlet.overflow, 'visible');
  const grid = declarations('.cm-editor-outlet .cm-apparel-grid', 390);
  assert.equal(grid['grid-template-rows'], 'auto auto');
  const scroll = declarations('.cm-editor-outlet .cm-apparel-grid .cm-config-scroll', 390);
  assert.equal(scroll.overflow, 'visible');
  assert.equal(scroll.flex, 'none');
  assert.equal(
    declarations('.cm-editor-outlet .cm-apparel-grid .cm-action-bar', 390).position,
    'static',
  );
  assert.deepEqual(declarations('.cm-root.cm-editor-outlet:has(.cm-apparel-grid)', 1440), {});
  assert.equal(declarations('.cm-editor-outlet .cm-config-scroll', 1440).overflow, 'auto');
});

test('mobile catalogue copy has two readable lines and A+ output selector spans its settings grid', () => {
  const copy = declarations('.cm-catalogue .cm-tool-copy p', 390);
  assert.equal(copy['white-space'], 'normal');
  assert.equal(copy['-webkit-line-clamp'], '2');
  assert.equal(declarations('.cm-catalogue .cm-tool-copy p', 1440)['white-space'], 'nowrap');
  assert.equal(declarations('.cm-detail-output-fields > .cm-field', 1440)['grid-column'], '1 / -1');
});
