import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';

test('landing and workspace brand marks share one canonical SVG', () => {
  for (const [file, name] of [
    ['landing/BrandMark.tsx', 'BrandMark'],
    ['workspace/WorkspaceMark.tsx', 'WorkspaceMark'],
  ]) {
    const source = readFileSync(new URL(`../src/components/${file}`, import.meta.url), 'utf8');
    assert.match(source, /from ['"]@\/components\/BrandMark['"]/);
    assert.ok(source.includes(name));
    assert.doesNotMatch(source, /<svg/);
  }
});

test('identity routes reuse the canonical mark instead of a lightning logo', () => {
  for (const file of ['AuthPage.tsx', 'LegalPage.tsx']) {
    const source = readFileSync(
      new URL(`../src/components/identity/${file}`, import.meta.url),
      'utf8',
    );
    assert.match(source, /from ['"]@\/components\/BrandMark['"]/);
    assert.match(source, /<BrandMark/);
    assert.doesNotMatch(source, /<Zap/);
  }
});
