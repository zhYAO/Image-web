import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';
const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'https://zimage.test' });
for (const key of ['window', 'document', 'navigator', 'HTMLElement', 'Node', 'MutationObserver']) {
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
}
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
const { render, act, cleanup } = await import('@testing-library/react');
const { AppProvider, usePreviewSessions } = await import('../src/components/AppProvider');
const { useSimulatedChat, simulatedAnswer } =
  await import('../src/components/workspace/useSimulatedChat');
let flow: ReturnType<typeof useSimulatedChat>;
let sessions: ReturnType<typeof usePreviewSessions>;
function Probe() {
  const value = useSimulatedChat();
  React.useEffect(() => {
    flow = value;
  });
  return null;
}
function Observer({ show = true }: { show?: boolean }) {
  const value = usePreviewSessions();
  React.useEffect(() => {
    sessions = value;
  });
  return show ? <Probe /> : null;
}
function mount() {
  return render(
    <AppProvider>
      <Observer />
    </AppProvider>,
  );
}
function begin() {
  let id = '';
  act(() => {
    id = sessions.createSession();
    assert.equal(flow.start(id, '陶瓷杯'), true);
  });
  return id;
}
function last(id: string) {
  return sessions.sessions.find((s) => s.id === id)?.messages.at(-1);
}
afterEach(cleanup);

test('simulation advances thinking to typing to done and prevents synchronous duplicate starts', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  mount();
  const id = begin();
  assert.equal(last(id)?.simulation?.status, 'thinking');
  act(() => {
    assert.equal(flow.start(id, 'duplicate'), false);
  });
  assert.equal(sessions.sessions.find((s) => s.id === id)?.messages.length, 1);
  act(() => t.mock.timers.tick(700));
  assert.equal(last(id)?.simulation?.step, 1);
  act(() => t.mock.timers.tick(700));
  act(() => t.mock.timers.tick(700));
  assert.equal(last(id)?.simulation?.status, 'typing');
  act(() => {
    flow.onTextChange('围绕');
    flow.complete();
  });
  assert.equal(last(id)?.simulation?.status, 'done');
  assert.equal(last(id)?.text, simulatedAnswer('陶瓷杯'));
  assert.equal(flow.run, null);
  act(() => sessions.selectSession(null));
  act(() => sessions.selectSession(id));
  assert.equal(flow.run, null, 'finished answer never restarts');
  assert.equal(last(id)?.simulation?.status, 'done');
});

test('stop retains partial text and cancels pending thinking steps', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  mount();
  const id = begin();
  act(() => {
    flow.onTextChange('保留的正文');
    flow.stop();
  });
  act(() => t.mock.timers.tick(10000));
  assert.equal(last(id)?.text, '保留的正文');
  assert.equal(last(id)?.simulation?.status, 'stopped');
  assert.equal(last(id)?.simulation?.step, 0);
  assert.equal(flow.isRunning(), false);
});

test('switching and deleting sessions cancel simulation without appending late output', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  mount();
  const id = begin();
  act(() => sessions.selectSession(null));
  act(() => t.mock.timers.tick(10000));
  assert.equal(last(id)?.simulation?.status, 'stopped');
  const deleted = begin();
  act(() => sessions.deleteSession(deleted));
  act(() => t.mock.timers.tick(10000));
  assert.equal(last(deleted), undefined);
  assert.equal(flow.run, null);
});

test('workspace unmount persists stopped state and releases pending work', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const view = mount();
  const id = begin();
  act(() => flow.onTextChange('partial'));
  view.rerender(
    <AppProvider>
      <Observer show={false} />
    </AppProvider>,
  );
  act(() => t.mock.timers.tick(10000));
  assert.equal(last(id)?.simulation?.status, 'stopped');
  assert.equal(last(id)?.text, 'partial');
  view.rerender(
    <AppProvider>
      <Observer />
    </AppProvider>,
  );
  assert.equal(flow.run, null);
});
