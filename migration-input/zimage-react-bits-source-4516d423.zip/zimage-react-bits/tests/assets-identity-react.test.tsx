import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';
import { registerHooks } from 'node:module';

registerHooks({
  load(url, context, next) {
    if (url.endsWith('.css'))
      return {
        format: 'module',
        source: 'export default new Proxy({}, {get:(_, name)=>String(name)})',
        shortCircuit: true,
      };
    return next(url, context);
  },
});

const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'https://zimage.test',
  pretendToBeVisual: true,
});
for (const key of [
  'window',
  'document',
  'navigator',
  'HTMLElement',
  'HTMLInputElement',
  'HTMLDialogElement',
  'Element',
  'Node',
  'Event',
  'MouseEvent',
  'KeyboardEvent',
  'MutationObserver',
])
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
Object.defineProperty(globalThis, 'self', { configurable: true, value: dom.window });
Object.defineProperty(window, 'matchMedia', {
  value: () => ({ matches: true, media: '', addEventListener() {}, removeEventListener() {} }),
});
HTMLElement.prototype.scrollIntoView = function () {};
HTMLDialogElement.prototype.showModal = function () {
  this.setAttribute('open', '');
};
HTMLDialogElement.prototype.close = function () {
  this.removeAttribute('open');
};
const { render, fireEvent, cleanup, act, waitFor } = await import('@testing-library/react');
const { default: AssetLibrary } = await import('../src/components/assets/AssetLibrary');
const { default: AuthPage } = await import('../src/components/identity/AuthPage');
const { default: AccountLedger } = await import('../src/components/identity/AccountLedger');
afterEach(() => cleanup());

test('asset search, favorite, selection and sort retain mounted card and decoded image identity', () => {
  const view = render(<AssetLibrary />);
  const originalCards = [...view.container.querySelectorAll<HTMLElement>('[data-asset-card]')];
  const originalImages = originalCards.map((card) => card.querySelector('img'));
  const first = originalCards[0];
  fireEvent.load(first.querySelector('img')!);
  fireEvent.click(view.getByRole('button', { name: '收藏 午后，听见暖意' }));
  assert.equal(
    view.getByRole('button', { name: '取消收藏 午后，听见暖意' }).getAttribute('aria-pressed'),
    'true',
  );
  fireEvent.change(view.getByRole('searchbox', { name: '搜索素材' }), {
    target: { value: '香氛' },
  });
  assert.equal(first.hidden, true);
  assert.equal(view.container.querySelectorAll('[data-asset-card]:not([hidden])').length, 2);
  fireEvent.click(view.getByRole('button', { name: '清空搜索' }));
  fireEvent.click(view.getByRole('combobox', { name: '素材排序' }));
  fireEvent.click(view.getByRole('option', { name: '名称排序' }));
  fireEvent.click(view.getByRole('checkbox', { name: '选择 午后，听见暖意' }));
  assert.equal(view.getByText('已选择 1 张').textContent, '已选择 1 张');
  originalCards.forEach((card, index) => {
    assert.equal(
      view.container.querySelector(`[data-asset-card="${card.dataset.assetCard}"]`),
      card,
    );
    assert.equal(card.querySelector('img'), originalImages[index]);
  });
  assert.equal(first.querySelector('img')?.className, 'is-loaded');
  fireEvent.click(view.getByRole('button', { name: '撤销' }));
  assert.equal(
    view.getByRole('button', { name: '收藏 午后，听见暖意' }).getAttribute('aria-pressed'),
    'false',
  );
});

test('asset preview contains only the full image and close/navigation controls, supports keyboard paging and restores focus', async () => {
  const view = render(<AssetLibrary />);
  const trigger = view.getByRole('button', { name: '查看 午后，听见暖意' });
  trigger.focus();
  fireEvent.click(trigger);
  const close = await view.findByRole('button', { name: '关闭图片' });
  const dialog = view.getByRole('dialog', { name: '午后，听见暖意' });
  const image = dialog.querySelector('img');
  assert.ok(image);
  assert.equal(document.activeElement, close);
  assert.equal(dialog.querySelectorAll('button').length, 3);
  assert.equal(dialog.querySelector('h2'), null);
  assert.equal(
    (view.getByRole('button', { name: '上一张图片' }) as HTMLButtonElement).disabled,
    true,
  );
  assert.equal(dialog.querySelector('dl'), null);
  assert.equal(dialog.querySelector('.za-detail-info'), null);
  assert.equal(dialog.querySelector('.za-detail-pager'), null);
  fireEvent.load(image);
  assert.equal(dialog.querySelector('img'), image);
  fireEvent.keyDown(dialog, { key: 'ArrowRight' });
  assert.notEqual(dialog.querySelector('img')?.getAttribute('src'), image.getAttribute('src'));
  assert.equal(document.activeElement, close);
  fireEvent.click(view.getByRole('button', { name: '上一张图片' }));
  assert.equal(dialog.querySelector('img')?.getAttribute('src'), image.getAttribute('src'));
  fireEvent(dialog, new Event('cancel', { bubbles: false, cancelable: true }));
  await waitFor(() => assert.equal(dialog.hasAttribute('open'), false));
  await waitFor(() => assert.equal(document.activeElement, trigger));
  fireEvent.click(trigger);
  fireEvent.click(await view.findByRole('button', { name: '关闭图片' }));
  await waitFor(() => assert.equal(dialog.hasAttribute('open'), false));
});

test('asset collection membership and undo remain available from selection controls', async () => {
  const view = render(<AssetLibrary />);
  const image = view.container.querySelector('[data-asset-card] img');
  fireEvent.click(view.getByRole('checkbox', { name: '选择 午后，听见暖意' }));
  fireEvent.click(view.getByRole('button', { name: '加入合集' }));
  const warm = await view.findByRole('button', { name: '从暖调日常移出' });
  fireEvent.click(warm);
  assert.equal(
    view.getByRole('button', { name: '加入暖调日常' }).getAttribute('aria-pressed'),
    'false',
  );
  fireEvent.click(view.getByRole('button', { name: '撤销' }));
  assert.equal(
    view.getByRole('button', { name: '从暖调日常移出' }).getAttribute('aria-pressed'),
    'true',
  );
  fireEvent.click(view.getByRole('button', { name: '完成' }));
  await waitFor(() =>
    assert.equal(view.container.querySelector('dialog')?.hasAttribute('open'), false),
  );
  assert.equal(view.container.querySelector('[data-asset-card] img'), image);
});

test('assets route uses one shared shell with canonical brand, current navigation and library content', async () => {
  const { AppRouterContext } =
    await import('next/dist/shared/lib/app-router-context.shared-runtime.js');
  const { AppProvider } = await import('../src/components/AppProvider');
  const { default: AssetsPage } = await import('../src/app/assets/page');
  const router = {
    push() {},
    replace() {},
    refresh() {},
    back() {},
    forward() {},
    prefetch: async () => {},
    hmrRefresh() {},
  };
  const view = render(
    <AppRouterContext.Provider value={router}>
      <AppProvider>
        <AssetsPage />
      </AppProvider>
    </AppRouterContext.Provider>,
  );
  assert.equal(view.container.querySelectorAll('main').length, 1);
  assert.equal(view.container.querySelectorAll('[data-workspace-shell]').length, 1);
  assert.ok(view.getByRole('complementary', { name: '会话侧栏' }));
  assert.ok(view.getByRole('link', { name: 'ZImage 品牌首页' }));
  assert.equal(view.getByRole('link', { name: '资产库' }).getAttribute('aria-current'), 'page');
  assert.equal(view.container.querySelector('.za-header'), null);
  assert.ok(view.container.querySelector('[data-workspace-shell] main .za-assets-host'));
});

test('phone login validates mainland numbers and six digit codes without collecting passwords', async () => {
  const view = render(<AuthPage />);
  const phone = view.getByLabelText('手机号') as HTMLInputElement;
  const code = view.getByLabelText('6 位数字验证码') as HTMLInputElement;
  assert.equal(view.queryByLabelText('邮箱'), null);
  assert.equal(view.container.querySelector('input[type="password"]'), null);
  assert.ok(view.getByText(/仅供前端演示/));
  assert.ok(view.getByText('+86'));
  fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' }));
  assert.equal(view.getByRole('alert').textContent, '请输入手机号。');
  assert.equal(document.activeElement, phone);
  fireEvent.change(phone, { target: { value: '12800138000' } });
  fireEvent.click(view.getByRole('button', { name: '获取演示验证码' }));
  assert.equal(view.getByRole('alert').textContent, '请输入有效的中国大陆 11 位手机号。');
  fireEvent.change(phone, { target: { value: '13800138000' } });
  fireEvent.change(code, { target: { value: '12a3' } });
  fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' }));
  assert.equal(view.getByRole('alert').textContent, '请输入 6 位数字验证码。');
  assert.equal(document.activeElement, code);
  fireEvent.change(code, { target: { value: '123456' } });
  fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' }));
  assert.equal(view.getByRole('alert').textContent, '请先获取当前手机号的演示验证码。');
  await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
  assert.ok(view.getByRole('button', { name: '60 秒后重新获取' }).hasAttribute('disabled'));
  fireEvent.change(code, { target: { value: '654321' } });
  view.getByRole('button', { name: '验证并继续（演示）' }).focus();
  await act(async () => fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' })));
  assert.equal(view.getByRole('alert').textContent, '演示验证码不正确，请输入 123456。');
  assert.equal(
    document.activeElement?.id,
    code.id,
    'async validation restores focus after fields are re-enabled',
  );
  fireEvent.change(code, { target: { value: '123456' } });
  await act(async () => fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' })));
  assert.match(view.getByRole('status').textContent ?? '', /演示校验完成，尚未登录/);
  assert.equal(code.value, '');
  assert.equal(view.getByLabelText('手机号'), phone);
  assert.equal(view.getByLabelText('6 位数字验证码'), code);
  assert.equal(window.location.pathname, '/');
  assert.equal(window.localStorage.length, 0);
  assert.equal(window.sessionStorage.length, 0);
});

test('legacy auth routes explain unavailability without collecting obsolete credentials', () => {
  const view = render(<AuthPage mode="register" />);
  for (const mode of ['register', 'recovery', 'verify', 'reset'] as const) {
    view.rerender(<AuthPage mode={mode} />);
    assert.equal(view.container.querySelector('input'), null);
    assert.equal(view.container.querySelector('form'), null);
    assert.ok(view.getByRole('link', { name: '返回手机号登录' }));
    assert.match(view.getByRole('status').textContent ?? '', /未开放|未接入/);
  }
});

test('ledger can reveal all supplied records without inventing account data', () => {
  const records = Array.from({ length: 5 }, (_, i) => ({
    id: `${i}`,
    time: `记录 ${i}`,
    purpose: `创作 ${i}`,
    type: '消费',
    amount: '− 0.80',
  }));
  const ledger = render(<AccountLedger records={records} onRetry={() => {}} />);
  assert.equal(ledger.container.querySelectorAll('tbody tr').length, 3);
  fireEvent.click(ledger.getByRole('button', { name: '加载更多' }));
  assert.equal(ledger.container.querySelectorAll('tbody tr').length, 5);
  assert.equal(ledger.getByRole('status').textContent, '已显示全部流水');
});

test('server-rendered phone credentials stay disabled until React handlers are active', async () => {
  const { renderToString } = await import('react-dom/server');
  const html = new JSDOM(renderToString(<AuthPage />)).window.document;
  assert.ok(html.querySelector<HTMLFieldSetElement>('form fieldset')?.disabled);
  assert.equal(html.querySelector('form')?.method, 'post');
  assert.ok(html.querySelector<HTMLButtonElement>('form button[type="submit"]')?.disabled);
  assert.ok(html.querySelector<HTMLButtonElement>('form button[type="button"]')?.disabled);
  const view = render(<AuthPage />);
  assert.equal(view.container.querySelector<HTMLFieldSetElement>('form fieldset')?.disabled, false);
  fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' }));
  assert.equal(view.getByRole('alert').textContent, '请输入手机号。');
});

test('account presents an unconnected phone login state without accepting passwords', async () => {
  const { AppRouterContext } =
    await import('next/dist/shared/lib/app-router-context.shared-runtime.js');
  const { AppProvider } = await import('../src/components/AppProvider');
  const { default: AccountPage } = await import('../src/components/identity/AccountPage');
  const router = {
    push() {},
    replace() {},
    refresh() {},
    back() {},
    forward() {},
    prefetch: async () => {},
    hmrRefresh() {},
  };
  const view = render(
    <AppRouterContext.Provider value={router}>
      <AppProvider>
        <AccountPage />
      </AppProvider>
    </AppRouterContext.Provider>,
  );
  assert.equal(view.container.querySelector('input[type="password"]'), null);
  assert.ok(view.getByText('手机号尚未绑定 · 账号服务未接入'));
  assert.ok(view.getByText(/无需设置密码/));
  assert.ok(view.getByText(/不代表已登录/));
  assert.ok(view.getByRole('link', { name: '前往手机号登录' }));
});

test('auth pathname navigation preserves its shell but clears phone credentials and countdown on leaving login', async () => {
  const { PathnameContext } =
    await import('next/dist/shared/lib/hooks-client-context.shared-runtime.js');
  const { default: AuthLayout } = await import('../src/app/(identity-auth)/layout');
  const route = (pathname: string) => (
    <PathnameContext.Provider value={pathname}>
      <AuthLayout>{null}</AuthLayout>
    </PathnameContext.Provider>
  );
  const view = render(route('/login/'));
  const selectors = [
    '.zi-auth-screen',
    '.zi-auth-visual',
    '.zi-auth-story',
    '.zi-auth-reveal',
    '.zi-auth-card',
    '.zi-auth-scroll',
  ];
  const nodes = selectors.map((selector) => view.container.querySelector(selector));
  assert.ok(nodes.every(Boolean));
  fireEvent.change(view.getByLabelText('手机号'), { target: { value: '13800138000' } });
  await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
  fireEvent.change(view.getByLabelText('6 位数字验证码'), { target: { value: '123456' } });
  const originalForm = view.container.querySelector('form');
  view.rerender(route('/auth/'));
  assert.equal(
    view.container.querySelector('form'),
    originalForm,
    'equivalent aliases retain the form',
  );
  assert.equal((view.getByLabelText('手机号') as HTMLInputElement).value, '13800138000');
  for (const pathname of [
    '/register/',
    '/forgot-password/',
    '/auth/register/',
    '/auth/recovery/',
    '/auth/verify/',
    '/auth/reset/',
  ]) {
    view.rerender(route(pathname));
    selectors.forEach((selector, index) =>
      assert.equal(view.container.querySelector(selector), nodes[index]),
    );
    assert.equal(view.container.querySelector('input'), null);
  }
  view.rerender(route('/login'));
  assert.notEqual(view.container.querySelector('form'), originalForm);
  assert.equal((view.getByLabelText('手机号') as HTMLInputElement).value, '');
  assert.equal((view.getByLabelText('6 位数字验证码') as HTMLInputElement).value, '');
  assert.equal(
    view.getByRole('button', { name: '获取演示验证码' }).hasAttribute('disabled'),
    false,
  );
  assert.equal(view.queryByRole('alert'), null);
});

test('phone requests guard synchronous duplicates and abort stale phone responses', async () => {
  const requests: {
    phone: { countryCode: '+86'; number: string };
    signal: AbortSignal;
    resolve: (value: { id: string; retryAfterSeconds: number }) => void;
  }[] = [];
  const service = {
    requestCode(
      phone: { countryCode: '+86'; number: string },
      { signal }: { signal: AbortSignal },
    ) {
      return new Promise<{ id: string; retryAfterSeconds: number }>((resolve) =>
        requests.push({ phone, signal, resolve }),
      );
    },
    async verifyCode() {
      return { kind: 'demo-verified' as const };
    },
  };
  const view = render(<AuthPage phoneAuth={service} />);
  const phone = view.getByLabelText('手机号');
  fireEvent.change(phone, { target: { value: '13800138000' } });
  const request = view.getByRole('button', { name: '获取演示验证码' });
  act(() => {
    fireEvent.click(request);
    fireEvent.click(request);
  });
  assert.equal(requests.length, 1);
  assert.deepEqual(requests[0].phone, { countryCode: '+86', number: '13800138000' });
  assert.equal((phone as HTMLInputElement).disabled, true);
  fireEvent.change(phone, { target: { value: '13900139000' } });
  assert.equal(requests[0].signal.aborted, true);
  fireEvent.click(view.getByRole('button', { name: '获取演示验证码' }));
  assert.equal(requests.length, 2);
  await act(async () => requests[0].resolve({ id: 'stale', retryAfterSeconds: 60 }));
  assert.ok(view.getByRole('button', { name: '获取中…' }).hasAttribute('disabled'));
  await act(async () => requests[1].resolve({ id: 'current', retryAfterSeconds: 60 }));
  assert.ok(view.getByRole('button', { name: '60 秒后重新获取' }).hasAttribute('disabled'));
  fireEvent.change(phone, { target: { value: '13800138000' } });
  fireEvent.change(view.getByLabelText('6 位数字验证码'), { target: { value: '123456' } });
  fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' }));
  assert.equal(view.getByRole('alert').textContent, '请先获取当前手机号的演示验证码。');
});

test('phone verification guards duplicate submissions and ignores completion after navigation', async () => {
  const checks: {
    input: unknown;
    signal: AbortSignal;
    resolve: (result: { kind: 'demo-verified' }) => void;
  }[] = [];
  const service = {
    async requestCode() {
      return { id: 'local-challenge', retryAfterSeconds: 60 };
    },
    verifyCode(input: unknown, { signal }: { signal: AbortSignal }) {
      return new Promise<{ kind: 'demo-verified' }>((resolve) =>
        checks.push({ input, signal, resolve }),
      );
    },
  };
  const view = render(<AuthPage phoneAuth={service} />);
  fireEvent.change(view.getByLabelText('手机号'), { target: { value: '13800138000' } });
  await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
  fireEvent.change(view.getByLabelText('6 位数字验证码'), { target: { value: '123456' } });
  const form = view.container.querySelector('form')!;
  act(() => {
    fireEvent.submit(form);
    fireEvent.submit(form);
  });
  assert.equal(checks.length, 1);
  assert.deepEqual(checks[0].input, {
    countryCode: '+86',
    number: '13800138000',
    code: '123456',
    challengeId: 'local-challenge',
  });
  view.rerender(<AuthPage mode="recovery" phoneAuth={service} />);
  assert.equal(checks[0].signal.aborted, true);
  await act(async () => checks[0].resolve({ kind: 'demo-verified' }));
  assert.equal(view.queryByText(/演示校验完成/), null);
  view.rerender(<AuthPage phoneAuth={service} />);
  assert.equal((view.getByLabelText('6 位数字验证码') as HTMLInputElement).value, '');
});

test('resend uses elapsed wall time and clears its interval on unmount', async (t) => {
  t.mock.timers.enable({ apis: ['Date', 'setInterval'], now: 1000 });
  const view = render(
    <React.StrictMode>
      <AuthPage />
    </React.StrictMode>,
  );
  fireEvent.change(view.getByLabelText('手机号'), { target: { value: '13800138000' } });
  await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
  act(() => t.mock.timers.tick(1000));
  assert.ok(view.getByRole('button', { name: '59 秒后重新获取' }).hasAttribute('disabled'));
  act(() => {
    t.mock.timers.setTime(61_000);
    t.mock.timers.tick(1000);
  });
  assert.equal(
    view.getByRole('button', { name: '获取演示验证码' }).hasAttribute('disabled'),
    false,
  );
  await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
  const clearInterval = t.mock.method(globalThis, 'clearInterval');
  view.unmount();
  assert.equal(clearInterval.mock.callCount(), 1);
  act(() => t.mock.timers.tick(120_000));
  assert.equal(view.container.innerHTML, '');
});

test('phone service errors allow retries and never expose raw provider errors', async () => {
  let requestAttempts = 0;
  let verifyAttempts = 0;
  const service = {
    async requestCode() {
      requestAttempts++;
      if (requestAttempts === 1) throw new Error('private provider payload');
      return { id: 'retry-challenge', retryAfterSeconds: 0 };
    },
    async verifyCode() {
      verifyAttempts++;
      if (verifyAttempts === 1) throw new Error('private provider payload');
      return { kind: 'demo-verified' as const };
    },
  };
  const view = render(<AuthPage phoneAuth={service} />);
  fireEvent.change(view.getByLabelText('手机号'), { target: { value: '13800138000' } });
  await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
  assert.equal(view.getByRole('alert').textContent, '暂时无法获取演示验证码，请重试。');
  assert.equal(
    view.getByRole('button', { name: '获取演示验证码' }).hasAttribute('disabled'),
    false,
  );
  await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
  fireEvent.change(view.getByLabelText('6 位数字验证码'), { target: { value: '123456' } });
  await act(async () => fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' })));
  assert.equal(view.getByRole('alert').textContent, '暂时无法完成演示校验，请重试。');
  await act(async () => fireEvent.click(view.getByRole('button', { name: '验证并继续（演示）' })));
  assert.match(view.getByRole('status').textContent ?? '', /演示校验完成/);
  assert.equal(requestAttempts, 2);
  assert.equal(verifyAttempts, 2);
  assert.equal(view.queryByText(/private provider payload/), null);
});

test('leaving login aborts a pending code request even if the adapter ignores cancellation', async () => {
  let requestSignal: AbortSignal | undefined;
  let finish!: (value: { id: string; retryAfterSeconds: number }) => void;
  const service = {
    requestCode(_phone: unknown, { signal }: { signal: AbortSignal }) {
      requestSignal = signal;
      return new Promise<{ id: string; retryAfterSeconds: number }>((resolve) => {
        finish = resolve;
      });
    },
    async verifyCode() {
      return { kind: 'demo-verified' as const };
    },
  };
  const view = render(<AuthPage phoneAuth={service} />);
  fireEvent.change(view.getByLabelText('手机号'), { target: { value: '13800138000' } });
  fireEvent.click(view.getByRole('button', { name: '获取演示验证码' }));
  view.rerender(<AuthPage mode="register" phoneAuth={service} />);
  assert.equal(requestSignal?.aborted, true);
  await act(async () => finish({ id: 'late', retryAfterSeconds: 60 }));
  view.rerender(<AuthPage phoneAuth={service} />);
  assert.equal(
    view.getByRole('button', { name: '获取演示验证码' }).hasAttribute('disabled'),
    false,
  );
  assert.equal(view.queryByRole('status'), null);
});

for (const nextClickDetail of [0, 1]) {
  test(`completed phone demo ignores the second physical click but accepts a later detail-${nextClickDetail} activation`, async () => {
    const view = render(<AuthPage />);
    fireEvent.change(view.getByLabelText('手机号'), { target: { value: '13800138000' } });
    await act(async () => fireEvent.click(view.getByRole('button', { name: '获取演示验证码' })));
    fireEvent.change(view.getByLabelText('6 位数字验证码'), { target: { value: '123456' } });
    const submit = view.getByRole('button', { name: '验证并继续（演示）' });

    // Real double-clicks span separate event turns: the local service can finish between them.
    await act(async () => fireEvent.click(submit, { detail: 1 }));
    const completion = view.getByRole('status').textContent;
    assert.match(completion ?? '', /演示校验完成，尚未登录/);
    assert.equal((view.getByLabelText('6 位数字验证码') as HTMLInputElement).value, '');
    await act(async () => fireEvent.click(submit, { detail: 2 }));
    fireEvent.doubleClick(submit, { detail: 2 });
    assert.equal(view.queryByRole('alert')?.textContent, undefined);
    assert.equal(view.getByRole('status').textContent, completion);

    // Keyboard activation uses detail 0; a new independent pointer click uses detail 1.
    fireEvent.click(submit, { detail: nextClickDetail });
    assert.equal(view.getByRole('alert').textContent, '请输入 6 位数字验证码。');
    assert.equal(document.activeElement?.id, 'zi-phone-code');
  });
}
