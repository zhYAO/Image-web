import './register-css.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';

const component = new URL('../src/components/landing/PillNavCTA.tsx', import.meta.url);
const cssPath = new URL('../src/components/landing/pill-nav-cta.css', import.meta.url);

test('homepage hero and final Start Creating links retain the Pill Nav adapter', () => {
  const page = readFileSync(
    new URL('../src/components/landing/LandingPage.tsx', import.meta.url),
    'utf8',
  );
  assert.equal((page.match(/<PillNavCTA\s*\/>/g) || []).length, 2);
});

test('Pill Nav CTA preserves native Next Link and one accessible text label', async () => {
  assert.ok(existsSync(component), 'CTA adapter must exist');
  const React = await import('react');
  const { renderToStaticMarkup } = await import('react-dom/server');
  const { PillNavCTA } = await import(component);
  const { JSDOM } = await import('jsdom');
  const markup = renderToStaticMarkup(React.createElement(PillNavCTA));
  const document = new JSDOM(markup).window.document;
  const link = document.querySelector('a');
  assert.equal(link.getAttribute('href'), '/workspace');
  assert.ok(link.classList.contains('zl-button-primary'));
  assert.equal(link.querySelector('.zl-pill-cta-label').textContent.trim(), '开始创作');
  assert.equal(link.querySelector('.zl-pill-cta-label-alt').getAttribute('aria-hidden'), 'true');
  assert.equal(document.querySelectorAll('a, button').length, 1);
  const source = readFileSync(component, 'utf8');
  assert.match(source, /import Link from 'next\/link'/);
  assert.doesNotMatch(source, /prefetch=|use client|useEffect|requestAnimationFrame|gsap/);
});

test('Pill Nav fill and label motion are scoped, finite, keyboard-accessible and motion-safe', () => {
  assert.ok(existsSync(cssPath), 'scoped motion CSS must exist');
  const css = readFileSync(cssPath, 'utf8');
  assert.match(css, /border-radius: 50%/);
  assert.match(css, /scale\(0\)/);
  assert.match(css, /scale\(1\)/);
  assert.match(css, /translateY\(-100%\)/);
  assert.match(css, /:focus-visible/);
  assert.match(css, /@media \(hover: hover\) and \(pointer: fine\)/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
  assert.match(css, /@media \(forced-colors: active\)/);
  assert.match(css, /transition: none/);
  assert.doesNotMatch(css, /infinite|@keyframes|will-change/);
});

test('Pill Nav carries the full pinned license into the static distribution', () => {
  const license = readFileSync(new URL('../licenses/pill-nav-LICENSE.md', import.meta.url), 'utf8');
  const publicLicense = readFileSync(
    new URL('../public/licenses/pill-nav-LICENSE.md', import.meta.url),
    'utf8',
  );
  assert.equal(publicLicense, license);
  assert.match(license, /Copyright \(c\) 2026 David Haz/);
  assert.match(license, /MIT \+ Commons Clause/);
  assert.match(license, /Background Studio, Texture Lab/);
  const notice = readFileSync(
    new URL('../public/licenses/pill-nav-NOTICE.txt', import.meta.url),
    'utf8',
  );
  assert.match(notice, /c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/);
  assert.match(notice, /pill-nav-LICENSE\.md/);
});

test('static preference resets outrank active hover and focus label motion', () => {
  const css = readFileSync(cssPath, 'utf8');
  for (const preference of ['prefers-reduced-motion: reduce', 'forced-colors: active']) {
    const block = css.slice(css.indexOf(`@media (${preference})`));
    assert.match(
      block,
      /\.zl-root \.zl-pill-cta:is\(:hover, :focus-visible\) \.zl-pill-cta-label\s*\{[^}]*transform: none;[^}]*transition: none;/,
      `${preference} must override both active selectors at matching specificity`,
    );
  }
});

test('navigation shares Pill Nav motion while retaining compact geometry and menu closing', () => {
  const nav = readFileSync(
    new URL('../src/components/landing/LandingNav.tsx', import.meta.url),
    'utf8',
  );
  assert.match(nav, /<PillNavCTA variant="nav" onClick=\{\(\) => setOpen\(false\)\} \/>/);
  const css = readFileSync(cssPath, 'utf8');
  assert.match(css, /:is\(\.zl-button, \.zl-nav-cta\)\.zl-pill-cta:hover/);
});
