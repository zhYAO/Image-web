import test from 'node:test';
import assert from 'node:assert/strict';
import { restoreDraftConfiguration } from '../src/components/commerce/commerce-drafts';
import {
  createEditorState,
  draftConfiguration,
  validateUploadFiles,
} from '../src/components/commerce/commerce-state';

test('draft hydration tolerates malformed objects and validates count and enum bounds', () => {
  const defaults = createEditorState();
  for (const input of [null, [], 'bad draft', { modules: null, counts: null }]) {
    assert.deepEqual(restoreDraftConfiguration(input), defaults);
  }
  const restored = restoreDraftConfiguration({
    counts: { white: 20, selling: 20, scene: 0, other: 0 },
    count: 100,
    modules: ['unknown module'],
    ratio: 'invalid',
    advanced: 'true',
    listing: null,
    apparelVersion: -1,
    cloneMode: 'invalid',
    sceneTab: 'invalid',
    source: 'invalid',
  });
  assert.deepEqual(restored, defaults);
});

test('draft hydration preserves safe configuration without restoring transient state or blob URLs', () => {
  const restored = restoreDraftConfiguration({
    description: '<img src=x onerror=alert(1)>',
    stage: 'review',
    busy: true,
    view: 'results',
    references: [{ url: 'blob:stale' }],
    results: [{ id: 'stale' }],
    apparelSaved: true,
    progress: 100,
    error: 'stale',
    modules: ['品牌故事', '核心卖点', '品牌故事'],
    ratio: '3:4',
    count: 4,
    copy: { 品牌故事: '保留文案', 核心卖点: { invalid: true }, unknown: 'ignored' },
    counts: { white: 2, selling: 1, scene: 0, other: 0, extra: 100 },
    layouts: ['左文右图', 'invalid'],
    listing: { title: '标题', unexpected: 'ignored' },
  });
  assert.equal(restored.description, '<img src=x onerror=alert(1)>');
  assert.deepEqual(restored.modules, ['品牌故事', '核心卖点']);
  assert.deepEqual(restored.copy, { 品牌故事: '保留文案' });
  assert.deepEqual(restored.counts, { white: 2, selling: 1, scene: 0, other: 0 });
  assert.deepEqual(restored.layouts, ['左文右图', '自动分配']);
  assert.deepEqual(restored.listing, { title: '标题' });
  assert.equal(restored.ratio, '3:4');
  assert.equal(restored.count, 4);
  assert.equal(restored.stage, 'configure');
  assert.equal(restored.view, 'examples');
  assert.equal(restored.busy, false);
  assert.equal(restored.apparelSaved, false);
  assert.equal(restored.progress, 0);
  assert.equal(restored.error, '');
  assert.deepEqual(restored.references, []);
  assert.deepEqual(restored.results, []);
});

test('valid saved configuration round-trips without sharing mutable collections', () => {
  const state = createEditorState();
  state.description = '已确认的商品信息';
  state.modules.reverse();
  state.copy = { 品牌首屏: '标题' };
  state.apparel = { name: '商品名称' };
  const saved = draftConfiguration(state);
  const restored = restoreDraftConfiguration(saved);
  assert.deepEqual(restored, state);
  restored.modules.push('品牌故事');
  restored.counts.white++;
  restored.copy.品牌首屏 = '新标题';
  assert.equal(state.modules.includes('品牌故事'), false);
  assert.equal(state.counts.white, 1);
  assert.equal(state.copy.品牌首屏, '标题');
});

test('commerce uploads reject empty files before creating image object URLs', () => {
  assert.match(
    validateUploadFiles(
      'product-set',
      'product',
      [{ name: 'empty.png', type: 'image/png', size: 0 }],
      [],
    ),
    /空文件/,
  );
});

test('image model preference survives explicit save while obsolete and chat-only models fall back', () => {
  const state = createEditorState();
  state.modelId = 'qwen-image-3.0-pro';
  assert.equal(restoreDraftConfiguration(draftConfiguration(state)).modelId, state.modelId);
  for (const modelId of ['gpt-6.1-sol', 'removed-image-model', 42, null, {}]) {
    assert.equal(restoreDraftConfiguration({ modelId }).modelId, createEditorState().modelId);
  }
  assert.equal(
    restoreDraftConfiguration({ description: 'older draft' }).modelId,
    createEditorState().modelId,
  );
});
