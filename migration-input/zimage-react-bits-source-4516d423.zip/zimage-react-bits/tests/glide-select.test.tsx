import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import fs from 'node:fs';
import React, { useState } from 'react';
const dom = new JSDOM('<!doctype html><html><body></body></html>', { pretendToBeVisual: true });
for (const key of [
  'window',
  'document',
  'navigator',
  'HTMLElement',
  'Element',
  'Node',
  'Event',
  'MouseEvent',
  'KeyboardEvent',
  'MutationObserver',
])
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
HTMLElement.prototype.scrollIntoView = function () {};
const { render, fireEvent, cleanup } = await import('@testing-library/react');
const { default: GlideSelect, glideMenuHeight } =
  await import('../src/components/react-bits/GlideSelect');
afterEach(cleanup);
function Controlled() {
  const [value, setValue] = useState('Alpha');
  return (
    <GlideSelect
      ariaLabel="Sort"
      value={value}
      onChange={setValue}
      options={['Alpha', 'Beta', 'Bravo', 'Charlie']}
    />
  );
}
test('controlled selection supports multi-character typeahead, Home/End, click, Escape and focus', () => {
  const view = render(<Controlled />);
  const combo = view.getByRole('combobox');
  fireEvent.keyDown(combo, { key: 'End' });
  let list = view.getByRole('listbox');
  assert.equal(document.activeElement, list);
  fireEvent.keyDown(list, { key: 'Home' });
  fireEvent.keyDown(list, { key: 'b' });
  fireEvent.keyDown(list, { key: 'r' });
  fireEvent.keyDown(list, { key: 'Enter' });
  assert.match(combo.textContent!, /Bravo/);
  assert.equal(document.activeElement, combo);
  fireEvent.click(combo);
  fireEvent.click(view.getByRole('option', { name: 'Charlie' }));
  assert.match(combo.textContent!, /Charlie/);
  fireEvent.click(combo);
  list = view.getByRole('listbox');
  fireEvent.scroll(list);
  assert.ok(view.getByRole('listbox'));
  fireEvent.keyDown(list, { key: 'Escape' });
  assert.equal(view.queryByRole('listbox'), null);
  assert.equal(document.activeElement, combo);
});
test('portal remains inside enclosing dialog, is viewport bounded and cleans up on outside interaction', () => {
  const view = render(
    <dialog open>
      <Controlled />
    </dialog>,
  );
  const combo = view.getByRole('combobox');
  combo.getBoundingClientRect = () => ({
    left: 1000,
    right: 1100,
    top: 730,
    bottom: 765,
    width: 100,
    height: 35,
    x: 1000,
    y: 730,
    toJSON() {},
  });
  fireEvent.click(combo);
  const menu = view.getByRole('listbox').parentElement!;
  assert.equal(menu.parentElement, view.getByRole('dialog'));
  assert.ok(parseFloat(menu.style.left) + parseFloat(menu.style.width) <= window.innerWidth - 12);
  assert.ok(parseFloat(menu.style.top) >= 12);
  assert.ok(parseFloat(menu.style.maxHeight) <= 280);
  fireEvent.pointerDown(document.body);
  assert.equal(view.queryByRole('listbox'), null);
  fireEvent.click(combo);
  fireEvent.resize(window);
  assert.equal(view.queryByRole('listbox'), null);
});
test('empty or disabled options cannot open; disabling an open popup closes it', () => {
  const view = render(<GlideSelect options={[]} />);
  assert.equal(view.getByRole('combobox').hasAttribute('disabled'), true);
  view.rerender(<GlideSelect options={['One']} />);
  fireEvent.click(view.getByRole('combobox'));
  assert.ok(view.getByRole('listbox'));
  view.rerender(<GlideSelect options={['One']} disabled />);
  assert.equal(view.queryByRole('listbox'), null);
});

test('resize and outer scroll restore popup focus without stealing outside focus', () => {
  const view = render(
    <>
      <Controlled />
      <button>Outside</button>
    </>,
  );
  const combo = view.getByRole('combobox');
  const outside = view.getByRole('button', { name: 'Outside' });
  fireEvent.click(combo);
  assert.equal(document.activeElement, view.getByRole('listbox'));
  fireEvent.resize(window);
  assert.equal(document.activeElement, combo);
  fireEvent.click(combo);
  fireEvent.scroll(document.body);
  assert.equal(view.queryByRole('listbox'), null);
  assert.equal(document.activeElement, combo);
  fireEvent.click(combo);
  outside.focus();
  fireEvent.resize(window);
  assert.equal(document.activeElement, outside);
  fireEvent.click(combo);
  outside.focus();
  fireEvent.pointerDown(outside);
  assert.equal(document.activeElement, outside);
  assert.equal(view.queryByRole('listbox'), null);
});

test('shrinking open options keeps an existing active descendant and selectable value', () => {
  let selected = '';
  const onChange = (value: string) => {
    selected = value;
  };
  const view = render(<GlideSelect options={['One', 'Two', 'Three']} onChange={onChange} />);
  fireEvent.keyDown(view.getByRole('combobox'), { key: 'End' });
  view.rerender(<GlideSelect options={['One']} onChange={onChange} />);
  const list = view.getByRole('listbox');
  const active = document.getElementById(list.getAttribute('aria-activedescendant')!);
  assert.equal(active, view.getByRole('option', { name: 'One' }));
  fireEvent.keyDown(list, { key: 'Enter' });
  assert.equal(selected, 'One');
  assert.equal(view.queryByRole('listbox'), null);
});

test('menu height includes exact row gaps, padding and borders without a spurious short-list scrollbar', () => {
  for (const row of [26, 30, 40]) {
    for (const count of [1, 2, 3]) {
      assert.equal(glideMenuHeight(count, row), count * row + (count - 1) + 8 + 2);
    }
  }
  assert.equal(glideMenuHeight(2, 30), 71);
  assert.equal(glideMenuHeight(20, 30), 280);
  const view = render(<GlideSelect options={['Desktop', 'Desktop and mobile']} />);
  fireEvent.click(view.getByRole('combobox'));
  assert.equal(view.getByRole('listbox').parentElement!.style.maxHeight, '71px');
});

test('menu grid can shrink inside border-box width and scrolls only vertically', () => {
  const css = fs.readFileSync('src/components/react-bits/GlideSelect.css', 'utf8');
  assert.match(css, /\.glide-select__list\s*\{[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)/);
  assert.match(css, /\.glide-select__option\s*\{[^}]*min-width:\s*0/);
  assert.match(css, /\.glide-select__menu\s*\{[^}]*overflow-x:\s*hidden;[^}]*overflow-y:\s*auto/);
});

test('rich option labels use explicit readable text for naming and typeahead', () => {
  let selected = '';
  const view = render(
    <GlideSelect
      ariaLabel="Model"
      includeValueInLabel
      value="provider-a"
      onChange={(value) => {
        selected = value;
      }}
      options={[
        {
          value: 'provider-a',
          label: (
            <span>
              <svg aria-hidden="true" />
              Alpha model
            </span>
          ),
          textValue: 'Alpha model',
        },
        {
          value: 'provider-b',
          label: (
            <span>
              <svg aria-hidden="true" />
              Beta model
            </span>
          ),
          textValue: 'Beta model',
        },
      ]}
    />,
  );
  const combo = view.getByRole('combobox', { name: 'Model Alpha model' });
  fireEvent.click(combo);
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'b' });
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'Enter' });
  assert.equal(selected, 'provider-b');
});

test('reopening resets typeahead instead of combining separate selection attempts', () => {
  const view = render(<Controlled />);
  const combo = view.getByRole('combobox');
  fireEvent.click(combo);
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'b' });
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'Escape' });
  fireEvent.click(combo);
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'c' });
  fireEvent.keyDown(view.getByRole('listbox'), { key: 'Enter' });
  assert.match(combo.textContent!, /Charlie/);
});

test('model rows use local decorative icons before names on white menus and respect busy state', async () => {
  const { ModelSelector } = await import('../src/components/models/ModelSelector');
  const view = render(<ModelSelector capability="chat" value="gpt-6.1-sol" onChange={() => {}} />);
  const combo = view.getByRole('combobox', { name: '对话模型 GPT-6.1 Sol' });
  fireEvent.click(combo);
  const list = view.getByRole('listbox');
  assert.equal(list.parentElement!.style.getPropertyValue('--gs-surface'), '#ffffff');
  assert.equal(list.parentElement!.style.getPropertyValue('--gs-text'), '#292633');
  assert.equal(view.getAllByRole('option').length, 6);
  for (const option of view.getAllByRole('option')) {
    const row = option.querySelector('.model-selector-label')!;
    assert.equal(row.firstElementChild?.tagName.toLowerCase(), 'svg');
    assert.equal(row.firstElementChild?.getAttribute('aria-hidden'), 'true');
    assert.equal(row.lastElementChild?.tagName.toLowerCase(), 'span');
    assert.ok(row.lastElementChild?.textContent);
  }
  view.rerender(
    <ModelSelector capability="chat" value="gpt-6.1-sol" onChange={() => {}} disabled />,
  );
  assert.equal(view.queryByRole('listbox'), null);
  assert.equal(combo.hasAttribute('disabled'), true);
  view.rerender(
    <ModelSelector capability="image" value="doubao-seedream-5.0-pro" onChange={() => {}} />,
  );
  fireEvent.click(view.getByRole('combobox', { name: '图片模型 Seedream 5.0 Pro' }));
  assert.equal(view.getAllByRole('option').length, 4);
  assert.equal(view.queryByRole('option', { name: 'GPT-6.1 Sol' }), null);
  assert.equal(
    view.getByRole('option', { name: 'Seedream 5.0 Pro' }).getAttribute('aria-selected'),
    'true',
  );
});

test('Tab closes the portaled list, restores its trigger and leaves native traversal uncancelled', () => {
  const view = render(
    <>
      <Controlled />
      <button>Next control</button>
    </>,
  );
  const combo = view.getByRole('combobox');
  fireEvent.click(combo);
  const tab = new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true });
  fireEvent(view.getByRole('listbox'), tab);
  assert.equal(view.queryByRole('listbox'), null);
  assert.equal(document.activeElement === combo, true);
  assert.equal(tab.defaultPrevented, false);
  // jsdom has no native Tab traversal. user-event 14 captures the old listbox
  // target before this handler restores focus, so browser progression is QA-only.
});

test('keyboard navigation scrolls only the menu, never the surrounding dialog or document', () => {
  const view = render(
    <dialog open>
      <Controlled />
    </dialog>,
  );
  fireEvent.click(view.getByRole('combobox'));
  const list = view.getByRole('listbox');
  const menu = list.parentElement!;
  const dialog = view.getByRole('dialog');
  Object.defineProperty(menu, 'clientHeight', { value: 70 });
  Object.defineProperty(list, 'offsetTop', { value: 4 });
  for (const [index, option] of view.getAllByRole('option').entries()) {
    Object.defineProperty(option, 'offsetTop', { value: index * 31 });
    Object.defineProperty(option, 'offsetHeight', { value: 30 });
    option.scrollIntoView = () => {
      // Native scrollIntoView can also move the enclosing overflow:auto dialog.
      dialog.scrollTop = 100;
      fireEvent.scroll(dialog);
    };
  }
  fireEvent.keyDown(list, { key: 'End' });
  assert.equal(view.queryByRole('listbox'), list);
  assert.equal(menu.scrollTop, 57);
  assert.equal(dialog.scrollTop, 0);
  fireEvent.scroll(menu);
  assert.equal(view.queryByRole('listbox'), list);
  fireEvent.keyDown(list, { key: 'Home' });
  assert.equal(menu.scrollTop, 4);
  assert.equal(document.activeElement, list);
});

test('opening a long menu reveals the selected row after viewport sizing commits', () => {
  const properties = ['clientHeight', 'offsetTop', 'offsetHeight'] as const;
  const originals = properties.map((name) =>
    Object.getOwnPropertyDescriptor(HTMLElement.prototype, name),
  );
  Object.defineProperties(HTMLElement.prototype, {
    clientHeight: {
      configurable: true,
      get() {
        return this.classList.contains('glide-select__menu')
          ? parseFloat(this.style.maxHeight) || 1000
          : 0;
      },
    },
    offsetTop: {
      configurable: true,
      get() {
        return this.classList.contains('glide-select__list')
          ? 4
          : Number(this.dataset.index || 0) * 31;
      },
    },
    offsetHeight: { configurable: true, get: () => 30 },
  });
  try {
    const options = Array.from({ length: 20 }, (_, index) => `Choice ${index + 1}`);
    const view = render(<GlideSelect options={options} value="Choice 20" />);
    fireEvent.click(view.getByRole('combobox'));
    const menu = view.getByRole('listbox').parentElement!;
    assert.equal(menu.style.maxHeight, '280px');
    assert.equal(menu.scrollTop, 343);
  } finally {
    properties.forEach((name, index) => {
      const original = originals[index];
      if (original) Object.defineProperty(HTMLElement.prototype, name, original);
      else delete (HTMLElement.prototype as unknown as Record<string, unknown>)[name];
    });
  }
});
