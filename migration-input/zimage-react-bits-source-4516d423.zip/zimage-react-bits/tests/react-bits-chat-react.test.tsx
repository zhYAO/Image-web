import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';

const dom = new JSDOM('<!doctype html><html><body></body></html>', { pretendToBeVisual: true });
for (const key of [
  'window',
  'self',
  'document',
  'navigator',
  'HTMLElement',
  'Element',
  'Node',
  'Event',
  'MutationObserver',
]) {
  Object.defineProperty(globalThis, key, { configurable: true, value: (dom.window as any)[key] });
}
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;
let reduced = false;
let disconnects = 0;
const mediaListeners = new Set<() => void>();
const observers = new Set<IntersectionObserverCallback>();
class Observer {
  callback: IntersectionObserverCallback;
  constructor(callback: IntersectionObserverCallback) {
    this.callback = callback;
    observers.add(callback);
  }
  observe() {}
  disconnect() {
    observers.delete(this.callback);
    disconnects++;
  }
}
Object.assign(globalThis, {
  IntersectionObserver: Observer,
  requestAnimationFrame: dom.window.requestAnimationFrame.bind(dom.window),
  cancelAnimationFrame: dom.window.cancelAnimationFrame.bind(dom.window),
});
Object.assign(dom.window, {
  matchMedia: () => ({
    get matches() {
      return reduced;
    },
    addEventListener: (_: string, callback: () => void) => mediaListeners.add(callback),
    removeEventListener: (_: string, callback: () => void) => mediaListeners.delete(callback),
  }),
});
const { render, cleanup, act, fireEvent, waitFor } = await import('@testing-library/react');
const { ThoughtLine, LatticeLoader, ShinyText, TextType } =
  await import('../src/components/react-bits/chat');
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
afterEach(() => {
  cleanup();
  reduced = false;
  Object.defineProperty(document, 'hidden', { configurable: true, value: false });
});

function setHidden(hidden: boolean) {
  act(() => {
    Object.defineProperty(document, 'hidden', { configurable: true, value: hidden });
    document.dispatchEvent(new Event('visibilitychange'));
  });
}

test('ThoughtLine exposes expandable named steps and retains user choice on settle', () => {
  const steps = [
    { id: 'one', label: '整理需求', description: '仅为本地演示步骤', status: 'active' as const },
  ];
  const view = render(<ThoughtLine steps={steps} />);
  const button = view.getByRole('button');
  assert.equal(button.getAttribute('aria-expanded'), 'true');
  assert.ok(view.getByText('仅为本地演示步骤'));
  fireEvent.click(button);
  assert.equal(button.getAttribute('aria-expanded'), 'false');
  assert.equal(
    document.getElementById(button.getAttribute('aria-controls')!)?.getAttribute('aria-hidden'),
    'true',
  );
  view.rerender(<ThoughtLine steps={steps} working={false} />);
  assert.equal(button.getAttribute('aria-expanded'), 'false');
  assert.equal(view.container.firstElementChild?.getAttribute('data-running'), 'false');
});

test('official lattice orbit cells and done mark remain present; resources release', () => {
  const before = disconnects;
  const view = render(<LatticeLoader />);
  const cells = [
    ...view.container.querySelectorAll<HTMLElement>('.lattice-loader__run .lattice-loader__cell'),
  ];
  assert.equal(cells.length, 9);
  assert.deepEqual(
    cells.map((cell) => cell.style.animationDelay),
    ['0ms', '108ms', '216ms', '756ms', '', '324ms', '648ms', '540ms', '432ms'],
  );
  assert.equal(view.container.firstElementChild?.getAttribute('aria-hidden'), 'true');
  view.rerender(<LatticeLoader state="done" />);
  assert.equal(view.container.firstElementChild?.getAttribute('data-running'), 'false');
  assert.equal(view.container.querySelectorAll('.lattice-loader__mark [data-on]').length, 4);
  view.unmount();
  assert.ok(disconnects > before);
  assert.equal(mediaListeners.size, 0);
});

test('TextType emits intact graphemes once and does not restart for callback identity changes', async () => {
  const parts: string[] = [];
  let completed = 0;
  const view = render(
    <TextType
      text="你👨‍👩‍👧‍👦好"
      typingSpeed={2}
      loop={false}
      onTextChange={(part) => parts.push(part)}
      onComplete={() => completed++}
    />,
  );
  await waitFor(() => assert.equal(completed, 1));
  assert.deepEqual(parts, ['你', '你👨‍👩‍👧‍👦', '你👨‍👩‍👧‍👦好']);
  view.rerender(
    <TextType
      text="你👨‍👩‍👧‍👦好"
      typingSpeed={2}
      onTextChange={(part) => parts.push(part)}
      onComplete={() => completed++}
    />,
  );
  await act(() => delay(20));
  assert.equal(completed, 1);
  assert.equal(view.container.querySelectorAll('.text-type__char').length, 3);
  assert.equal(view.container.querySelector('.zi-chat-text-type__cursor'), null);
});

test('TextType freezes while hidden and stopped, and unmount prevents late callbacks', async () => {
  const parts: string[] = [];
  let complete = 0;
  const props = {
    text: 'abcdefghi',
    typingSpeed: 10,
    onTextChange: (part: string) => parts.push(part),
    onComplete: () => complete++,
  };
  const view = render(<TextType {...props} />);
  await waitFor(() => assert.ok(parts.length >= 1), { interval: 2 });
  setHidden(true);
  const hiddenCount = parts.length;
  await act(() => delay(35));
  assert.equal(parts.length, hiddenCount);
  setHidden(false);
  await waitFor(() => assert.ok(parts.length > hiddenCount), { interval: 2 });
  view.rerender(<TextType {...props} active={false} />);
  const stoppedCount = parts.length;
  await act(() => delay(35));
  assert.equal(parts.length, stoppedCount);
  assert.equal(view.container.firstElementChild?.getAttribute('data-running'), 'false');
  view.unmount();
  await act(() => delay(25));
  assert.equal(parts.length, stoppedCount);
  assert.equal(complete, 0);
  assert.equal(mediaListeners.size, 0);
});

test('live reduced motion completes text and stops decorative sweeps', async () => {
  let result = '';
  let completed = 0;
  const view = render(
    <>
      <TextType
        text="完整的本地演示回答"
        typingSpeed={1000}
        onTextChange={(value) => (result = value)}
        onComplete={() => completed++}
      />
      <ShinyText text="正在生成演示回答" />
    </>,
  );
  act(() => {
    reduced = true;
    mediaListeners.forEach((callback) => callback());
  });
  await waitFor(() => assert.equal(completed, 1));
  assert.equal(result, '完整的本地演示回答');
  assert.equal(view.getByText('正在生成演示回答').getAttribute('data-running'), 'false');
  assert.equal(view.getByText('正在生成演示回答').style.backgroundImage, 'none');
});

test('offscreen gates stop and resume decorations; disabling ShinyText remains readable', () => {
  const view = render(<ShinyText text="正在生成" />);
  act(() =>
    observers.forEach((callback) =>
      callback(
        [{ isIntersecting: false }] as IntersectionObserverEntry[],
        {} as IntersectionObserver,
      ),
    ),
  );
  assert.equal(view.container.firstElementChild?.getAttribute('data-running'), 'false');
  act(() =>
    observers.forEach((callback) =>
      callback(
        [{ isIntersecting: true }] as IntersectionObserverEntry[],
        {} as IntersectionObserver,
      ),
    ),
  );
  assert.equal(view.container.firstElementChild?.getAttribute('data-running'), 'true');
  view.rerender(<ShinyText text="正在生成" disabled />);
  assert.equal(view.getByText('正在生成').style.backgroundImage, 'none');
  assert.equal(view.getByText('正在生成').getAttribute('data-running'), 'false');
});
