// DOM unit tests execute real React logic; styles are validated separately by
// Next's production build. This hook never runs in the application bundle.
import { registerHooks } from 'node:module';
registerHooks({
  load(url, context, nextLoad) {
    if (/\.css(?:\?|$)/.test(url))
      return { format: 'module', source: 'export default {};', shortCircuit: true };
    return nextLoad(url, context);
  },
});
