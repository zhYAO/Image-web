import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';

const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'https://zimage.test',
  pretendToBeVisual: true,
});
for (const key of [
  'window',
  'document',
  'navigator',
  'HTMLElement',
  'Element',
  'Node',
  'Event',
  'MouseEvent',
  'KeyboardEvent',
  'MutationObserver',
]) {
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
}
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
let hidden = false;
Object.defineProperty(document, 'hidden', { configurable: true, get: () => hidden });
type MediaListener = (event: { matches: boolean }) => void;
const media = new Map<
  string,
  {
    matches: boolean;
    media: string;
    listeners: Set<MediaListener>;
    addEventListener: (event: string, listener: MediaListener) => void;
    removeEventListener: (event: string, listener: MediaListener) => void;
  }
>();
Object.defineProperty(window, 'matchMedia', {
  configurable: true,
  value: (query: string) => {
    if (!media.has(query)) {
      const listeners = new Set<(event: { matches: boolean }) => void>();
      media.set(query, {
        matches: query.includes('pointer: fine'),
        media: query,
        listeners,
        addEventListener(_event: string, fn: (event: { matches: boolean }) => void) {
          listeners.add(fn);
        },
        removeEventListener(_event: string, fn: (event: { matches: boolean }) => void) {
          listeners.delete(fn);
        },
      });
    }
    return media.get(query);
  },
});
class Observer {
  static all: Observer[] = [];
  disconnected = false;
  node?: Element;
  constructor(
    public callback: (
      entries: {
        target: Element | undefined;
        isIntersecting: boolean;
        intersectionRatio: number;
      }[],
    ) => void,
    public options: IntersectionObserverInit = {},
  ) {
    Observer.all.push(this);
  }
  observe(node: Element) {
    this.node = node;
  }
  unobserve(node: Element) {
    if (this.node === node) this.node = undefined;
  }
  disconnect() {
    this.disconnected = true;
  }
  emit(visible: boolean) {
    this.callback([
      { target: this.node, isIntersecting: visible, intersectionRatio: visible ? 1 : 0 },
    ]);
  }
}
Object.defineProperty(globalThis, 'IntersectionObserver', { configurable: true, value: Observer });
Object.defineProperty(window, 'IntersectionObserver', { configurable: true, value: Observer });
const raf = new Map<number, FrameRequestCallback>();
let frameId = 0;
Object.defineProperty(globalThis, 'requestAnimationFrame', {
  configurable: true,
  value: (fn: FrameRequestCallback) => {
    raf.set(++frameId, fn);
    return frameId;
  },
});
Object.defineProperty(globalThis, 'cancelAnimationFrame', {
  configurable: true,
  value: (id: number) => raf.delete(id),
});
const { render, fireEvent, cleanup, act } = await import('@testing-library/react');
const { HeroGallery } = await import('../src/components/landing/HeroGallery');
const { LandingNav } = await import('../src/components/landing/LandingNav');
const { SectionJump } = await import('../src/components/landing/SectionJump');
const { LandingFaq } = await import('../src/components/landing/LandingFaq');
const { WorkflowReel } = await import('../src/components/landing/WorkflowReel');

function flushFrames() {
  act(() => {
    const pending = [...raf.values()];
    raf.clear();
    pending.forEach((fn) => fn(0));
  });
}
afterEach(() => {
  cleanup();
  media.clear();
  Observer.all.length = 0;
  raf.clear();
  hidden = false;
});

test('gallery loads only its active image and pauses cycling for visibility, manual control and reduced motion', () => {
  const intervals = new Map<number, { run: () => void; delay: number }>();
  let timerId = 0;
  const setInterval = window.setInterval,
    clearInterval = window.clearInterval;
  window.setInterval = ((run: () => void, delay: number) => {
    intervals.set(++timerId, { run, delay });
    return timerId;
  }) as typeof window.setInterval;
  window.clearInterval = (id: number | undefined) => {
    if (id !== undefined) intervals.delete(id);
  };
  try {
    const view = render(<HeroGallery />);
    assert.equal(view.container.querySelectorAll('.zl-gallery-frame img').length, 1);
    assert.equal(intervals.size, 0);
    act(() => Observer.all.find((observer) => observer.options.threshold === 0.3)!.emit(true));
    assert.equal(intervals.size, 1);
    assert.equal([...intervals.values()][0].delay, 10_000);
    act(() => [...intervals.values()][0].run());
    assert.equal(
      view.getByRole('button', { name: '生活场景' }).getAttribute('aria-pressed'),
      'true',
    );
    fireEvent.click(view.getByRole('button', { name: '服装视觉' }));
    assert.equal(intervals.size, 0);
    fireEvent.pointerLeave(view.container.querySelector('.zl-showcase')!);
    assert.equal(intervals.size, 1);
    fireEvent.click(view.getByRole('button', { name: '暂停自动切换' }));
    assert.equal(intervals.size, 0);
    fireEvent.click(view.getByRole('button', { name: '恢复自动切换' }));
    assert.equal(intervals.size, 1);
    act(() => {
      hidden = true;
      document.dispatchEvent(new Event('visibilitychange'));
    });
    assert.equal(intervals.size, 0);
    act(() => {
      hidden = false;
      document.dispatchEvent(new Event('visibilitychange'));
      const preference = media.get('(prefers-reduced-motion: reduce)')!;
      preference.matches = true;
      preference.listeners.forEach((fn) => fn({ matches: true }));
    });
    assert.equal(intervals.size, 0);
    assert.equal(view.queryByRole('button', { name: '暂停自动切换' }), null);
    const observers = [...Observer.all];
    view.unmount();
    assert.equal(intervals.size, 0);
    assert.ok(observers.every((observer) => observer.disconnected));
  } finally {
    window.setInterval = setInterval;
    window.clearInterval = clearInterval;
  }
});

test('navigation handles open, Escape, outside pointer, resize and scroll hysteresis', () => {
  Object.defineProperty(window, 'innerWidth', { configurable: true, value: 620, writable: true });
  Object.defineProperty(window, 'scrollY', { configurable: true, value: 0, writable: true });
  const view = render(<LandingNav />);
  const menu = view.getByRole('button', { name: '打开导航' });
  const nav = view.getByRole('navigation', { name: '主导航' });
  const firstLink = nav.querySelector('button');
  const cta = view.getByRole('link', { name: '开始创作' });
  assert.equal(cta.getAttribute('href'), '/workspace');
  assert.ok(cta.classList.contains('zl-nav-cta'));
  assert.ok(cta.classList.contains('zl-pill-cta'));
  assert.equal(cta.classList.contains('zl-button'), false);
  assert.equal(cta.querySelector('.zl-pill-cta-label-alt')?.getAttribute('aria-hidden'), 'true');
  fireEvent.click(menu);
  cta.addEventListener('click', (event) => event.preventDefault(), { once: true });
  fireEvent.click(cta);
  assert.equal(menu.getAttribute('aria-expanded'), 'false');

  assert.equal(nav.classList.contains('liquid-glass'), false);
  fireEvent.click(menu);
  assert.equal(menu.getAttribute('aria-expanded'), 'true');
  assert.equal(view.getByRole('navigation', { name: '主导航' }), nav);
  assert.equal(nav.querySelector('button'), firstLink);
  assert.equal(nav.classList.contains('liquid-glass'), true);
  assert.equal(
    nav.classList.contains('surface-white'),
    true,
    'open menu must hide underlying hero text',
  );
  fireEvent.keyDown(document, { key: 'Escape' });
  assert.equal(menu.getAttribute('aria-expanded'), 'false');
  assert.equal(document.activeElement, menu);
  assert.equal(nav.classList.contains('liquid-glass'), false);
  assert.equal(nav.querySelector('button'), firstLink);
  fireEvent.click(menu);
  fireEvent.pointerDown(document.body);
  assert.equal(menu.getAttribute('aria-expanded'), 'false');
  fireEvent.click(menu);
  window.innerWidth = 1200;
  fireEvent(window, new Event('resize'));
  flushFrames();
  assert.equal(menu.getAttribute('aria-expanded'), 'false');
  const header = view.container.querySelector('header')!;
  for (const [y, condensed] of [
    [65, true],
    [24, true],
    [23, false],
  ] as const) {
    window.scrollY = y;
    fireEvent(window, new Event('scroll'));
    flushFrames();
    assert.equal(header.classList.contains('is-condensed'), condensed);
  }
  view.unmount();
  assert.equal(raf.size, 0);
});

test('FAQ keeps click-opened answers open after pointer leaves', () => {
  const view = render(<LandingFaq />);
  const summary = view.getByText('我可以从哪里开始？');
  const details = summary.closest('details')!;
  fireEvent.click(summary);
  assert.equal(details.open, true);
  fireEvent.pointerLeave(details.parentElement!);
  assert.equal(details.open, true);
  fireEvent.click(summary);
  assert.equal(details.open, false);
  fireEvent.pointerEnter(details.parentElement!);
  assert.equal(details.open, true);
  fireEvent.pointerLeave(details.parentElement!);
  assert.equal(details.open, false);
});

test('small-screen reel has manual, accessible selection and releases observers on unmount', () => {
  Object.defineProperty(window, 'innerWidth', { configurable: true, value: 620, writable: true });
  Object.defineProperty(window, 'innerHeight', { configurable: true, value: 780, writable: true });
  const view = render(<WorkflowReel />);
  fireEvent.click(view.getByRole('button', { name: /留下来，让灵感继续/ }));
  assert.equal(
    view.getByRole('button', { name: /留下来，让灵感继续/ }).getAttribute('aria-pressed'),
    'true',
  );
  assert.equal(
    view.container.querySelector('#workflow-frame-2')?.getAttribute('aria-hidden'),
    'false',
  );
  assert.equal(
    view.container.querySelector('#workflow-frame-0')?.getAttribute('aria-hidden'),
    'true',
  );
  const observers = [...Observer.all];
  view.unmount();
  assert.ok(observers.every((observer) => observer.disconnected));
  assert.equal(raf.size, 0);
});

test('lazy reveals retain child identity and values while their effect controller loads', async () => {
  const { Reveal } = await import('../src/components/landing/Reveal');
  const view = render(
    <Reveal>
      <input aria-label="Stable reveal child" defaultValue="Original" />
    </Reveal>,
  );
  const input = view.getByLabelText('Stable reveal child') as HTMLInputElement;
  fireEvent.change(input, { target: { value: 'Keep this value' } });
  const near = Observer.all.find((observer) => observer.options.rootMargin === '240px')!;
  await act(async () => {
    near.emit(true);
    await new Promise((resolve) => setTimeout(resolve, 50));
  });
  assert.equal(view.getByLabelText('Stable reveal child'), input);
  assert.equal(input.value, 'Keep this value');
  assert.equal(near.disconnected, true);
});

test('glass section jump remains a native button and preserves its content across updates', () => {
  const target = document.createElement('section');
  target.id = 'glass-jump-test';
  let scrolled = false;
  target.scrollIntoView = () => {
    scrolled = true;
  };
  document.body.append(target);
  try {
    const view = render(
      <SectionJump className="liquid-glass" target={target.id}>
        <span>Explore scenes</span>
      </SectionJump>,
    );
    const button = view.getByRole('button', { name: 'Explore scenes' });
    const content = button.querySelector('span');
    assert.equal(button.tagName, 'BUTTON');
    assert.equal(button.getAttribute('data-liquid-glass'), null);
    assert.equal(button.querySelectorAll('.glass-surface__rim').length, 0);
    fireEvent.click(button);
    assert.equal(scrolled, true);
    view.rerender(
      <SectionJump target={target.id} className="liquid-glass updated">
        <span>Explore scenes</span>
      </SectionJump>,
    );
    assert.equal(view.getByRole('button', { name: 'Explore scenes' }), button);
    assert.equal(button.querySelector('span'), content);
  } finally {
    target.remove();
  }
});
