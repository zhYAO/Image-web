import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  ASSET_ITEMS,
  ASSET_COLLECTIONS,
  initialAssetState,
  orderedAssets,
  visibleAssets,
  updateMembership,
  membershipEdit,
} from '../src/components/assets/library.ts';
import { validatePhone, validatePhoneLogin } from '../src/components/identity/validation.ts';
import { demoPhoneAuth, PhoneAuthError } from '../src/components/identity/phone-auth.ts';
import { ledgerPage, LEDGER_PAGE_SIZE } from '../src/components/identity/ledger.ts';
const root = resolve(import.meta.dirname, '..');
const source = (path) => readFileSync(resolve(root, path), 'utf8');

test('all twelve curated assets and collection members are valid local images', () => {
  assert.equal(ASSET_ITEMS.length, 12);
  assert.equal(new Set(ASSET_ITEMS.map((asset) => asset.id)).size, 12);
  for (const asset of ASSET_ITEMS) {
    assert.ok(existsSync(resolve(root, `public${asset.file}`)), asset.file);
    assert.ok(asset.width > 0 && asset.height > 0);
  }
  for (const collection of ASSET_COLLECTIONS)
    assert.ok(collection.ids.every((id) => ASSET_ITEMS.some((asset) => asset.id === id)));
});
test('search intersects type, favorites and collection scopes without changing source items', () => {
  const state = initialAssetState();
  assert.equal(visibleAssets(state).length, 12);
  state.query = '耳机';
  assert.equal(visibleAssets(state).length, 6);
  state.type = 'detail';
  assert.equal(visibleAssets(state).length, 2);
  state.scope = 'favorites';
  assert.equal(visibleAssets(state).length, 0);
  state.favorites.add('blue-detail');
  assert.equal(visibleAssets(state)[0].id, 'blue-detail');
  state.scope = 'collection:warm';
  assert.deepEqual(
    visibleAssets(state).map((asset) => asset.id),
    ['headphone-detail'],
  );
  state.query = '<script>';
  assert.equal(visibleAssets(state).length, 0);
});
test('sorts preserve shared asset objects and do not mutate the curated order', () => {
  const initial = ASSET_ITEMS.map((asset) => asset.id);
  const sorted = orderedAssets('size');
  assert.ok(
    sorted.every(
      (asset, index) =>
        index === 0 ||
        sorted[index - 1].width * sorted[index - 1].height >= asset.width * asset.height,
    ),
  );
  assert.ok(sorted.every((asset) => ASSET_ITEMS.includes(asset)));
  assert.deepEqual(
    ASSET_ITEMS.map((asset) => asset.id),
    initial,
  );
  assert.deepEqual(
    orderedAssets('curated').map((asset) => asset.id),
    initial,
  );
});
test('membership is immutable, rejects unknown IDs and undo retains unrelated later edits', () => {
  const state = initialAssetState();
  state.favorites.add('amber-sound');
  const edit = membershipEdit(state, ['amber-sound', 'blue-detail'], true);
  const changed = edit.apply(state);
  assert.equal(state.favorites.size, 1);
  assert.equal(changed.favorites.size, 2);
  changed.favorites = updateMembership(changed.favorites, ['mint-cup', 'unknown'], true);
  const reverted = edit.undo(changed);
  assert.deepEqual([...reverted.favorites].sort(), ['amber-sound', 'mint-cup']);
  assert.deepEqual([...edit.undo(reverted).favorites].sort(), ['amber-sound', 'mint-cup']);
  const collectionEdit = membershipEdit(state, ['amber-sound'], false, 'warm');
  assert.equal(collectionEdit.apply(state).collections.warm.size, 3);
  assert.equal(collectionEdit.undo(collectionEdit.apply(state)).collections.warm.size, 4);
});
test('phone login accepts mainland mobile numbers and requires exactly six numeric code digits', () => {
  for (const value of [
    '',
    ' ',
    '12800138000',
    '1380013800',
    '138001380000',
    '+8613800138000',
    '138 00138000',
    '１３８００１３８０００',
  ]) {
    assert.equal(validatePhone(value)?.field, 'phone', value);
  }
  for (const value of ['13800138000', '19900138000', ' 13800138000 ']) {
    assert.equal(validatePhone(value), null, value);
  }
  for (const code of ['', '12345', '1234567', '123ab6', '１２３４５６', '123456 ']) {
    assert.equal(validatePhoneLogin('13800138000', code)?.field, 'code', code);
  }
  assert.equal(validatePhoneLogin('13800138000', '123456'), null);
});

test('the local phone adapter is abortable, rejects invalid inputs and never sends a network request', async (t) => {
  const network = t.mock.method(globalThis, 'fetch', () => {
    throw new Error('Network must not be used');
  });
  const controller = new AbortController();
  const options = { signal: controller.signal };
  const phone = { countryCode: '+86', number: '13800138000' };
  const challenge = await demoPhoneAuth.requestCode(phone, options);
  assert.equal(challenge.retryAfterSeconds, 60);
  const input = { ...phone, challengeId: challenge.id, code: '123456' };
  assert.deepEqual(await demoPhoneAuth.verifyCode(input, options), { kind: 'demo-verified' });
  await assert.rejects(
    demoPhoneAuth.requestCode({ ...phone, number: '123' }, options),
    (error) => error instanceof PhoneAuthError && error.code === 'invalid-phone',
  );
  await assert.rejects(
    demoPhoneAuth.verifyCode({ ...input, challengeId: 'missing' }, options),
    (error) => error.code === 'expired-challenge',
  );
  await assert.rejects(
    demoPhoneAuth.verifyCode({ ...input, code: '654321' }, options),
    (error) => error.code === 'invalid-code',
  );
  controller.abort();
  await assert.rejects(demoPhoneAuth.requestCode(phone, options), { name: 'AbortError' });
  await assert.rejects(demoPhoneAuth.verifyCode(input, options), { name: 'AbortError' });
  assert.equal(network.mock.callCount(), 0);
});
test('ledger retains record rendering and three-record pagination without inventing account data', () => {
  const entries = Array.from({ length: 5 }, (_, i) => ({
    id: `${i}`,
    time: '2026-10-15',
    purpose: '图片创作',
    type: '消费',
    amount: '− 0.80',
  }));
  assert.equal(LEDGER_PAGE_SIZE, 3);
  assert.equal(ledgerPage(entries).entries.length, 3);
  assert.equal(ledgerPage(entries).hasMore, true);
  assert.equal(ledgerPage(entries, 6).entries.length, 5);
  assert.equal(ledgerPage(entries, 6).hasMore, false);
  assert.equal(ledgerPage([]).hasMore, false);
  assert.match(source('src/components/identity/AccountLedger.tsx'), /records = null/);
});
test('assets cards stay mounted and the modal is loaded only when open', () => {
  const component = source('src/components/assets/AssetLibrary.tsx');
  assert.match(component, /allItems\s*\.\s*map\s*\(\s*\(\s*asset\b/);
  assert.match(component, /key\s*=\s*\{\s*asset\.id\s*\}/);
  assert.match(component, /hidden\s*=\s*\{\s*!visibleIds\.has\(asset\.id\)\s*\}/);
  assert.match(
    component,
    /dynamic\s*\(\s*\(\s*\)\s*=>\s*import\s*\(\s*['"]\.\/AssetDialogContent['"]\s*\)/,
  );
  assert.match(component, /dialogState\?\.kind === 'collection' &&\s*\(?\s*<AssetDialogContent\b/);
  assert.doesNotMatch(component, /dangerouslySetInnerHTML|innerHTML|iframe|fetch\(|localStorage/);
});
test('identity aliases are static routes and form controls have bounded viewport and fill-only focus', () => {
  for (const path of [
    'login',
    'auth',
    'register',
    'auth/register',
    'forgot-password',
    'auth/recovery',
    'auth/verify',
    'auth/reset',
    'account',
    'terms',
    'privacy',
  ])
    assert.ok(
      existsSync(
        resolve(
          root,
          `src/app/${['account', 'terms', 'privacy'].includes(path) ? '' : '(identity-auth)/'}${path}/page.tsx`,
        ),
      ),
    );
  const auth = source('src/components/identity/AuthPage.tsx');
  const css = source('src/components/identity/identity.css');
  assert.match(auth, /window\.visualViewport/);
  assert.match(css, /\.zi-auth-scroll\s*\{[^}]*overflow-y\s*:\s*auto\b/);
  assert.match(css, /\.zi-auth-screen\s*\{[^}]*position\s*:\s*fixed\b/);
  assert.match(
    css,
    /input:is\(\s*:focus\s*,\s*:focus-visible\s*\)\s*\{[^}]*box-shadow\s*:\s*none\s*!important/,
  );
  assert.doesNotMatch(auth, /WorkspaceShell|fetch\(|localStorage|dangerouslySetInnerHTML|iframe/);
  assert.match(source('src/components/identity/PhoneLoginForm.tsx'), /仅供前端演示/);
  assert.match(source('src/components/identity/PhoneLoginForm.tsx'), /尚未登录/);
});

test('phone credentials never use GET submission and legacy/account routes collect no passwords', () => {
  const phone = source('src/components/identity/PhoneLoginForm.tsx');
  assert.match(phone, /<form[^>]*method="post"/);
  for (const name of ['AuthPage', 'PhoneLoginForm', 'AccountPage']) {
    assert.doesNotMatch(
      source(`src/components/identity/${name}.tsx`),
      /type="password"|localStorage|sessionStorage|fetch\(/,
    );
  }
});

test('assets reuse the workspace shell and omit standalone navigation and image metadata', () => {
  const route = source('src/app/assets/page.tsx');
  assert.match(route, /<WorkspaceShell title="资产库" active="assets">/);
  const library = source('src/components/assets/AssetLibrary.tsx');
  assert.doesNotMatch(library, /za-header|za-brand|za-nav|<main/);
  const dialog = source('src/components/assets/AssetDialogContent.tsx');
  assert.doesNotMatch(dialog, /za-detail-info|za-detail-tags|za-detail-pager|<dl>|收藏图片/);
  assert.match(library, /<ImagePreviewDialog[\s\S]*?imageOnly/);
  assert.doesNotMatch(dialog, /<img|AssetImage/);
  const css = source('src/components/assets/assets.css');
  const host = css.match(/\.za-assets-host\s*\{([^}]+)\}/)?.[1];
  assert.ok(host);
  assert.doesNotMatch(host, /(?:^|;)\s*(?:height|max-height|overflow(?:-[xy])?)\s*:/);
  assert.doesNotMatch(host, /overscroll-behavior:\s*contain/);
  assert.match(
    source('src/components/image-preview.css'),
    /\.image-preview-full\s*\{[^}]*object-fit: contain/,
  );
});

test('auth routes share a persistent layout instead of remounting the screen on every tab', () => {
  const group = 'src/app/(identity-auth)';
  assert.ok(existsSync(resolve(root, `${group}/layout.tsx`)), 'auth routes need a shared layout');
  assert.match(source(`${group}/layout.tsx`), /<AuthRoute/);
  for (const path of [
    'login',
    'register',
    'forgot-password',
    'auth',
    'auth/register',
    'auth/recovery',
    'auth/verify',
    'auth/reset',
  ]) {
    assert.match(source(`${group}/${path}/page.tsx`), /return null/);
    assert.ok(!existsSync(resolve(root, `src/app/${path}/page.tsx`)), 'no duplicate public URL');
  }
});

test('auth card geometry stays bounded and mode transitions never hide the whole screen', () => {
  const css = source('src/components/identity/identity.css');
  assert.match(css, /\.zi-auth-reveal\s*\{[^}]*height:\s*min\(680px,\s*100%\)/);
  assert.match(css, /\.zi-auth-card\s*\{[^}]*height:\s*100%/);
  assert.match(css, /\.zi-auth-form\s*\{[^}]*animation:\s*zi-auth-form-enter/);
  assert.match(css, /@keyframes zi-auth-form-enter\s*\{\s*from\s*\{\s*opacity:\s*0\.85/);
});
