import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import React from 'react';

const dom = new JSDOM('<!doctype html><html><body></body></html>', { pretendToBeVisual: true });
for (const key of [
  'window',
  'self',
  'document',
  'navigator',
  'HTMLElement',
  'HTMLCanvasElement',
  'Element',
  'Node',
  'Event',
  'MutationObserver',
]) {
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
}
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
let intersection: IntersectionObserverCallback;
let disconnects = 0;
const changes = new Set<() => void>();
let reduced = false;
let forced = false;
class Observer {
  constructor(callback: IntersectionObserverCallback) {
    intersection = callback;
  }
  observe() {}
  disconnect() {
    disconnects += 1;
  }
}
Object.assign(globalThis, { IntersectionObserver: Observer });
Object.assign(dom.window, {
  IntersectionObserver: Observer,
  matchMedia: (query: string) => ({
    get matches() {
      return query.includes('reduced-motion') ? reduced : forced;
    },
    addEventListener: (_: string, cb: () => void) => changes.add(cb),
    removeEventListener: (_: string, cb: () => void) => changes.delete(cb),
  }),
});
const { render, cleanup, act } = await import('@testing-library/react');
const { ComposerOrbs } = await import('../src/components/workspace/ComposerOrbs');
afterEach(() => {
  cleanup();
  reduced = false;
  forced = false;
  Object.defineProperty(document, 'hidden', { configurable: true, value: false });
});
function visibility(visible: boolean) {
  act(() =>
    intersection(
      [{ isIntersecting: visible }] as IntersectionObserverEntry[],
      {} as IntersectionObserver,
    ),
  );
}

test('three stable CSS orbs pause immediately on focus and resume on blur', () => {
  const view = render(<ComposerOrbs focused={false} />);
  const host = view.container.firstElementChild!;
  assert.equal(host.getAttribute('aria-hidden'), 'true');
  assert.equal(host.children.length, 3);
  for (const x of host.children) {
    assert.equal(x.children.length, 1, 'each horizontal track owns one vertical track');
    assert.equal(
      x.firstElementChild?.children.length,
      1,
      'each vertical track owns one light spot',
    );
  }
  assert.equal(host.querySelector('canvas'), null);
  assert.equal(host.getAttribute('data-running'), 'false');
  visibility(true);
  assert.equal(host.getAttribute('data-running'), 'true');
  const orb = host.firstElementChild;
  view.rerender(<ComposerOrbs focused />);
  assert.equal(host.getAttribute('data-focused'), 'true');
  assert.equal(host.getAttribute('data-running'), 'false');
  assert.equal(host.firstElementChild, orb);
  view.rerender(<ComposerOrbs focused={false} />);
  assert.equal(host.getAttribute('data-running'), 'true');
  assert.equal(view.container.firstElementChild, host);
});

test('hidden, offscreen and live accessibility changes pause motion and cleanup listeners', () => {
  const before = disconnects;
  const view = render(<ComposerOrbs focused={false} />);
  const host = view.container.firstElementChild!;
  visibility(true);
  assert.equal(host.getAttribute('data-running'), 'true');
  visibility(false);
  assert.equal(host.getAttribute('data-running'), 'false');
  visibility(true);
  act(() => {
    Object.defineProperty(document, 'hidden', { configurable: true, value: true });
    document.dispatchEvent(new Event('visibilitychange'));
  });
  assert.equal(host.getAttribute('data-running'), 'false');
  act(() => {
    Object.defineProperty(document, 'hidden', { configurable: true, value: false });
    document.dispatchEvent(new Event('visibilitychange'));
  });
  assert.equal(host.getAttribute('data-running'), 'true');
  for (const preference of ['reduced', 'forced']) {
    act(() => {
      if (preference === 'reduced') reduced = true;
      else forced = true;
      changes.forEach((fn) => fn());
    });
    assert.equal(host.getAttribute('data-running'), 'false');
    act(() => {
      reduced = false;
      forced = false;
      changes.forEach((fn) => fn());
    });
    assert.equal(host.getAttribute('data-running'), 'true');
  }
  view.unmount();
  assert.equal(disconnects, before + 1);
  assert.equal(changes.size, 0);
});

test('missing observer leaves inert static decoration', () => {
  const saved = dom.window.IntersectionObserver;
  Reflect.deleteProperty(dom.window, 'IntersectionObserver');
  try {
    const view = render(<ComposerOrbs focused={false} />);
    assert.equal(view.container.firstElementChild?.getAttribute('data-running'), 'false');
  } finally {
    Object.assign(dom.window, { IntersectionObserver: saved });
  }
});
