import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

const css = readFileSync('src/components/workspace/workspace.module.css', 'utf8');
const composer = readFileSync('src/components/workspace/WorkspaceComposer.tsx', 'utf8');

test('composer uses CSS orbs without retaining the WebGL renderer', () => {
  assert.match(composer, /<ComposerOrbs focused=\{focused\}/);
  assert.equal(existsSync('src/components/react-bits/GhostFibers.tsx'), false);
  assert.equal(existsSync('src/components/workspace/ComposerFibers.tsx'), false);
});

test('orbs retain translucent but visible cores and explicit content stacking', () => {
  assert.match(
    css,
    /\.composerOrbs\s*\{[^}]*z-index: 0;[^}]*pointer-events: none;[^}]*opacity: 0\.28;[^}]*transition: opacity 220ms ease;/s,
  );
  assert.match(css, /\.composerInputRow\s*\{[^}]*z-index: 1;/s);
  assert.match(css, /\.composerBottom\s*\{[^}]*z-index: 1;/s);
  assert.match(css, /\.composerOrb\s*\{[^}]*filter: blur\(18px\);/s);
  for (const color of ['139, 92, 246', '125, 165, 235', '221, 151, 195']) {
    assert.ok(css.includes(`--orb-color: ${color};`));
  }
  assert.match(css, /data-running='false'[^}]*animation-play-state: paused/s);
  assert.match(css, /data-focused='true'[^}]*opacity: 0;/s);
});

// Removing the inner scale would silently restore the old capped visual size.
test('all three orb visuals are three times their responsive tracks and clipped by the host', () => {
  const visual = css.slice(css.indexOf('.composerOrb {')).split('}')[0];
  assert.match(visual, /width: 100%;/);
  assert.match(visual, /height: 100%;/);
  assert.match(visual, /transform: scale\(3\);/);
  assert.match(visual, /transform-origin: center;/);
  assert.match(css, /\.composerOrbs\s*\{[^}]*border-radius: inherit;[^}]*overflow: hidden;/s);
  const decoration = readFileSync('src/components/workspace/ComposerOrbs.tsx', 'utf8');
  assert.match(
    decoration,
    /className=\{styles\.composerOrbX\}[^>]*>\s*<span className=\{styles\.composerOrbY\}>\s*<span className=\{styles\.composerOrb\}/,
  );
  const reducedMotion = css.slice(
    css.indexOf('@media (prefers-reduced-motion: reduce)', css.indexOf('.composerOrbs {')),
  );
  assert.doesNotMatch(reducedMotion.split('@media (forced-colors: active)')[0], /transform:/);
});

// Returning to local drift or easing would break the responsive track rebounds.
test('orbs bounce independently across container-aware bounds on separate transform axes', () => {
  assert.match(css, /container-type: size;/);
  assert.match(
    css,
    /width: min\(var\(--orb-width\), 70cqw, calc\(65cqh \* var\(--orb-ratio\)\)\);/,
  );
  assert.match(css, /aspect-ratio: var\(--orb-ratio\);/);
  for (const axis of ['X', 'Y']) {
    assert.match(
      css,
      new RegExp(
        `composerOrbBounce${axis} var\\(--bounce-${axis.toLowerCase()}\\) linear infinite alternate`,
      ),
    );
    const frames = css
      .slice(css.indexOf(`@keyframes composerOrbBounce${axis}`))
      .split('@keyframes')[1];
    assert.match(
      frames,
      new RegExp(`translate${axis}\\(calc\\(100cq${axis === 'X' ? 'w' : 'h'} - 100%\\)\\)`),
    );
    assert.doesNotMatch(frames, /(?:filter|background|width|height|left|top):/);
  }
  for (const [selector, width, ratio, x, y] of [
    ['.composerOrbX', 360, 1.44, 24, 17],
    ['.composerOrbX:nth-child(2)', 250, 1.25, 31, 21],
    ['.composerOrbX:nth-child(3)', 270, 1.2857142857, 37, 26],
  ]) {
    const rule = css.slice(css.indexOf(`${selector} {`)).split('}')[0];
    for (const declaration of [
      `--orb-width: ${width}px`,
      `--orb-ratio: ${ratio}`,
      `--bounce-x: ${x}s`,
      `--bounce-y: ${y}s`,
    ])
      assert.ok(rule.includes(declaration));
  }
  assert.doesNotMatch(css, /@keyframes composerOrb(?:Violet|Blue|Pink)/);
  for (const part of ['composerOrbX', 'composerOrbY', 'composerOrb']) {
    assert.ok(css.includes(`.composerOrbs[data-running='false'] .${part}`));
    assert.ok(css.includes(`.composerOrbs .${part}`));
  }
});

test('reduced motion retains static spots while forced colors hides decoration', () => {
  const rules = css.slice(css.indexOf('/* Independently blurred'));
  assert.match(
    rules,
    /@media \(prefers-reduced-motion: reduce\)\s*\{\s*\.composerOrbs\s*\{\s*transition: none;/,
  );
  assert.match(
    rules,
    /@media \(prefers-reduced-motion: reduce\)[\s\S]*?\.composerOrbs \.composerOrb\s*\{\s*animation: none;/,
  );
  assert.match(
    rules,
    /@media \(forced-colors: active\)\s*\{\s*\.composerOrbs\s*\{\s*display: none;/,
  );
});

test('orbs retain independent slow opacity-only shimmer cycles', () => {
  const base = css.slice(css.indexOf('.composerOrb {')).split('}')[0];
  assert.match(base, /composerOrbShimmer var\(--shimmer-duration\) ease-in-out infinite/);
  for (const [selector, duration, delay] of [
    ['.composerOrbX', 6, 0],
    ['.composerOrbX:nth-child(2)', 7.5, -2.5],
    ['.composerOrbX:nth-child(3)', 9, -5],
  ]) {
    const rule = css.slice(css.indexOf(`${selector} {`)).split('}')[0];
    assert.ok(rule.includes(`--shimmer-duration: ${duration}s;`));
    assert.ok(rule.includes(`--shimmer-delay: ${delay}s;`));
  }
  const match = css.match(/@keyframes composerOrbShimmer\s*\{((?:[^{}]|\{[^{}]*\})*)\}/);
  assert.ok(match, 'shimmer keyframes exist as a bounded CSS block');
  const frames = match[1];
  assert.match(frames, /opacity: 0\.55;/);
  assert.match(frames, /opacity: 1;/);
  assert.doesNotMatch(frames, /(?:transform|filter|background|width|height|left|top):/);
});
