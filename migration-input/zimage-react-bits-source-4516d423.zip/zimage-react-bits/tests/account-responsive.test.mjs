import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const css = readFileSync(
  new URL('../src/components/identity/identity.css', import.meta.url),
  'utf8',
);
const mobile = css.split('@media (max-width: 767px) {')[1]?.split('@media (max-height: 620px)')[0];

// These are responsive CSS contracts, not a substitute for browser layout checks.
test('mobile account settings stretch cards and the login/deletion section across the column', () => {
  assert.ok(mobile, 'mobile identity breakpoint exists');
  const settings = mobile.match(/\.zi-account-settings\s*\{([^}]+)\}/)?.[1];
  assert.ok(settings, 'mobile settings override exists');
  assert.match(settings, /display:\s*flex\s*;/);
  // Tablet uses align-items:start for a two-column grid. When switching back to
  // a column flexbox, leaving that value in place shrinks every child to its content.
  assert.match(settings, /align-items:\s*stretch\s*;/);
  const component = readFileSync(
    new URL('../src/components/identity/AccountPage.tsx', import.meta.url),
    'utf8',
  );
  assert.match(component, /className="zi-account-session"/);
  assert.match(css, /\.zi-account-session > \.zi-button\s*\{\s*width:\s*100%\s*;/);
});

test('mobile account inputs share the 16px input size used by authentication forms', () => {
  assert.match(
    mobile,
    /\.zi-auth-card \.zi-field input,\s*\.zi-account \.zi-field input\s*\{\s*font-size:\s*16px\s*;/,
  );
});
