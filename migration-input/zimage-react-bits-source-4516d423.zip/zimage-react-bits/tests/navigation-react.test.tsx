import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { JSDOM } from 'jsdom';
import React, { createRef } from 'react';

// Inspect the public Link boundary. Network scheduling belongs to Next and needs
// a production browser check; jsdom cannot establish navigation latency.
registerHooks({
  resolve(specifier, context, next) {
    if (specifier === 'next/link')
      return {
        url: new URL('../node_modules/next/link.js', import.meta.url).href,
        shortCircuit: true,
      };
    return next(specifier, context);
  },
  load(url, context, next) {
    if (url.endsWith('/node_modules/next/link.js'))
      return {
        format: 'module',
        source: `import React from 'react';
          export default function Link({prefetch, ...props}) {
            return React.createElement('a', {...props, 'data-prefetch': prefetch === null ? 'auto' : String(prefetch)});
          }`,
        shortCircuit: true,
      };
    return next(url, context);
  },
});
const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'https://zimage.test/create',
});
for (const key of [
  'window',
  'document',
  'navigator',
  'HTMLElement',
  'Element',
  'Node',
  'Event',
  'MouseEvent',
])
  Object.defineProperty(globalThis, key, {
    configurable: true,
    value: (dom.window as unknown as Record<string, unknown>)[key],
  });
(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
const { render, fireEvent, cleanup } = await import('@testing-library/react');
const { IntentLink } = await import('../src/components/IntentLink');
afterEach(cleanup);

for (const event of ['mouseEnter', 'focus', 'touchStart'] as const) {
  test(`scene prefetch starts only for the link receiving ${event}`, () => {
    const view = render(
      <>
        <IntentLink href="/create/product-set">First</IntentLink>
        <IntentLink href="/create/try-on">Second</IntentLink>
      </>,
    );
    const first = view.getByText('First');
    const second = view.getByText('Second');
    assert.equal(first.getAttribute('data-prefetch'), 'false');
    assert.equal(second.getAttribute('data-prefetch'), 'false');
    fireEvent[event](first);
    assert.equal(first.getAttribute('data-prefetch'), 'auto');
    assert.equal(second.getAttribute('data-prefetch'), 'false');
    fireEvent[event](first);
    assert.equal(first.getAttribute('data-prefetch'), 'auto');
  });
}

test('intent link preserves refs, handlers, semantics and stable DOM when enabling prefetch', () => {
  const ref = createRef<HTMLAnchorElement>();
  const calls: string[] = [];
  const view = render(
    <IntentLink
      href="/create/product-set"
      ref={ref}
      className="scene-card"
      aria-label="Scene"
      target="_blank"
      onMouseEnter={() => calls.push('hover')}
      onFocus={() => calls.push('focus')}
      onTouchStart={() => calls.push('touch')}
      onClick={(event) => {
        calls.push('click');
        event.preventDefault();
      }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element -- A plain image fixture verifies DOM identity, not image delivery. */}
      <img src="/sample.webp" alt="Example" />
    </IntentLink>,
  );
  const link = view.getByRole('link', { name: 'Scene' });
  const image = view.getByAltText('Example');
  fireEvent.mouseEnter(link);
  fireEvent.focus(link);
  fireEvent.touchStart(link);
  fireEvent.click(link, { ctrlKey: true });
  assert.deepEqual(calls, ['hover', 'focus', 'touch', 'click']);
  assert.equal(ref.current, link);
  assert.equal(view.getByAltText('Example'), image);
  assert.equal(link.getAttribute('href'), '/create/product-set');
  assert.equal(link.getAttribute('target'), '_blank');
  assert.equal(link.className, 'scene-card');
});

test('cancelled intent stays cold and a changed destination requires new intent', () => {
  const view = render(
    <IntentLink href="/create/product-set" onFocus={(event) => event.preventDefault()}>
      Scene
    </IntentLink>,
  );
  const link = view.getByText('Scene');
  fireEvent.focus(link);
  assert.equal(link.getAttribute('data-prefetch'), 'false');
  fireEvent.mouseEnter(link);
  assert.equal(link.getAttribute('data-prefetch'), 'auto');
  view.rerender(<IntentLink href="/create/try-on">Scene</IntentLink>);
  assert.equal(view.getByText('Scene'), link);
  assert.equal(link.getAttribute('data-prefetch'), 'false');
  fireEvent.focus(link);
  assert.equal(link.getAttribute('data-prefetch'), 'auto');
});
