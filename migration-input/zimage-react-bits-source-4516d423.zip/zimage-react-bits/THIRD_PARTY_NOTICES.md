# Third-party notices

## React Bits

Copyright (c) 2026 David Haz

This application includes adapted source for **StarBorder**, **FadeContent**, **GlassSurface**, and **GlideSelect**
from the free, public React Bits repository. No React Bits Pro content is used.

- Upstream: https://github.com/DavidHDev/react-bits
- Revision: `496968c4117e21278f13917201b7d615bc5e7450`
- GlassSurface/GlideSelect revision: `43591e8b3fa327d45633b4e8239ff6742ef706ef`
- License: **MIT + Commons Clause License Condition v1.0**
- Full, unchanged license text: [licenses/react-bits-LICENSE.md](licenses/react-bits-LICENSE.md)
- Static distribution copies: `public/licenses/react-bits-LICENSE.md` and
  `public/licenses/react-bits-NOTICE.txt`, exported to `out/licenses/`
- Selection, source paths, modifications, and integration notes:
  [docs/react-bits-selection.md](docs/react-bits-selection.md)

The upstream license permits use, modification, and distribution as part of an
application, website, or product, including commercial use. It restricts selling,
sublicensing, or redistributing the components themselves, alone, bundled, or
ported. Keep the full copyright and permission notice with application copies or
substantial portions. This is **not an unrestricted MIT-only license**.

The adaptations in this application are scoped to its UI. Do not extract this
directory into a component library or sell it as a component pack without
separate permission from the rights holder.

## Package dependencies

React, React DOM, Next.js, Lucide, TypeScript, and type-definition packages retain
their own licenses in their installed package distributions. The lockfile pins
the actual packages used by this prototype. This notice does not replace those
packages' license files.

## React Bits chat selections

This application also includes adapted ThoughtLine, LatticeLoader, ShinyText and
TextType source, copyright (c) 2026 David Haz, from revision
`c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a` of the same official repository.
These use MIT + Commons Clause; the exact license at that revision is preserved in
[licenses/react-bits-chat-LICENSE.md](licenses/react-bits-chat-LICENSE.md) and
`public/licenses/react-bits-chat-LICENSE.md`. See
[docs/react-bits-chat.md](docs/react-bits-chat.md) for pinned source links, retained
algorithms, scoped API adaptations and lifecycle changes.

## Historical Border Glow removal

The Border Glow adaptation was removed on 2026-10-19. See
[docs/border-glow.md](docs/border-glow.md) for historical provenance. Its shared
license remains required by the chat selections above. StarBorder remains in
source for historical regression coverage but is not used by application routes.
