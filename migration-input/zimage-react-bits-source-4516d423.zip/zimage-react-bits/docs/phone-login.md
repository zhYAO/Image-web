# Phone-code login demonstration

`/login/` and `/auth/` keep the existing fullscreen identity shell, with a +86 Chinese mainland phone field and six-digit code. This is a frontend demonstration, not authentication. Requesting a code makes no network call or SMS delivery. The visible local fixture is `123456`; successful verification explicitly says the user is **not logged in**. The application writes no token, cookie, phone number or verification code to storage.

## Ownership and behavior

- `PhoneLoginForm.tsx` owns the phone, code, challenge, feedback and request state. Leaving the login mode unmounts the form and cancels active work.
- `validation.ts` validates the mainland phone shape and six numeric code digits. The code input also filters nonnumeric characters; validation preserves field identity and focuses invalid fields.
- A synchronous request ref prevents repeated request/verify events before React renders disabled controls. Requests carry an `AbortSignal`; identity checks ignore late results even when an adapter fails to honor abort.
- A challenge is bound to the phone that requested it. Editing the phone clears the old code/challenge. Resend uses a 60-second wall-clock deadline rather than decrementing a drifting counter. Changing the number does not bypass that deadline.
- Inputs and submission remain disabled in server HTML until hydration. `method="post"` is a secondary URL-leak defense, not a server endpoint.
- Recovery, reset, email-verification and registration URLs remain available as truthful informational pages. Registration is closed and legal pages are unapproved drafts. Account balances and authentication remain unavailable.

## Real-service integration boundary

`phone-auth.ts` defines `PhoneAuthService`, `PhoneIdentity`, `PhoneCodeChallenge`, `PhoneCodeVerification`, `PhoneAuthError` and the local `demoPhoneAuth` implementation. The form accepts the service as a prop, keeping transport outside the visual component. Request results contain a challenge identifier and retry delay; verification currently returns only `{ kind: 'demo-verified' }`, never an authenticated identity.

Replacing the demo adapter is only one part of a real integration. The server must own OTP generation, expiry, attempt/rate limits, replay prevention, phone/challenge binding and secure session issuance. Never put provider secrets or an authoritative OTP check in the browser. Replace demo-specific labels, fixture-code feedback and success handling together with the service contract; do not remove the demo notice before the complete flow exists. Use safe user-facing error mapping instead of rendering raw provider errors. Handle actual sessions separately, preferably through server-issued secure cookies rather than browser token storage.

This change deliberately does not add an endpoint, SDK, provider credential, automatic registration, accepted legal agreement or live SMS test.

## Verification boundary

The existing Node/jsdom suites cover validation, same-tick duplicate requests, resend timing, error recovery, phone changes, late responses, unmount cancellation, field identity, legacy routes and server-rendered disabled controls. Pixel layout, mobile keyboard behavior, browser autofill and real SMS/authentication require separate verification; a demo test does not establish backend readiness.
