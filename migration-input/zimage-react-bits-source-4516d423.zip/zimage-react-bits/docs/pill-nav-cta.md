# Homepage Pill Nav CTA

Verified on 2026-10-19 against [React Bits Pill Nav](https://reactbits.dev/components/pill-nav)
and the public DavidHDev/react-bits repository, pinned at
[`c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a`](https://github.com/DavidHDev/react-bits/commit/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a).

## Source and license

- [Official PillNav.tsx](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/ts-default/Components/PillNav/PillNav.tsx)
- [Official PillNav.css](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/ts-default/Components/PillNav/PillNav.css)
- [Official license](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/LICENSE.md)

Copyright 2026 David Haz, **MIT + Commons Clause**. The pinned license adds upstream tool/export clauses to the earlier React Bits
license, so its full unchanged text is retained separately in
`licenses/pill-nav-LICENSE.md` and the identical exported
`public/licenses/pill-nav-LICENSE.md`, alongside
`public/licenses/pill-nav-NOTICE.txt` attribution. Existing component licenses
remain unchanged. This is a selected application
adaptation, not redistribution of a standalone component package or Pro content.

## Adaptation

`src/components/landing/PillNavCTA.tsx` supplies all three homepage
“开始创作” links: header navigation, hero and final section. The `nav` variant
retains the existing compact `zl-nav-cta` geometry and menu-close click handler;
the default variant retains `zl-button zl-button-primary`. It preserves `/workspace`, the existing Next Link default
prefetch behavior, native link semantics, text, arrow, padding, responsive sizing,
and pill border radius. No replacement navigation, mobile menu, active indicator, intro animation,
client effect, observer, timer, GSAP dependency or animation loop is added.

The official `pill-nav__fill` expands a circular fill centered at the bottom edge,
while `pill-nav__face` and `pill-nav__face-alt` roll vertically. The scoped CSS
adapter preserves its 550 ms fill entry, 500 ms label entry, 360 ms return and
cubic-bezier easing. For these fixed, wide CTA links, a 200%-width circle with
square aspect ratio covers the button without upstream's runtime measurements.
It replaces the old whole-button lift/instant recoloring with a dark-to-violet
circular fill and paired rolling labels. Local label clipping prevents the
outgoing copy from remaining visible inside the button padding.

Fine-pointer hover and keyboard focus-visible trigger the same feedback; the
focus outline remains independent. Decorative fill and duplicate labels are
hidden from assistive technology. Reduced motion uses immediate static color
feedback, with no label movement; forced colors hides the decoration and retains
system-colored text and focus outlines. Media-query changes apply live. CSS
transitions reverse on exit and stop at endpoints, with no resource lifecycle.

## Evidence boundary

`tests/pill-nav-cta.test.mjs` checks the hero/final and header callsites, server-rendered native link,
single accessible label, unchanged prefetch configuration and scoped CSS motion,
focus, coarse-pointer, reduced-motion and forced-colors contracts. CSS is stubbed
for server rendering; these are source/DOM checks, not pixel or browser animation
verification. Final application build/budget checks belong to the coordinated
release verification. Browser hover, focus and media-preference visual QA must be
reported separately when actually performed. The navigation interaction regression
also checks the single accessible CTA label, compact classes, destination and
menu closing. BorderGlow has been removed; the PillNav animation is independent.
