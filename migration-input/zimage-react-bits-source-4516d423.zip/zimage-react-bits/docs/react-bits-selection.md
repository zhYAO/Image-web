# React Bits selection and integration

Verified against the official public repository on **2026-10-15**. This is an
independent application prototype. The previous `zimage-home-preview` directory
was read only and has not been modified by this integration.

## Selected components

1. **StarBorder** (historical; no runtime consumers; the later [BorderGlow adaptation was removed](border-glow.md)) previously supplied the requested flowing border and subtle breathing on
   the five commerce catalogue cards. Its original perimeter geometry, canvas
   trail drawing, glow, projection, and input machinery are retained. The root is
   the actual link or button, with a decorative, pointer-transparent canvas.
2. **FadeContent** supplies modest, one-time landing/section reveals. Its original
   fade/optional-blur wrapper and a small prop subset are adapted to the browser's
   Web Animations API and IntersectionObserver instead of adding GSAP solely for
   one reveal effect. This is explicitly an **adaptation**, not an unchanged
   upstream implementation.

3. **GlassSurface** supplies restrained optional SVG glass and the default frosted material through shared `Glass`.
4. **GlideSelect** supplies animated value menus with application portal/accessibility adaptations.

No whole-library package, Pro content, 3D scene, cursor effects, global
animated background, motion package, or GSAP dependency has been added.
SpotlightCard was considered and deliberately omitted: layering another card
effect would change the existing visual language without serving this task.

## Official source and license

Pinned upstream commit:
[`496968c4117e21278f13917201b7d615bc5e7450`](https://github.com/DavidHDev/react-bits/commit/496968c4117e21278f13917201b7d615bc5e7450).

| Source                                                                                                                                                         | Original Git blob SHA                      |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------ |
| [StarBorder.tsx](https://github.com/DavidHDev/react-bits/blob/496968c4117e21278f13917201b7d615bc5e7450/src/ts-default/Animations/StarBorder/StarBorder.tsx)    | `59abc67186187a1fab190f7de08cb26d58d7dafc` |
| [StarBorder.css](https://github.com/DavidHDev/react-bits/blob/496968c4117e21278f13917201b7d615bc5e7450/src/ts-default/Animations/StarBorder/StarBorder.css)    | `8a6a91dd6b9f429e9cf9784f9e0a7cc0850421ca` |
| [FadeContent.tsx](https://github.com/DavidHDev/react-bits/blob/496968c4117e21278f13917201b7d615bc5e7450/src/ts-default/Animations/FadeContent/FadeContent.tsx) | `6ed7511ac61e2eb3e6d8e54acf0864d620872af3` |
| [LICENSE.md](https://github.com/DavidHDev/react-bits/blob/496968c4117e21278f13917201b7d615bc5e7450/LICENSE.md)                                                 | `6425315416e94469f28d0223a09f7285b2f785ab` |

The official license is **MIT + Commons Clause License Condition v1.0**, copyright
2026 David Haz. It expressly allows application/website/product use and commercial
use, while restricting redistribution of the components themselves. The exact
license is retained in `licenses/react-bits-LICENSE.md`; see also
`THIRD_PARTY_NOTICES.md`. No claim of unrestricted MIT-only licensing is made.

An identical license and short attribution notice are also in `public/licenses/`.
Next's static export carries them into `out/licenses/`, so a compiled application
distribution retains the notices even when JavaScript comments are minified away.
Only the application is distributed; raw component source is not published as a
separate component library. Keep these static notice files with exported copies.

## GlassSurface integration (2026-10-15)

The shared `Glass` API now re-exports `react-bits/GlassSurface.tsx`, with the
optional `GlassSurfaceEffect.js` controller and shared `liquid-glass.css` paint.
Pinned official upstream revision:
[`43591e8b3fa327d45633b4e8239ff6742ef706ef`](https://github.com/DavidHDev/react-bits/commit/43591e8b3fa327d45633b4e8239ff6742ef706ef).

- [Official GlassSurface.tsx](https://github.com/DavidHDev/react-bits/blob/43591e8b3fa327d45633b4e8239ff6742ef706ef/src/ts-default/Components/GlassSurface/GlassSurface.tsx)
- [Official GlassSurface.css](https://github.com/DavidHDev/react-bits/blob/43591e8b3fa327d45633b4e8239ff6742ef706ef/src/ts-default/Components/GlassSurface/GlassSurface.css)
- [Official component](https://reactbits.dev/components/glass-surface)

Retained: transparent RGB displacement ramps, explicit SVG soft-center Gaussian
blur, separated RGB displacement/color matrices, screen blending, and frosted
CSS blur/saturation/brightness with inset top/bottom highlights. The exact
upstream license remains in both source and exported notices.

Application adaptations: semantic `as`/ref/native-attribute forwarding, direct
stable children, geometry owned by the caller, four computed corner radii,
restrained -50/-47/-44 displacement, scoped light/dark tint and shared fallbacks.
The already-tested application lifecycle manager is retained around the Bits
algorithm: one observer per document, settled resize updates, per-target filters,
reference-counted cleanup, BFCache suspension and live accessibility preferences.
Default `refract={false}` uses the visible Bits frosted material with no SVG
allocation; `refract` dynamically loads only its effect. There is no animation
loop. Upstream's SVG-browser gate is retained; Safari/Firefox use CSS frosting.

Unlike upstream's demonstration wrapper, this integration does not impose a
200×80 size, padding, flex content wrapper, or overflow clipping. It omits the
WebGL renderer, image/video/canvas backdrop API, arbitrary `shape` rasterizer,
and advanced visual props because the application uses one bounded material.
This is a documented source adaptation, not an unchanged upstream component.
The former `src/lib/liquid-glass-engine.js` is superseded and removed.

## GlideSelect integration (2026-10-15)

The same free-source revision `43591e8b3fa327d45633b4e8239ff6742ef706ef`
supplies [GlideSelect](https://reactbits.dev/c/micro/glide-select):
[TypeScript source](https://github.com/DavidHDev/react-bits/blob/43591e8b3fa327d45633b4e8239ff6742ef706ef/src/ts-default/Micro/GlideSelect/GlideSelect.tsx)
and [CSS](https://github.com/DavidHDev/react-bits/blob/43591e8b3fa327d45633b4e8239ff6742ef706ef/src/ts-default/Micro/GlideSelect/GlideSelect.css).
The local `react-bits/GlideSelect.tsx` retains the phase/pop animation, translated
hover pill, sizes, selected-label swap, chevron and check. Existing Lucide icons
replace Hugeicons, so no dependencies are added. Application changes add a
fixed, viewport-bounded, dialog-aware portal, scroll handling, native click/touch
activation, controlled values, keyboard/typeahead/Escape, empty/disabled safety,
and forced-colors/reduced-motion treatment. See [AGENTS quick reference](../AGENTS.md#6-shared-material-and-react-bits-quick-reference) for the
complete API and integration notes. This replaces value-selection dropdowns;
command menus and interactive dialog popovers retain their own correct semantics.

The 2026-10-19 model-selector integration adds optional `textValue` for rich icon/name
labels, readonly option inputs and reset-on-open typeahead. The shared model wrapper
uses the same GlideSelect; no second dropdown implementation or icon dependency is added.
Menus retain the existing opaque-white theme, dialog-aware portal, viewport bounds,
selected state, keyboard/focus and motion-preference behavior. See
[model catalog and state contracts](model-selectors.md).

## Direct imports and rendering

Import only the component in use, with no barrel file:

```tsx
import StarBorder from '@/components/react-bits/StarBorder';
import FadeContent from '@/components/react-bits/FadeContent';
```

Both are client components, safe to render beneath Next server components. The
server markup remains usable, and no browser API runs during server rendering.
For a below-the-fold reveal or secondary route, split the individual component
with `next/dynamic` or the route boundary. Pass server-rendered children through
the wrapper so dynamic loading does not replace actual content with a blank
placeholder. Do not set `ssr: false` just to run these components. StarBorder's
first-screen use is intentionally a direct import so no late card swap is needed.

For genuinely deferred below-the-fold use, the same module also exports
`FadeContentEffect`. It accepts `targetRef: RefObject<HTMLDivElement | null>` plus
the reveal options and renders `null`. Keep the host div and its children mounted
from server render, then conditionally load only this effect controller near the
viewport. This avoids both loading-placeholder collapse and child remounts. The
default wrapper and controller use the same internal lifecycle hook.

### StarBorder

The local `hover="reveal"` adaptation plays one full lap per new hover or keyboard-focus activation, then holds a static highlight without a continuing RAF loop. Breathing is limited to playback; real leave/re-entry rearms the lap. Hidden/offscreen time pauses progress, and reduced-motion remains static.

```tsx
import Link from 'next/link';
import StarBorder from '@/components/react-bits/StarBorder';

<StarBorder
  as={Link}
  href="/commerce/"
  className="catalogue-card"
  theme="light"
  color="#8b6fc1"
  trailColor="#c4b2e2"
  backgroundColor="transparent"
  radius={23}
  thickness={2}
  duration={3.8}
  trailLength={0.18}
  glow={0.45}
  breath={0.24}
  hover="reveal"
  sparkle={false}
  clickPulse={false}
>
  {/* Non-interactive card contents, no nested link/button. */}
</StarBorder>;
```

Important integration details:

- `as` is polymorphic: native `a`, `button`, or a ref-forwarding link such as
  Next's `Link`. Use an actual anchor for navigation, not a clickable `div`.
- `duration` is **seconds**, matching upstream. There is no legacy `speed` prop.
- `radius` must match the visible card's corner radius, in pixels.
- The official component has button-like padding, inline-flex alignment, and a
  surface color. Let the application card class set `display: block`, `padding:
0`, width, and layout where necessary. Pass surface/text/track colors explicitly.
- Use `hover="reveal"` for hover/focus-only motion. This is the local default,
  changed from upstream's default `lap`. It fades out and idles after interaction.
- `breath` is the only new animation prop: an amplitude from 0 to 1, default 0.16.
  It gently changes trail luminance on a 4.8-second cycle. Set 0 to disable.
- Existing upstream props remain available: `color`, `trailColor`, `thickness`,
  `trailLength`, `stars`, `glow`, `sparkle`, `direction`, `hover`, `clickPulse`,
  `theme`, `backgroundColor`, `textColor`, `borderColor`, class/style and native
  attributes. No application API or state is coupled to the effect.

### FadeContent

```tsx
<FadeContent duration={600} delay={0} threshold={0.12} rootMargin="0px 0px -8% 0px" distance={12}>
  <section>{/* Real server-rendered content. */}</section>
</FadeContent>
```

The retained API subset is `children`, `blur`, `duration`, `delay`, `ease`,
`threshold`, `initialOpacity`, `onComplete`, `className`, `style`, and ordinary
div attributes. Differences from current upstream:

- `duration` and `delay` are **always milliseconds**. The original accepts a
  mixed seconds/milliseconds convention; this adaptation is intentionally clear.
- `ease` accepts a CSS easing string, not a GSAP ease name.
- `distance` (default 12 px) and `rootMargin` (default `0px`) are additions.
- The named `FadeContentEffect` controller is an application-specific addition
  for delayed enhancement without changing the server-rendered content tree.
- `container`, `disappearAfter`, `disappearDuration`, `disappearEase`, and
  `onDisappearanceComplete` are not implemented. Content does not disappear again.
- It reveals once per mounted instance with stable visual props. Do not put it
  around tiles that are deliberately remounted by filtering/sorting. Prefer a
  stable section wrapper. Keep callback identity out of animation dependencies.

## Lifecycle, accessibility, and compatibility changes

StarBorder uses padding-box canvas measurements (`clientWidth`/`clientHeight`) and matching pointer coordinates. A pale-violet under-stroke separates the violet core from card imagery; the former white-on-white recipe failed visible-browser acceptance. The static track sits below the animated canvas. StarBorder keeps the original 2D canvas implementation and regular React
`useEffect`/`useRef` APIs. It does **not** require React 19.3 APIs. Local changes:

- Observe live `prefers-reduced-motion` changes. A reduced-motion hover/focus is
  static, with no continuous RAF, lap, pulse, dust, or breathing.
- Cancel RAF immediately on document hiding and offscreen intersection. Resume
  only when appropriate, reset delta timing, and cancel on unmount.
- Use guarded ResizeObserver/IntersectionObserver with a resize fallback.
- Use focus-in/out to include keyboard-focused descendants; provide a visible
  focus outline and a forced-colors fallback. Canvas remains `aria-hidden` and
  pointer-transparent.
- Ignore touch pointer-enter so a tap cannot leave the hover-only effect latched.
- No state updates per frame; React children are not remounted by the effect.

FadeContent's server HTML and non-JavaScript fallback are visible. A live reduced
motion change or keyboard focus cancels the reveal immediately. Hidden documents
pause an active Web Animation; all observer, listener, animation, and callback
resources are cleaned up on unmount. Missing browser APIs leave readable content.

The visible violet moving edge is decorative; it is not a
status indicator or the only signal for interactivity. Semantic links and the
solid keyboard outline remain independently usable, and forced-colors mode uses
a regular system-color border. Check actual text/icon contrast in the final app's
light/dark palettes separately; this component test suite does not establish WCAG
contrast conformance for application styles. Canvas rendering, antialiasing,
glow clipping, coarse-pointer behavior, and actual reduced-motion OS integration
still need real-browser review of the assembled pages.

## Verification

`node --test tests/react-bits-lifecycle.test.mjs` tests the actual transpiled
component effects with a deterministic DOM/canvas/RAF harness:

- Hover-only idle/start and immediate offscreen/background pause
- Live reduced-motion switching, including hover/click behavior
- Link semantics, observer fallbacks, and all cleanup paths
- Visible server markup and single reveal behavior
- Observer geometry, tab visibility, reduced motion and keyboard cancellation
- Readable fallback without browser animation APIs
- Identical, complete source and static-distribution license notices

The focused lifecycle suite additionally checks padding-box stroke bounds, clockwise travel and under-stroke coverage and already-hovered hydration activation. `npm run typecheck` also
passed when these files were added. These checks do not replace real-browser
visual, touch, keyboard, or complete application integration testing. Run the
application's full verify command and browser checks after all page work lands.

## Workspace decoration (2026-10-18)

The workspace now uses application-owned CSS gradient orbs in `ComposerOrbs`, following
the updated lightweight-design request. It is not a React Bits component. Three
independent violet/blue/pink radial gradients are now 360×250, 250×200 and 270×210 px
(twice their previous width and height), with fixed blur and 28% host opacity.
18–27 second transform-only drift combines with independent 6/7.5/9 second opacity
shimmer cycles between 55% and 100%, smoothly eased with staggered phases. Focus pauses motion and fades the host out in 220 ms;
hidden/offscreen and accessibility preferences suspend motion. The input remains stable.
The previous Ghost Fibers implementation, its tests and its exclusive source/exported
license copies were removed. No WebGL exception remains. The four retained React Bits
adaptations and their complete original license/attribution files are unchanged.
