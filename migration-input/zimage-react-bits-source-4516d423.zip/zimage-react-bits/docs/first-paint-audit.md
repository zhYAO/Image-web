# First contentful paint: diagnosis and acceptance protocol

Reviewed 2026-10-15. Target: homepage FCP ≤800 ms under an explicitly recorded test profile. A user-supplied Edge trace for the earlier deployment measured **21,036.157 ms FCP**, so that sample fails the target. The current restored-glass/inline-CSS revision requires a fresh recording; file sizes and passing source tests do not establish their FCP.

## Source-level findings and change

The homepage already renders meaningful HTML at build time, with system fonts and two initial stylesheets. The headline does not wait for React hydration or a font download. Shared framework JavaScript matters for hydration, but removing it is neither necessary for SSR text painting nor compatible with preserving the requested React application.

The previous hero animations nonetheless masked that HTML: `zl-hero-enter` started at opacity zero with backwards fill, and the title combined opacity zero with a 10 px blur. The description waited 160 ms and CTA 240 ms before their 900 ms entrance; the gallery waited 250 ms before its 1100 ms entrance. The fixed navigation was visible, so these delays were **not proof of the FCP bottleneck**. They were a source-level cause of delayed readable hero content and potentially later LCP.

The hero keyframes now animate only transforms. Existing timing, stagger, translation trajectory, final geometry and reduced-motion overrides remain intact; text and imagery are no longer deliberately transparent/blurred while their entrance runs. The title animation is named `zl-title-enter` to reflect this. A source-contract test checks both hero keyframes retain transforms without opacity/filter masking. This is not a browser visual-regression test. Scroll-triggered below-fold FadeContent remains unchanged.

## Critical path and hosting checks

The baseline export before this change contained:

- Homepage HTML: 46,249 raw bytes; 8,886 bytes gzip at level 9.
- Two render-blocking stylesheets together: 46,560 raw bytes; 10,030 bytes gzip.
- Initial modern JavaScript: 496,062 raw bytes; 149,629 bytes gzip.
- Eager image declarations: 97,628 bytes; additional native-lazy images may load near the viewport.

These are the existing build's baseline, not final combined-build measurements. Rebuild before using the analyzer for the new output. Other concurrent work can change shared resources.

A real FCP diagnosis must separate navigation response latency, stylesheet discovery/transfer, and main-thread render delay. The page has no external font dependency. SSR content avoids a hydration gate; images need not finish for the header and text to paint. JavaScript and near-viewport image downloads can still contend for bandwidth/CPU. Do not equate the sum of every declared asset with a serial FCP critical path.

The documented Python `http.server` preview sends uncompressed files by default. The analyzer's hypothetical gzip totals are **not** its transferred bytes. This server is useful for local correctness but is not a production compression/cache simulation. Inspect actual `Content-Encoding`, `Cache-Control`, document TTFB and resource timing on the authorized serving environment. HTTP caching/compression must be configured by the static host; Next static export alone does not establish response headers. Do not mark unhashed image URLs immutable unless the serving workflow also versions or invalidates them. No hosting configuration or deployment was changed by this audit.

## Reproducible acceptance profile

Use the production export, never `next dev`. Record build identity/time, serving URL, browser/version, OS, hardware, viewport/DPR, network profile, CPU throttling and cache conditions before interpreting 800 ms.

User-approved primary target: desktop Edge (Chrome is also acceptable) on normal broadband, cold-cache initial navigation. Record measured network conditions rather than treating “normal broadband” as a fixed latency/bandwidth guarantee. Suggested reproducible diagnostic viewport: current Chromium desktop, 1440 × 900 CSS pixels, DPR 1, no CPU/network throttling, foreground tab, fresh navigation with cache disabled and no service worker. This is a **local diagnostic profile**, not a claim about mobile users or the public site's geographic latency. Run a second cold-cache test at 390 × 844 with an explicitly named network/CPU profile representative of intended users. Keep warm-cache results separate.

1. Build once after all source edits, then serve that export in an authorized environment.
2. With DevTools open, disable cache, start a Performance recording and navigate directly to `/`. Do not use an in-app route transition as an initial-navigation sample.
3. Repeat five fresh navigations under identical conditions. Record all five FCP values and the median; inspect slow samples, rather than discarding them. A median ≤800 ms must be described as a median, not “every run ≤800 ms.”
4. Export the trace/waterfall and record document TTFB, stylesheet finish times, main-thread long tasks, image activity and compression. Include LCP and layout shifts separately; FCP only describes the first contentful pixels.
5. Repeat with JavaScript disabled to confirm SSR text and real navigation links remain visible. Review initial/intermediate/final animation frames on desktop and narrow screens, plus reduced motion, before claiming no visual regressions.

The following read-only DevTools expression captures browser-observed evidence for the current navigation. Run after loading; it does not simulate a network, clear caches or manufacture a missing result. A missing FCP stays `null`.

```js
(() => {
  const nav = performance.getEntriesByType('navigation')[0];
  const fcp = performance.getEntriesByName('first-contentful-paint')[0];
  return {
    capturedAt: new Date().toISOString(),
    url: location.href,
    userAgent: navigator.userAgent,
    viewport: { width: innerWidth, height: innerHeight, dpr: devicePixelRatio },
    visibility: document.visibilityState,
    fcpMs: fcp?.startTime ?? null,
    navigation: nav?.toJSON() ?? null,
    resources: performance.getEntriesByType('resource').map((entry) => entry.toJSON()),
  };
})();
```

Transfer sizes of zero alone do not prove cache hits: timing visibility and browser restrictions can also produce zeros. Confirm cache and compression in the Network panel. Report the actual metric and conditions rather than translating file-size improvements into an invented number of milliseconds.

## Current evidence boundary

Source inspection and the hero regression test establish removal of intentional first-screen opacity/blur masking. The cloud-browser localhost route was unreachable across execution environments. The published private site requires sign-in, and initiating authentication requires explicit authorization; no credentials were entered. A read-only task on the already authorized Mac was started to check whether existing browser access supports measurement. No login gate or browser restriction was bypassed. FCP ≤800 ms and screenshot parity remain unverified until authorized browser measurements are available.

## Uploaded Edge baseline and corrective experiment (2026-10-15)

The user supplied `Trace-20261015T205651.json.gz`, recorded at 12:56:51 UTC before the official-glass/inline-CSS revision. Matching the main frame and navigation ID establishes FCP = **21,036.157 ms**, not a duration relative to trace start. The sole LCP candidate is the hero accent-title text at the same time. Document response-header start is approximately **1,221.304 ms** after navigation, already beyond the 800 ms target.

Two initial render-blocking stylesheets were discovered at approximately 1,235 ms and completed at **20,104.753 / 20,245.619 ms**. Their recorded network timing contains approximately **18.46 seconds before sendStart**, followed by only 351–500 ms to response headers. This supports a pre-send waiting diagnosis, not an assertion of slow CSS processing, origin processing, CDN failure, or extension causation. Extensions were active; their presence alone does not explain the wait. Browser-cache misses and CDN HITs were observed, but the exact cold-cache procedure and CPU/network throttling are not established. The last stylesheet-to-FCP interval of 790.538 ms is **not FCP** and is not a passing score.

The controlled code change uses Next 16.3.8's documented experimental `inlineCss` option. Initial exported documents carry their CSS in `<style>` tags instead of waiting for separate stylesheet requests. This removes the two observed initial CSS dependencies; it does not resolve unknown network scheduling or document TTFB and does not prove an 800 ms result. The supported option is global, production-only, duplicates CSS in the initial RSC payload and loses independent CSS caching on direct document loads; client-side navigations still use stylesheet links. Review this trade-off with actual measurements before adopting it in the real product.

The export analyzer now enforces **zero initial stylesheet-link requests** and a **48 KiB gzip initial-HTML cap**, alongside unchanged JavaScript/image limits. These are file-level regression guards, not network/performance measurements. Keep uploaded traces, response bodies, source maps and raw logs outside Git. Re-record the deployed revision under the same stated conditions before comparing improvement.
