# React preview performance review

Production export inspected: **2026-10-15**, after restoring the b79fe4e glass appearance while preserving the experimental inline-CSS critical-path change and ref lifecycle fixes. Framework: **Next.js 16.3.8, React/ReactDOM 19.2.7, TypeScript 6.0.3**.

## Result and limits

The final combined `npm run verify` passed: lint, formatting, type generation/typecheck, **79/79 unit/source-contract tests**, **54/54 React interaction tests**, production audit (**0 vulnerabilities**), static build and bundle/image budgets. This production-only audit does not clear the separately documented development-tool advisory. The implementation is genuine React with static App Router output, isolated interactive components, and verified asynchronous chunks. No old application is injected through HTML or an iframe.

The resource inventory below consists of **static production-file measurements**. A user-supplied Edge trace from the earlier deployment recorded **21,036.157 ms FCP**, which fails the ≤800 ms target. No fresh runtime FCP measurement exists for this build. Browser paint/layout cost, device memory and frame rate have not been measured for the restored-glass/inline-CSS revision; it also requires visual acceptance. Earlier browser checks are not proof of this revision's rendering. Initial JavaScript means unique script and script-preload files declared by each route's HTML. It excludes a separately measured **38.59 KiB gzip `noModule` legacy polyfill**, skipped by modern module browsers. Gzip is calculated at level 9 per file; actual hosting compression and transfer can differ.

Ordinary navigation links retain Next.js prefetching, so later network transfers can exceed the initial declaration totals. Heavy editor card links use `IntentLink`: prefetch remains disabled until mouse hover, keyboard focus or touch start, then Next resumes its normal per-link prefetch scheduling. This avoids warming all five editors just because their cards entered the viewport. Native lazy images can still load immediately when near the viewport; the eager-image column below is not a full image waterfall.

## Measured initial resources

All sizes are KiB. JavaScript, external CSS and HTML use per-file gzip. Inline CSS is included in HTML bytes; zero external CSS does not mean zero styles or zero CSS processing cost. Images are their already-compressed WebP bytes, deduplicated by URL within each route.

| Route                      | Initial JS | External CSS | HTML including inline CSS | Eager image declarations |
| -------------------------- | ---------: | -----------: | ------------------------: | -----------------------: |
| `/`                        |     146.63 |         0.00 |                     28.35 |                    95.34 |
| `/workspace/`              |     150.59 |         0.00 |                     25.67 |                   345.89 |
| `/create/`                 |     151.97 |         0.00 |                     39.57 |                     0.00 |
| `/create/product-set/`     |     165.89 |         0.00 |                     44.08 |                   666.88 |
| `/create/detail/`          |     165.89 |         0.00 |                     44.03 |                   476.39 |
| `/create/clone/`           |     165.89 |         0.00 |                     43.70 |                   172.73 |
| `/create/product-main/`    |     165.89 |         0.00 |                     44.25 |                   255.91 |
| `/create/apparel-catalog/` |     165.89 |         0.00 |                     43.67 |                   177.74 |
| `/assets/`                 |     153.91 |         0.00 |                     38.58 |                   386.96 |
| `/account/`                |     147.34 |         0.00 |                     29.48 |                     0.00 |
| Auth routes and aliases    |     142.09 |         0.00 |                9.20–11.64 |                     0.00 |
| Legal routes               |     138.37 |         0.00 |                      9.08 |                     0.00 |

Six shared initial files account for **133.89 KiB gzip**, including the framework runtime and shared application code. The analyzer's modern uncompressed initial totals are file inventory measurements; they do not represent transferred bytes.

Compared with the preceding official-demo glass build, homepage initial JS decreased from **146.97 to 146.63 KiB gzip**, workspace from **150.89 to 150.59 KiB**, assets from **154.21 to 153.91 KiB**, and commerce editors from **166.20 to 165.89 KiB**. Image inventory and eager image totals are unchanged.

### Inline CSS: removed requests, increased document size

All exported routes now declare **zero initial stylesheet requests**, verified by the analyzer. Next's `experimental.inlineCss: true` moves the initial styles into the document rather than making the browser wait for separate stylesheet requests. Homepage HTML increased from **8.69 to 28.35 KiB gzip** (+19.66 KiB); workspace from **7.11 to 25.67 KiB** (+18.56 KiB); assets from **9.23 to 38.58 KiB** (+29.35 KiB). The largest document is product-main at **44.25 KiB gzip**, below the new 48 KiB cap. This is not a total-byte reduction: inline styles and their RSC representation increase HTML size, and styles no longer benefit from the same separate cross-page stylesheet cache reuse. CSS parsing/rendering remains necessary. Existing JS and image limits were not raised.

The change targets evidence from the earlier user trace, recorded at **12:56:51 UTC**: document response headers began about **1,221 ms** after navigation; the two blocking CSS requests were discovered around **1,235 ms** but finished near **20,105 / 20,246 ms**. Their timings contained approximately **18.46 seconds before sendStart**. This is evidence of pre-send waiting, not proof of expensive CSS computation or a specific CDN, origin, extension or browser defect. Its exact cause remains unknown. Removing those initial requests eliminates that particular request dependency, but does not prove the new build meets 800 ms; the earlier document response alone exceeded the target. See [the trace analysis and measurement protocol](first-paint-audit.md). Desktop Edge is accepted alongside Chrome; use a fresh recorded navigation with the agreed broadband/cold-cache conditions.

## Actual deferred chunks

Each following file is absent from initial HTML script/preload declarations. Its emitted Turbopack asynchronous loader reference was inspected, together with the conditional source call site. This checks actual bundle splitting, rather than only finding an `import()` string in source.

| Feature                        | Gzip KiB | Load condition                                | Emitted chunk      |
| ------------------------------ | -------: | --------------------------------------------- | ------------------ |
| Homepage FadeContent effect    |     0.95 | Section approaches viewport                   | `2k3_bst6gac_9.js` |
| Workspace reference viewer     |     0.49 | Reference opened                              | `2ax9tqntv30md.js` |
| Commerce dialog                |     0.65 | Dialog opened                                 | `0-e9yrlu7u_5l.js` |
| Commerce result cards          |     0.73 | Results displayed                             | `0lnea2ju3f9-s.js` |
| Asset image/collection content |     1.07 | Dialog opened                                 | `18m1ydxo-tpli.js` |
| GlassSurface SVG controller    |     2.80 | Hydrated GlassSurface with explicit `refract` | `05hr6ftt10z03.js` |

The auth page's small, first-screen FadeContent treatment is included in its route bundle. StarBorder is included on the catalogue route because the cards are immediately interactive. Four selected React Bits sources/adaptations are integrated: **StarBorder, FadeContent, GlassSurface and GlideSelect**, with their license retained. GlassSurface is the shared material implementation behind `Glass`; its CSS fallback and semantic host are initial code, while the SVG controller is dynamically imported. Refraction defaults to disabled again; explicit `refract` keeps the restrained -50/-47/-44 channel displacement and 7px backdrop blur. Navigation/topbar opt-ins load the SVG controller after hydration; ordinary panels use CSS frosting. React callback-ref cleanup and class/radius-change recovery remain fixed. GlideSelect is initial route code where visible selection controls need it. The asset image/collection chunk remains **1.07 KiB gzip**; the glass controller is **2.80 KiB gzip**, and commerce results **0.73 KiB**. These are component-chunk sizes, not total feature costs. There is no React Bits package, GSAP, motion framework, Three.js, or WebGL dependency.

The export contains **12 verified async loader edges**. One additional 3.57 KiB framework chunk and three small build manifests are absent from initial HTML but are not classified as interaction-deferred features solely from that absence.

## Resolved regression risks

- **Hero content is immediately readable in SSR CSS.** Entrance keyframes preserve translation and timing but no longer start hero text/images at opacity zero or blur the title. This removes an intentional readability delay; it does not establish browser FCP. The agreed target is desktop Chrome or Edge, normal broadband, cold cache, **≤800 ms FCP**; see [first-paint audit](first-paint-audit.md) for the evidence boundary and reproducible protocol.
- **Typing no longer invalidates session-only or notification-only consumers.** AppProvider has separate composer, session, and stable notification contexts. A real React render-count test verifies that draft changes leave unrelated consumer counts unchanged.
- **Commerce examples avoid per-keystroke layout work.** The examples are memoized, and the sizing observer no longer depends on newly allocated React children. Asset images are also memoized.
- **Deferred reveal preserves existing DOM.** A stable host always owns its children; the lazy effect controller adds no DOM. The real React test preserves a user-edited input and its node identity through loading.
- **Motion has bounded lifecycle costs.** The used StarBorder reveal mode is idle until hover/focus and settles after exit. Offscreen, hidden-tab, reduced-motion and unmount paths stop it. Both carousels pause appropriately; continuous scroll transforms use refs and only active-step changes update React state. Observer/listener/timer cleanup is covered by lifecycle and interaction tests.
- **Hidden catalogue images are lazy.** Direct editor entry no longer eagerly requests the persistent catalogue covers. Product-set eager declarations fell from **935.55 to 666.88 KiB** (28.7%); workspace declarations fell from **457.47 to 345.89 KiB** (24.4%). These compare the earlier React build, not the original HTML site's runtime.
- **Five identical image copies were removed**, saving **457.47 KiB** (16.9% of the previous image inventory). The remaining **33 assets** are 32 WebP images plus one SVG favicon, totaling **2249.55 KiB**, with no byte-identical duplicates. Shared artwork uses one URL so route changes reuse browser cache entries. The largest image is **188.79 KiB**. Local asset references resolve.
- Images use intrinsic width/height where appropriate or bounded CSS geometry/aspect ratios, with async decoding and native below-fold lazy loading. No remote image optimizer, external font, or image-generation service is required by this export.

## Regression guards and reproduction

`performance-budget.json` sets a **176 KiB maximum modern initial JS** budget, tighter route limits of 144–164 KiB, a **208 KiB individual image** limit, and **704 KiB maximum eager image declarations**. Homepage, workspace and assets have tighter image limits; catalogue covers must remain lazy. Duplicate image copies and missing local resources fail the check. The inline-CSS change adds a **48 KiB gzip initial HTML cap** and **zero initial stylesheet requests** gate. CSS bytes are accounted for in document size instead of disappearing from the budget. These are engineering regression guards with measured headroom, not guarantees of a browser score.

Run:

```sh
npm run verify
# Or inspect an already-built export:
node scripts/analyze-bundle.mjs --check
node scripts/analyze-bundle.mjs --json /path/to/report.json
```

The full verification command includes lint, formatting, type generation/typecheck, model/lifecycle tests, real React DOM interaction tests, production build and bundle budgets. Browser visual and device-performance testing remains a separate acceptance step.
