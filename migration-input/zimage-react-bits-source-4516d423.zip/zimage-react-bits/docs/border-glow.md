# Border Glow removal

Removed on 2026-10-19 at the user's request. The application no longer mounts
BorderGlowController, installs its delegated pointer/focus listeners, or renders
its shared edge overlay. Its component, controller, stylesheet and dedicated
runtime tests have been removed. Commerce catalogue cards use IntentLink directly,
retaining their original destination, intent prefetch, content and local styling.
StarBorder is not restored; its unused historical source and tests remain.

The homepage header, hero and final CTA retain the independent PillNav fill and
rolling labels. Workspace chat components and their selected effects are unchanged.
The no-global-glow regression lives in tests/react-bits-lifecycle.test.mjs.

## Historical provenance

The following records the removed adaptation's source. Its shared license remains
because the selected chat components still use that revision.

## Official source and license

Verified 2026-10-19: [official Border Glow documentation](https://reactbits.dev/components/border-glow).
Source repository revision: `c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a`.

- [TypeScript source](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/ts-default/Components/BorderGlow/BorderGlow.tsx), Git blob `64221706d5c09607f093d84872c4ae8dbd6909d0`.
- [CSS source](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/ts-default/Components/BorderGlow/BorderGlow.css), Git blob `ce36d39479e269a45a61377dd535b1653f1d4749`.
- Copyright (c) 2026 David Haz; **MIT + Commons Clause License Condition v1.0**, not unrestricted MIT.
- [Exact retained license](../licenses/react-bits-chat-LICENSE.md), verified byte-identical to that revision's LICENSE.md (Git blob `4069ce9d0ef1a712c93d6ce48ade5d5667e0f5ee`). Its public distribution copy is `public/licenses/react-bits-chat-LICENSE.md`.
