# Scene navigation audit

## Source findings (2026-10-16)

All internal page links already use Next.js `Link`, and the two imperative
navigation actions use `router.push`. The remaining native anchors are local
skip links and image downloads. There is no application-level full-document
redirect, click timeout, or awaited image decode in the scene-link path.

The catalogue (`CommerceCatalogue`), workspace (`SceneCarousel`), and landing
scene cards (`LandingPage`) explicitly used `prefetch={false}`. The previous
performance test required this behavior. It protected first-load traffic but
also prevented the framework from preparing an editor on hover: an uncached
editor route had to be requested after activation. This is a source-confirmed
avoidable cold-navigation dependency, not a measured attribution of every
reported delay to prefetching.

Ordinary navigation retains default Next prefetching. The persistent create
layout still keeps its catalogue hidden/inert while an editor is open, preserving
card/image identity on return. Carousel drag-click suppression remains intact.
No unrelated layout, upload, draft or simulated-generation behavior was changed.

## Bounded correction

The shared `IntentLink` follows the hover-triggered pattern in the installed
Next **16.3.8** `dist/docs/01-app/02-guides/prefetching.md`:

- Begin with prefetch disabled so merely showing five scene cards does not warm
  five editor routes.
- Restore Next's default prefetching for the intended destination on mouse
  hover, keyboard focus or touch start.
- Delegate request scheduling, cache lifetime and navigation to Next. No custom
  request/cache loop, route enumeration, resource preload or new dependency.
- Preserve the anchor, ref, caller handlers, target/modifier behavior and image
  nodes. Never prevent or delay activation while waiting for prefetch.
- A changed destination requires fresh intent. Cancelled intent does not enable
  prefetch. Repeated intent does not maintain a custom request queue.

Touch offers less lead time than hover; a fast tap or slow connection can still
need to wait for route resources. This change cannot eliminate hosting latency,
initial hydration cost, or all CSS/network/main-thread bottlenecks.

## Verification and limits

`navigation-react.test.tsx` exercises the real wrapper against a small Link-boundary
stub: untouched links stay cold, hover/focus/touch enables only the target, refs
and callbacks survive, DOM identity remains stable, and changed destinations or
cancelled events behave correctly. This proves the wrapper contract, not actual
Next network timing. `performance-budget.test.mjs` protects all three entry points.
The existing workspace/commerce component suites exercise their integration.

For production browser verification, build/export first (prefetch is a production
feature). Test catalogue → each editor → catalogue, landing/workspace scene
entries, and ordinary workspace/assets/account navigation. Compare a fresh
immediate activation with hover/focus-then-activation and a warm return. Observe
RSC/chunk requests before versus after activation, console/network failures,
unchanged document navigation count, preserved catalogue nodes, keyboard
activation, modified/new-tab links and touch activation. Record viewport,
browser, cache/network conditions and actual timings separately; do not present
unit tests, bundle bytes, or this source audit as browser latency measurements.
