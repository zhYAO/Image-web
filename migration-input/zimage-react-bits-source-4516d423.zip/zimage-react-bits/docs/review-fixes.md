# Interaction review fixes

## Source and scope

These changes start from Sites v17 commit `2450e9a5a95639a0f465534c920e27dc6027abd1` for project `appgprj_6ad0906b15f081919cc90064aff8acf5`, at <https://zimage-react-bits-preview.kylethree5.chatgpt.site>. This is the original frontend checkout, not a reconstruction. No production backend, model API, SMS provider, credentials, dependency versions or deployment settings were changed.

## Changes

- **Dialog layout dropdown:** dialog entrance/exit uses opacity only. A retained transform had made viewport-positioned menus relative to the dialog. Active-option scrolling now changes only the menu scrollport, including after its first positioning commit. Existing modal focus lock, Escape handling and body-scroll cleanup remain intact.
- **Composer double-click:** pointer multi-click continuations cannot turn Send into Stop, or Stop into a new send of the next draft. Fresh clicks and keyboard/assistive activation still work immediately, without an arbitrary cooldown timer.
- **Catalogue navigation:** the previously empty `/create/` Page now exposes a nonzero scroll target before the persistent catalogue. Next owns navigation scrolling and browser-history restoration; there is no global scroll-reset effect or remount of cached images.
- **Mobile navigation:** the open homepage panel uses the existing opaque white glass exception, preventing hero text bleed-through.
- **Mobile apparel form:** at 767 px or narrower, the long form uses continuous document flow, with actions after its fields and examples below. Other editors and desktop apparel retain bounded panels.
- **Catalogue descriptions:** mobile tool descriptions have two readable lines instead of one truncated line.
- **A+ settings:** full-width format selection and mode-specific dimensions/ratios replace conflicting generic resolution/help text. Fixed examples are explicitly not output-size evidence.
- **Identity:** phone-code frontend demonstration replaces password collection, with a transport boundary, accessible validation, countdown, duplicate-request protection, abort/stale-result guards and truthful account/legacy-route states. See [phone-login.md](phone-login.md).

## Verification

`npm run verify` passed in the cloud checkout on 2026-10-22:

- ESLint, Prettier and TypeScript.
- 115 unit/contract tests and 100 React interaction tests.
- Production dependency audit: zero vulnerabilities reported.
- Next static export and all existing bundle/image budgets.

Targeted regression tests reproduced failures before fixes, including the dialog containing block, menu-only scrolling, double-click state changes and mobile layout contracts. The original deployed dropdown fault was also reproduced in cloud Chrome: its configured left/top of 293/348 rendered at 564/472 while opening changed dialog scrollTop from 0 to 41. That is baseline evidence, not a post-change browser pass.

### Performance evidence

The same checkout/build analyzer measured initial modern JavaScript (KiB, gzip level 9):

| Route             | v17 baseline | Changed build |
| ----------------- | -----------: | ------------: |
| `/`               |       147.34 |        147.35 |
| `/login/`         |       142.69 |        143.56 |
| `/account/`       |       149.00 |        148.66 |
| `/create/`        |       148.41 |        148.40 |
| `/create/detail/` |       163.34 |        163.51 |
| `/workspace/`     |       158.51 |        158.59 |

These are static file measurements, not network transfer or rendering timings. The earlier online Edge 1440 × 900 FCP runs were 1.364 / 1.340 / 1.452 seconds, using ordinary reload without cleared cache or throttling. No equivalent post-change run has been performed. The 0.8-second goal is not an achieved result.

## Published browser follow-up

After commit `2f0aaac25e6e85d785b39c50adff497606139f47` was published, cloud Chrome at 1180 × 757 verified the phone demo's required-field/invalid-code messages, 60-second resend expiry and truthful single-submit success. It also verified the product-set dropdown's mouse and keyboard selection, menu-only scrolling in a long dialog, nested Escape/focus return, and both A+ modes' updated help. The displayed dropdown aligned at the trigger's x293 and width594 with a 6 px gap; a scrolled dialog stayed at scrollTop95 while End/Home changed only menu scrollTop376/4.

That browser pass exposed two additional native-click edge cases, now corrected with regression coverage:

- A rapid double-click on successful demo verification could clear the code on the first click, then overwrite success with an empty-code error on the second. The form now ignores pointer multi-click continuations, preserving fresh clicks and keyboard activation.
- Stopping while the next draft was queued could submit it even on a single click: React reused the same button and changed its type from button to submit before the browser completed its default action. Stop now cancels the native click default before changing state, in addition to filtering multi-click continuations.

The follow-up passed all release gates with 115 unit/contract and 102 React tests. These last two changes have not been republished or browser-retested. The browser pass was stopped when work moved to migration into the main ZImage repository. Exact 390 × 844 mobile acceptance, browser-history scroll restoration and new FCP measurements remain unverified. No real SMS, credentials, authentication or image generation was used.

## Required post-publication browser acceptance

The cloud browser could not reach the isolated execution environment's localhost preview. This environment limitation is not a code-test failure. Before marking visual/browser acceptance complete, test the actual published URL:

1. Desktop layout dropdown inside the product-set modal: open, keyboard arrows, select, Escape, focus restoration, no enclosing scroll jump.
2. Workspace: double-click Send and Stop, preserve the next draft, then send/stop by keyboard and a fresh click.
3. At 390 × 844, scroll the long chat to the bottom and navigate to `/create/`: heading starts visibly. Scroll the catalogue, open an editor, then Back: history position restores.
4. At 390 × 844, open homepage navigation over its hero: no text bleed-through; Escape/focus behavior remains correct.
5. At 390 × 844, read the apparel form continuously to the final action without a short inner scrollport; check examples and mobile catalogue descriptions.
6. On desktop and mobile, switch both A+ modes: full selector text and correct mode-specific help; fixed previews are not mislabeled as generated output.
7. Phone demonstration: mobile keyboard, autofill/zoom, countdown, invalid code, demo success and legacy-route copy; no SMS/auth network request or authenticated state.
8. Repeat FCP only under recorded comparable conditions, and report results rather than inferring them from bundle sizes.
