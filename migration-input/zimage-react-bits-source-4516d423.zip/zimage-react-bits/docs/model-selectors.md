# Shared model selectors

## Scope and source of truth

The independent preview has one typed registry at `src/lib/model-catalog.ts` with **10 total choices**: six for chat, four for image configuration. These are frontend catalog choices, not connected models. Model selection does not send data, change the deterministic simulated reply, generate an image, create credentials, or configure an API endpoint.

The catalog was checked against the following official documentation on **2026-10-19**. It is a selected current catalog, not a promise that every provider's newest tier is included. ChatGPT's underlying OpenAI model is named as a model rather than treating “ChatGPT” as an API model ID.

| Display name           | Capability | Local ID                  | Official reference                                                                                                             |
| ---------------------- | ---------- | ------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| GPT-6.1 Sol            | Chat       | `gpt-6.1-sol`             | [OpenAI model documentation](https://developers.openai.com/api/docs/models/gpt-6.1-sol)                                        |
| Gemini 4 Argon         | Chat       | `gemini-4-argon`          | [Google model documentation](https://ai.google.dev/gemini-api/docs/models/gemini-4-argon)                                      |
| Qwen3.8-Max            | Chat       | `qwen3.8-max`             | [Alibaba Cloud model documentation](https://help.aliyun.com/en/model-studio/qwen3-8-max)                                       |
| Claude Opus 5.5        | Chat       | `claude-opus-5-5`         | [Anthropic model overview](https://platform.claude.com/docs/en/models/overview)                                                |
| DeepSeek V4.1 Flash    | Chat       | `deepseek-flash`          | [DeepSeek model and pricing documentation](https://api-docs.deepseek.com/quick_start/pricing/)                                 |
| Grok 4.7               | Chat       | `grok-4.7`                | [xAI model documentation](https://docs.x.ai/developers/models/grok-4.7)                                                        |
| GPT-Image-2.5 Sunburst | Image      | `gpt-image-2.5-sunburst`  | [OpenAI model documentation](https://developers.openai.com/api/docs/models/gpt-image-2.5-sunburst)                             |
| Gemini Nano Banana 2.1 | Image      | `gemini-nano-banana-2.1`  | [Google model documentation](https://ai.google.dev/gemini-api/docs/models/gemini-nano-banana-2.1)                              |
| Qwen Image 3.0 Pro     | Image      | `qwen-image-3.0-pro`      | [Alibaba Cloud image model documentation](https://help.aliyun.com/en/model-studio/image-model)                                 |
| Seedream 5.0 Pro       | Image      | `doubao-seedream-5.0-pro` | [BytePlus model release announcements](https://console.byteplus.com/ark/region:ap-southeast-1/docs/model-release-announcement) |

Seedream preserves the previously requested Pro-tier default. The local stable identity `doubao-seedream-5.0-pro` is not claimed to be a regional service endpoint. BytePlus's international Pro release identifier is `dola-seedream-5-0-pro-260628`; this task does not alter any production backend or API configuration. A newer Flash tier does not replace the requested Pro quality default.

## UI and state contracts

- `models/ModelSelector.tsx` wraps the existing local React Bits `GlideSelect`; commerce fields/layouts and asset filters/sorting already use that same component. There are no native `<select>` or parallel listbox implementations in application components.
- Command menus and multi-control generation-parameter popovers are not value dropdowns and retain dialog semantics.
- Each option has a decorative local SVG followed by the readable model name. Provider glyphs in `ProviderIcon.tsx` are small application-drawn identifiers, not downloaded official logo artwork. They need no remote requests or additional package. Seven providers share the same component across both capabilities.
- `textValue` provides plain readable labels for typeahead and accessible trigger names even when the visual label is JSX. Opening a selector resets the search buffer, so a dismissed search cannot contaminate the next attempt.
- Triggers and menus use opaque white with dark text, including when their parent is glass or dark. Rows are 40 px tall. The menu remains viewport-clamped, scrollable and portaled outside clipping containers; inside a native dialog it remains in that dialog's top layer. Escape closes the inner selector first; selection restores the trigger; Tab continues from the trigger's original position.
- The composer stores `chatModel` and `imageModel` independently alongside the existing per-mode drafts in `AppProvider`. Switching modes or remounting the composer within that provider retains both selections. Reload resets this tab-local state. It does not bind a different simulated response or claim that a model was invoked.
- Chat starts with GPT-6.1 Sol. Workspace create-image mode and all five commerce editors start with Seedream 5.0 Pro and offer only image-capable choices.
- Commerce keeps `modelId` in scene-local `EditorState`. Explicit Save draft includes it in the existing scene key. Restore accepts only known image IDs; old drafts without the field, malformed values, retired IDs and chat-only IDs fall back safely. Reference URLs/results/jobs still never restore.
- The model control is disabled during the existing busy state and its open menu closes when disabled. Changing the apparel model invalidates its previously prepared local configuration, as other configuration edits do.
- Local-only notices remain visible in the composer and commerce configuration. Existing simulated-thinking and sample-asset provenance is unchanged.

## Verification coverage and limits

Automated coverage includes the exact catalog count/capability split, safe restoration, no duplicate value-menu implementation, decorative SVG/name ordering, opaque-white popup variables, typeahead and reopen reset, selection, Home/End, Escape, Tab focus handoff without cancelling native traversal, disabled-state dismissal, viewport bounds, dialog placement, independent workspace model choices/input identity, and every commerce scene's selector with explicit product-draft save/restore. Existing simulation, upload, resource-cleanup, image-identity and commerce-interaction tests remain applicable.

jsdom verifies DOM/state behavior and inline theme values, not pixels, touch scrolling, contrast conformance, native Tab progression or actual browser top-layer rendering. Real-browser visual acceptance remains a separate check; do not describe a login-gated page as inspected application UI. No package or lockfile change is needed.
