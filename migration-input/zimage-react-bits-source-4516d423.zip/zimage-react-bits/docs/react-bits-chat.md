# React Bits chat selections

The simulated chat uses **application-scoped adaptations of actual free React Bits source**,
not an npm React Bits package, unchanged upstream APIs, or components merely given its names.
Retrieved from David Haz's official repository on 2026-10-19. All four JSX/CSS pairs
were fetched at commit `c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a`.

## Sources and retained implementation

| Component     | Pinned source                                                                                                                                                 | Retained                                                                                                                          | Scoped changes                                                                                                                                                                                                                                                            |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ThoughtLine   | [JSX](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/content/Micro/ThoughtLine/ThoughtLine.jsx), adjacent CSS      | Collapsible head, chevron rotation, grid-row fold, step mark/pulse, upstream CSS                                                  | Typed step records instead of strings; Lucide replaces Hugeicons; CSS pulse replaces Motion breath; remove elapsed-time measurement, automatic settle/collapse and timer-label layout; user owns expansion; readable descriptions and explicit pending/active/done status |
| LatticeLoader | [JSX](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/content/Micro/LatticeLoader/LatticeLoader.jsx), adjacent CSS  | Exact 3×3 orbit cells, 108ms cell delays, 864ms cycle, layered done/error marks and CSS                                           | Exposes only state/className; no other patterns, timer, labels or configuration; decorative because caller supplies accessible waiting text                                                                                                                               |
| ShinyText     | [JSX](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/content/TextAnimations/ShinyText/ShinyText.jsx), adjacent CSS | Smooth cosine sweep, soft-band geometry, six-point falloff, sorted gradient stops and frame-driven background                     | Single 120° band, 2.2s cycle, no pointer/glow/yoyo modes; CSS color-mix resolves theme tokens instead of upstream canvas color parser and gamma blend; adds live reduced-motion, hidden/offscreen pause; readable solid text fallback                                     |
| TextType      | [JSX](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/content/TextAnimations/TextType/TextType.jsx), adjacent CSS   | Intl.Segmenter graphemes with Array.from fallback, count/slice per-character spans, timeout progression, complete accessible text | Single sentence only, loop=false; removes deletion, typo, reverse, per-character effects, prefix and moving cursor modes; CSS inline cursor replaces GSAP; adds active pause and final onComplete/onTextChange callbacks; reduced motion completes immediately            |

Component pages: [Thought Line](https://reactbits.dev/micro/thought-line),
[Lattice Loader](https://reactbits.dev/micro/lattice-loader),
[Shiny Text](https://reactbits.dev/text-animations/shiny-text),
[Text Type](https://reactbits.dev/text-animations/text-type).

No Motion, GSAP or Hugeicons runtime is added. Existing local FadeContent handles message entry.
The above are deliberately narrower adaptations, not claims of upstream feature parity.

## Integration contract

Named exports come from `src/components/react-bits/chat/index.ts`; each component also
has a default export from its own file. This small local barrel is not a package import.

- ThoughtLine: `working`, `steps: {id,label,description?,status?:'pending'|'active'|'done'}[]`,
  `title`, `defaultExpanded`, `className`. Expansion is keyboard-operable and remains user-controlled.
- LatticeLoader: `state: 'working'|'done'|'error'`, `className`. Caller supplies status text.
- ShinyText: `text`, `disabled`, `className`.
- TextType: immutable `text` per mounted answer, `typingSpeed` in ms (default 28),
  `loop?: false`, `active` (default true), `onTextChange`, `onComplete`, `className`.
  Key by message ID for a new answer. `active=false` freezes the current partial;
  unmount cancels the timeout. Callbacks are kept current without replaying the sequence.
  Completion fires once after the final character, including the reduced-motion path.
  Save the latest onTextChange value when stopping; completed answers render plain text.

`motion.ts` owns and cleans document visibility/media-query/intersection listeners.
All effects pause hidden/offscreen; reduced motion removes nonessential animation and
shows TextType's full answer. Missing media APIs select the static path. Theme colors
use `--text`, `--muted` and `--primary`, with forced-colors fallbacks. Existing Glass
is the only surface material; these components do not introduce another glass recipe.
No model calls or actual model reasoning are represented by the demo steps.

## License

Copyright (c) 2026 David Haz. **MIT + Commons Clause License Condition v1.0**, not
unrestricted MIT. Exact license at this pinned revision is retained in
[licenses/react-bits-chat-LICENSE.md](../licenses/react-bits-chat-LICENSE.md) and
`public/licenses/react-bits-chat-LICENSE.md` for exported distributions. Its text has
changed since the earlier selections, so their existing license file is preserved.
Application use is allowed; selling or redistributing these components as standalone
components, a library, a bundle or a port is restricted. No React Bits Pro content is used.

## Verification limits

Focused React tests cover expansion, grapheme typing, stop/hidden/reduced-motion behavior,
completion and cleanup. CSS/source checks cover the preserved orbit/falloff and static
fallbacks. These are not browser screenshot, contrast-measurement or frame-rate evidence.
