# Sidebar GooeyNav category indicator

Reviewed 2026-10-19. This is a selected geometry adaptation of official
[React Bits GooeyNav](https://reactbits.dev/components/gooey-nav), pinned to
[`c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a`](https://github.com/DavidHDev/react-bits/commit/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a).

## Source and attribution

- [Official TSX](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/ts-default/Components/GooeyNav/GooeyNav.tsx)
- [Official CSS](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/src/ts-default/Components/GooeyNav/GooeyNav.css)
- [Official license](https://github.com/DavidHDev/react-bits/blob/c2a1408d9219a5bd7a2d9c93c9c499042f5fa34a/LICENSE.md)

Copyright 2026 David Haz, MIT + Commons Clause (not unrestricted MIT).
The full unchanged license is retained at `licenses/gooey-nav-LICENSE.md`
and exported at `public/licenses/gooey-nav-LICENSE.md`, with the accompanying
`gooey-nav-NOTICE.txt`. This is an application adaptation, not a standalone
component distribution.

## Scope

`CategoryFilters.tsx` adapts the upstream `measure()` approach: measure the
selected button relative to its stage and track its width and height. The
upstream WebGL/particle pipeline, SVG tracing, morphing, text effects, routes,
and full navigation API are intentionally absent. It is not a drop-in copy of
GooeyNav. The existing three native `aria-pressed` action buttons remain.

One pointer-transparent, aria-hidden span slides behind stationary labels in
200 ms using CSS transitions; new clicks retarget the current transition without
queues or completion callbacks. Existing `--soft` violet material and `--primary`
text preserve the compact sidebar palette; no new glass engine or dependencies.
Server HTML retains a selected button background. Only after valid synchronous
layout measurement does the indicator replace that fallback, avoiding an entry
slide from zero or an invisible initial selection. Invalid/hidden bounds restore
the fallback. Resize corrections are immediate. One ResizeObserver watches the
group and three buttons, with a window resize fallback; cleanup disconnects the
observer and removes the listener. No timers, RAF loop or state-per-frame updates.

Reduced motion removes the transition, including live preference changes.
Forced colors hides the indicator and outlines the selected native button.
Collapse/mobile control ownership and compact filter popover stay in
WorkspaceShell. Existing category filtering/counts remain; rows now keep stable
ID-keyed DOM and use `hidden` with explicit display:none. The scroll host stays
mounted, with no list fade, reload or reset. Browsers may naturally clamp scroll
position when the filtered content becomes shorter.

## Verification boundaries

React tests check target bounds, repeated selection, resizing, observer cleanup,
pressed buttons, no filter navigation, stable row identity and stable scroll host.
SSR/CSS checks cover visible selected fallback, decorative semantics, the 200 ms
transition, reduced motion and forced colors. jsdom does not prove pixel layout,
actual CSS interpolation, Safari, touch or OS preference rendering. Browser QA
must be reported separately when performed. Run the full `npm run verify` gate
before publication, including production audit, static export and bundle budget.
