import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  output: 'export',
  trailingSlash: true,
  images: { unoptimized: true },
  poweredByHeader: false,
  reactStrictMode: true,
  // Static first visits receive styles with HTML, avoiding blocking CSS requests.
  experimental: { inlineCss: true },
};

export default nextConfig;
