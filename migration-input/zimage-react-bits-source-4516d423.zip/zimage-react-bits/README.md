# ZImage independent React preview

A new, isolated React application using the same frontend framework family as the real ZImage source snapshot: Next.js 16.3.x, React/ReactDOM 19.2.7 and TypeScript 6.0.3. This application pins Next.js 16.3.8 rather than the snapshot’s 16.3.0 to include published security fixes. The original HTML prototype and existing published site are untouched.

## Run

```sh
npm ci
npm run dev
```

## Validate and export

```sh
npm run verify
npm run preview
```

The build produces static HTML, route payloads, CSS and JavaScript in `out/`. The exported files can run on a static host without a Node server. Paths use trailing slashes so each route has its own `index.html`. Only `out/` is deployable; source, tests, local documentation, node_modules and build caches are not published.

## Architecture

- Next App Router pages are actual React components, not embedded legacy HTML.
- `/` is the brand homepage. `/workspace/` is the only shared chat/image workspace.
- `/create/` contains the catalogue with five scene editors: product-set, detail, clone, product-main and apparel-catalog.
- `/assets/`, `/login/` and `/account/` are independent frontend demonstration routes.
- `AppProvider` maintains synthetic sessions, independent chat/image drafts, shared workspace reference images and status messages. Provider state is transient and stays in this browser tab. Only explicitly saved commerce settings persist in validated browser localStorage; credentials, uploaded files and object URLs are not persisted.
- Images copied into `public/assets` are the existing local sample assets. Uploaded reference images remain local object URLs and are never sent to a server.
- Free React Bits components are selected and vendored individually with provenance; there is no entire-library import. Heavy and secondary UI is deferred at its usage boundary.
- Shared liquid-glass treatment is centralized. Reduced-motion, transparency and contrast preferences have fallbacks.

## Safety and scope

No real authentication, model generation, payment, analytics, Supabase, or external upload is implemented. The phone-code login uses a local demonstration code and never sends SMS or creates a session. Do not enter real verification codes. Legacy password/recovery screens do not collect credentials. Generated-result displays are examples. No API keys or production configuration are needed.

## Verification boundary

Unit tests and the production export verify local behavior, type contracts, route generation and packaging. They do not establish browser rendering, Safari behavior, mobile touch interactions, animation smoothness, or production backend readiness. Visual acceptance is a separate check.

## Read before changing code

- [AGENTS.md](AGENTS.md): working contract, architecture, focused reading paths and verification commands.
- [DESIGN.md](DESIGN.md): visual tokens, responsive behavior, shared components, motion and accessibility.
- [React Bits selection](docs/react-bits-selection.md): exact source revisions, component APIs, adaptations and licensing.
- [Phone login integration](docs/phone-login.md): demo behavior, typed adapter boundary and real-service requirements.
- [Performance review](docs/performance-review.md): measured build sizes, deferred chunks, budgets and unmeasured browser checks.

Run `npm run format` after changes and `npm run verify` before delivery. `npm run typecheck` generates Next route types on a clean checkout before checking TypeScript. The lint toolchain compatibility pin is documented in AGENTS.md.
