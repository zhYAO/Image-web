import { defineConfig, globalIgnores } from 'eslint/config';
import nextVitals from 'eslint-config-next/core-web-vitals';
import nextTypescript from 'eslint-config-next/typescript';

export default defineConfig([
  ...nextVitals,
  ...nextTypescript,
  globalIgnores(['.next/**', 'out/**', 'node_modules/**', 'next-env.d.ts']),
  {
    files: ['src/**/*.tsx'],
    rules: {
      // Static export serves precompressed local WebP artwork. Every image has
      // declared dimensions/loading rules; no image optimizer service is used.
      '@next/next/no-img-element': 'off',
    },
  },
  { files: ['tests/**', 'scripts/**'], rules: { '@typescript-eslint/no-explicit-any': 'off' } },
]);
