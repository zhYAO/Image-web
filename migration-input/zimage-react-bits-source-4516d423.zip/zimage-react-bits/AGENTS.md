# Working on the independent ZImage React preview

This file is the operating guide for agents changing **this application**. Read the relevant section before editing; use [DESIGN.md](DESIGN.md) for visual decisions and [README.md](README.md) for the short run guide.

## Start here: read only what the change needs

- **Every task:** read §1 (scope), inspect the current files, and finish with §7–8 (verification/delivery).
- **Layout or styling:** open the relevant feature CSS and [DESIGN.md](DESIGN.md); shared paint belongs to Glass, not a new recipe.
- **State or interactions:** use §3–5; provider ownership, stable nodes and cleanup are deliberate contracts.
- **Ordinary React Bits usage:** the table below and §6 are enough; no need to reread the canvas algorithm. Read source for internals, a bug, a new unsupported option or an upstream update.

| Need                       | Existing component                              | First facts to remember                                                                              |
| -------------------------- | ----------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| Shared translucent surface | `@/components/Glass` → named `Glass`            | Geometry stays local; `refract` defaults false; CSS fallback always works                            |
| Value dropdown             | `@/components/react-bits/GlideSelect` → default | Controlled `value`/`onChange`; `popDuration`/`glideDuration` in milliseconds; portal is dialog-aware |
| Workspace idle orbs        | `@/components/workspace/ComposerOrbs`           | Three CSS light spots; 28% opacity, fixed blur; focus pauses/fades; no canvas or added dependencies  |
| Immediate small reveal     | `@/components/react-bits/FadeContent` → default | Visible server HTML; `duration`/`delay` in **milliseconds**; no GSAP                                 |
| Landing section reveal     | `@/components/landing/Reveal` → named           | Stable host/children; defers only named `FadeContentEffect`, which renders `null`                    |

## Contents

1. [Scope and sources of truth](#1-scope-and-sources-of-truth)
2. [Toolchain and commands](#2-toolchain-and-commands)
3. [Architecture and ownership](#3-architecture-and-ownership)
4. [State, persistence, and resource ownership](#4-state-persistence-and-resource-ownership)
5. [React implementation rules](#5-react-implementation-rules)
6. [Shared material and React Bits quick reference](#6-shared-material-and-react-bits-quick-reference)
7. [Verification and acceptance](#7-verification-and-acceptance)
8. [Failure recovery, Git, and publication](#8-failure-recovery-git-and-publication)

## 1. Scope and sources of truth

### What this project is

`zimage-react-preview/` is an independent, frontend-only Next.js/React implementation of the ZImage preview. The homepage, workspace, scene editors, asset library, and account flows are real React components and routes. They are **not** an iframe, embedded HTML application, or `dangerouslySetInnerHTML` wrapper.

The existing HTML prototype, including sibling `zimage-home-preview/`, reference snapshots, the real ZImage product repository, and existing published site are outside this project's edit scope. Read supplied references when relevant; do not modify, regenerate, overwrite, or republish them. A request to improve this preview does not authorize changes to the product backend or old preview.

### What is intentionally absent

- No live model calls, conversation service, image generation, authentication, email delivery, billing, analytics, Supabase, external image import, or external upload.
- The workspace chat has an explicitly approved local simulation (2026-10-19): deterministic preset replies and clearly labeled mock thinking steps, never a real model call or real model reasoning. Preserve the visible simulation provenance. Image mode still records the user message and reports image generation unavailable; do not invent generated images.
- Commerce progress/results use local example assets. Keep the example designation and truthful unavailable states; animations are not evidence of a completed backend job.
- Account balances remain unavailable instead of fabricated. Registration stays closed while the terms/privacy pages are explicitly unapproved drafts.
- Credentials and production configuration are unnecessary. Never test with real passwords or add keys, tokens, payment details, or a service connection to make a demonstration look complete.

Adding any of these real services is a separate, explicitly scoped project. Do not add features, routes, packages, persistence, or integrations simply to make the preview appear more complete.

### Evidence order

1. Current user-approved requirements and reference material define the requested behavior.
2. Current source and tests establish what this checkout actually implements.
3. Version-matched installed framework documentation establishes API behavior.
4. These guides explain the architecture and intended invariants; update them when an authorized change alters those invariants.

The original HTML and supplied OpenDesign clone are visual/interaction references, not runtime dependencies. Port the intended geometry and behavior into the existing React architecture. Screenshots, comments, old build output, and previous test counts do not prove that the current code passes. Report any mismatch explicitly rather than silently picking a convenient source.

## 2. Toolchain and commands

### Pinned versions

| Item                               | Version / contract                                              |
| ---------------------------------- | --------------------------------------------------------------- |
| Node.js                            | 24.x; validated toolchain 24.19.0; repository engine `>=24 <25` |
| npm                                | Validated with 11.9.0; use `package-lock.json` and `npm ci`     |
| Next.js                            | `16.3.8`                                                        |
| React / React DOM                  | `19.2.7` / `19.2.7`                                             |
| TypeScript                         | `6.0.3`, strict mode                                            |
| Lucide React                       | `1.31.0`, named icon imports only                               |
| ESLint / Next ESLint config        | `9.39.5` / `16.3.8`                                             |
| Prettier                           | `3.9.10`                                                        |
| React Testing Library / user-event | `16.3.2` / `14.6.1`                                             |
| jsdom / tsx                        | `27.0.0` / `4.23.15`                                            |

`package.json` and `package-lock.json` are authoritative if an approved dependency update changes this table. Node 24 is the **project test-toolchain choice**, not a claim that Next requires Node 24. Do not upgrade the framework to resolve an unfamiliar API or install a second animation framework for one effect.

ESLint 9.39.5 is a deliberate development-tool compatibility pin: ESLint 10.12 with the original Next 16.3.0 bundled React plugin failed on `contextOrFilename.getFilename`. npm marks the 9.x version unsupported. Treat this as tooling maintenance debt; upgrade ESLint/config/plugins together with a verified lint run, rather than silently switching majors. It is not a browser runtime dependency.

### Reference versions versus security patches

The supplied real-ZImage source snapshot uses **Next.js 16.3.0**. This independent preview deliberately uses **Next.js and eslint-config-next 16.3.8**, a same-16.3-family security patch. React/React DOM 19.2.7 and TypeScript 6.0.3 remain aligned with the reference. Do not describe the full framework set as identical to the old source, or downgrade Next to recover literal version matching. The reference and original HTML preview remain untouched.

The patch addresses advisories affecting the older package, including [Node.js next/og ImageResponse RCE, patched in 16.3.6](https://github.com/advisories/GHSA-vcvr-r3jv-pc5j) and [image-optimization SSRF, patched in 16.3.8](https://github.com/advisories/GHSA-cjq9-62q9-8jv4). This application's exported site serves static files, has no `next/og` image-generation route, and uses unoptimized local images without `images.remotePatterns`; it does not expose those request-time server paths. That narrower deployed surface is not a reason to retain the vulnerable dependency in source used for development or future changes.

### Run from this directory

```sh
node --version
npm --version
npm ci
npm run dev
```

The development server binds to `127.0.0.1`. Do not run development and production builds concurrently against the same `.next/` directory.

```sh
npm run lint
npm run format:check
npm run typecheck
npm test
npm run test:react
npm run audit:prod
npm run build
npm run analyze
# Aggregate gate, including the network-dependent production audit:
npm run verify
```

- `lint`: ESLint, including Next/React rules. Explain a narrowly scoped suppression; do not disable rules project-wide to hide a problem.
- `format:check`: Prettier verification. `npm run format` applies formatting; coordinate before a whole-tree format when others are editing.
- `typecheck`: `next typegen && tsc --noEmit`; generates route types and ignored `next-env.d.ts` on a clean checkout before TypeScript checking. It does not test browser behavior.
- `test`: Node `.mjs` unit, source-contract, geometry, resource-lifecycle, and packaging tests through `node --import tsx --test tests/*.test.mjs`. The loader resolves shared TypeScript modules and extensionless imports.
- `test:react`: actual React components in jsdom through `tsx` and `tests/register-css.mjs`. CSS is stubbed by that loader, so this suite cannot verify pixel layout.
- `build`: production static export to `out/`.
- `analyze`: `scripts/analyze-bundle.mjs --check` against the **latest** `out/` and `performance-budget.json`. Build first.
- `audit:prod`: `npm audit --omit=dev --audit-level=high`; requires registry/network access. The final `verify` command includes this release gate. A failed or unavailable audit blocks release, while local unit/component checks can still run independently.
- `preview`: `python3` serves `out/` on `127.0.0.1:3000`; it serves the last build, not current source automatically.

For a readable export inventory without changing the budget:

```sh
node scripts/analyze-bundle.mjs
node scripts/analyze-bundle.mjs --json /tmp/zimage-bundle-report.json
```

### Dependency security before publication

Run `npm run audit:prod` against the final installed lockfile before publishing, and again after dependency changes. This is `npm audit --omit=dev --audit-level=high` and is included before the production build in `npm run verify`; `npm audit --omit=dev` is also useful for the full production-dependency report. The script fails at high/critical severity, but review all reported findings and their actual applicability/affected/fixed ranges. Record the result rather than claiming the static export is universally unaffected. The audit requires registry/network access: a blocked audit is **not run successfully**, not a clean result, and release remains blocked until it can be checked. Offline unit/component tests remain independently runnable.

For a relevant finding, prefer a tested compatible patch and update the package/lockfile together. Rerun lint, type generation/checks, tests, build and bundle analysis after the change. Do not use `npm audit fix --force`, suppress findings, or preserve known vulnerable versions merely to match a reference snapshot. Review development-tool findings separately when assessing the tooling environment; `--omit=dev` does not certify those dependencies. An audit is a point-in-time dependency check, not proof that the whole application is secure.

### Known development-tool advisory

As of the **2026-10-15** dependency review, the production-only audit reported **0 vulnerabilities**, while full `npm audit` reported **5 high-severity package entries** from one unresolved advisory propagated through the development-tool chain: `eslint-config-next` → `@next/eslint-plugin-next` → `fast-glob` → `micromatch` → `braces`.

The lockfile contains development-only `braces@3.0.3`. [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm) affects `braces <=3.0.3`, describes stack-exhaustion denial of service from deeply nested brace patterns, and lists **no patched version** at this review. These packages are development tooling, not runtime dependencies shipped as part of the static application. Do not describe the full audit as clean or present the production-only result as covering them.

Keep lint/glob patterns developer-controlled; do not pass untrusted user, remote or generated pattern inputs into this tooling. Revisit the advisory and upstream Next/ESLint dependency updates when a fix is available. Do not force incompatible overrides or claim that excluding development dependencies fixes the advisory. Preserve the production audit release gate and disclose this separate tooling risk until a verified compatible fix lands.

### Next.js rules for this version

Read the relevant guide in `node_modules/next/dist/docs/01-app/` before changing Next APIs. Useful starting files:

- `01-getting-started/05-server-and-client-components.md`
- `02-guides/static-exports.md`
- `02-guides/lazy-loading.md`
- `03-api-reference/03-file-conventions/dynamic-routes.md`

The installed Next `AGENTS.md` explicitly warns against relying on older API knowledge. This is App Router with `output: 'export'`, `trailingSlash: true`, `images.unoptimized: true`, and React Strict Mode. Server Components execute at build time; client components are also prerendered. No request-time server feature belongs here. Dynamic scenes use promise-based `params`, `generateStaticParams()`, `dynamicParams = false`, and `notFound()` for unknown IDs. Do not restore obsolete `next export` workflows or assume a live image optimizer.

## 3. Architecture and ownership

| Area                      | Owner files                                                                              | Responsibility                                                                                                                   |
| ------------------------- | ---------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| App composition           | `src/app/layout.tsx`, route `page.tsx` files                                             | Metadata, language, viewport, shared provider, thin server route entry points                                                    |
| Brand homepage            | `src/components/landing/`                                                                | Server-composed `LandingPage`; small client islands for nav, gallery, reel, FAQ and reveals; `motion.ts` holds testable geometry |
| Shared workspace shell    | `src/components/workspace/WorkspaceShell.tsx`, `workspace.module.css`                    | Sidebar, synthetic sessions, compact/mobile navigation, topbar, popovers; **does not** inject a composer on other routes         |
| Workspace interaction     | `WorkspacePage.tsx`, `WorkspaceComposer.tsx`, `SceneCarousel.tsx`                        | One shared chat/image workspace, timeline, composer, references, carousel                                                        |
| Shared tab state          | `src/components/AppProvider.tsx`                                                         | Independent composer/session/notification subscriptions and workspace reference URL ownership                                    |
| Commerce catalogue/layout | `CommerceLayout.tsx`, `CommerceCatalogue.tsx`                                            | Persistent create layout, hidden/inert catalogue cache, five semantic scene links                                                |
| Commerce editor           | `CommerceEditor.tsx`, `CommerceControls.tsx`, `commerce-state.ts`                        | Scene-local draft, upload validation, configuration, simulated progress/results, accessible controls                             |
| Commerce imagery          | `CommerceImage.tsx`, `CommerceExamples.tsx`, `CommerceResults.tsx`, `CommerceDialog.tsx` | Asset resolution, full-image fitting, results, individual regeneration and image dialogs                                         |
| Asset library             | `src/components/assets/`                                                                 | Curated data, filtering, favorites, selection, collection membership/undo, stable image nodes, deferred dialog content           |
| Identity/account          | `src/components/identity/`                                                               | Demo forms, validation, fullscreen auth, unavailable account data, ledger display, unapproved legal drafts                       |
| Shared material           | `Glass.tsx` → `react-bits/GlassSurface.tsx`, `liquid-glass.css`, `GlassSurfaceEffect.js` | Semantic wrapper, one material recipe, optional static refraction enhancement                                                    |
| Selected effects          | `src/components/react-bits/`                                                             | Local StarBorder/FadeContent and selected chat adaptations                                                                       |
| Data and limits           | `src/lib/demo-data.ts`, `preview-types.ts`, `reference-validation.ts`                    | Fixture data, workspace contracts, shared workspace upload limits                                                                |
| Hydration guard           | `src/lib/useHydrated.ts`                                                                 | Server-false/client-true external-store snapshot for interactive-only credential controls                                        |
| Verification              | `tests/`, `scripts/analyze-bundle.mjs`                                                   | Unit/component evidence and measured export-size checks                                                                          |

Scroll contract: preserve the original HTML natural document scroll on workspace/catalogue/assets/account so content passes behind the sticky glass topbar. Do not constrain all pages below navigation. Commerce editor panels remain independently bounded, except the long apparel form at ≤767 px: it uses continuous document flow with actions after the fields. The cached catalogue has a nonempty 1 px Page anchor before it so Next can apply forward-navigation scrolling without a global scroll reset or overriding Back/Forward restoration.

Canonical brand SVG lives in `src/components/BrandMark.tsx`; the landing/workspace mark files are compatibility re-exports. Do not duplicate or redesign the mark for assets or new workbench routes.

Feature-specific CSS stays beside its feature: `.zl-*` landing, `.cm-*` commerce, `.za-*` assets, `.zi-*` identity, and the workspace CSS module. `globals.css` owns global tokens, reset, focus defaults and toast placement. Do not solve a local spacing issue with an unscoped global selector.

The scene catalogue exists in `commerce-data.ts`; landing/workspace summaries also exist in `src/lib/demo-data.ts`. If changing a scene's identity or destination, check both sources and the exported route list. Do not add a sixth scene accidentally through only one array.

## 4. State, persistence, and resource ownership

### Choose the narrow provider hook

| Hook                   | Use for                                                                                          |
| ---------------------- | ------------------------------------------------------------------------------------------------ |
| `usePreviewComposer()` | `mode`, independent `chatDraft` / `imageDraft`, references and their add/remove/clear operations |
| `usePreviewSessions()` | Sessions, active session ID, selection, create/rename/delete, append/update-message operations   |
| `usePreviewNotify()`   | A stable `notify(message)` function; no composer/session subscription                            |
| `usePreview()`         | Existing compatibility use only; new code should pick the narrow hook(s) it needs                |

Typing should not rerender the sidebar or notification-only controls. The split contexts and memoized values enforce that boundary. Do not replace them with a single global context or store unrelated scene forms in `AppProvider`.

- Chat and image drafts are independent. Their typed model selections (`chatModel` / `imageModel`) also live in the composer provider and survive mode switches/route remounts for this browser tab. Switching modes hides reference controls in chat but must retain the same reference objects/URLs. Choices only configure the local demonstration, never dispatch model calls.
- The composer is one stable mounted form across first-send and session transitions. Only the welcome/timeline area changes.
- The first user message must be appended to the ID returned by `createSession()`, not a stale `activeSessionId` closure.
- Session updates are immutable. IDs are stable; rename trims and caps titles at 80 characters. Toast announcements expire after 4,500 ms and are explicitly dismissible.

### Approved simulated chat lifecycle

`useSimulatedChat.ts` owns one active local demonstration: idle → thinking → typing → done/stopped. Three preset steps advance on owned timers; `TextType` reveals the deterministic answer and reports partial text through a ref, without rerendering provider subscribers for every character. Completion stores full text; stop, session switch, active-session deletion and workspace unmount preserve partial text as stopped and cancel pending work. Reopening a finished or stopped answer renders plain stored text and never replays typing. A synchronous active-run guard prevents duplicate submissions. The composer also ignores pointer multi-click continuations on the newly switched stop button, while fresh clicks and keyboard/assistive activations can still stop immediately. Keep image-mode service-unavailable behavior and independent drafts/uploads unchanged.

ThoughtLine, LatticeLoader, ShinyText and TextType live in `react-bits/chat/`; provenance and adapter details are in `docs/react-bits-chat.md`. Thinking steps are explicitly simulated UI data, never a claimed model reasoning transcript. The timeline disables automatic live announcements; a separate polite status announces phase changes only. Document-scroll following pauses when the user reads above; a new submission resumes following. No backend, persistence or generated-image success is implied.

### Uploaded files are local resources

Workspace `AppProvider` owns the URLs it creates. `reference-validation.ts` limits workspace references to four nonempty PNG/JPEG/WebP files, each at most `10 * 1024 * 1024` bytes. Removal, clear, and provider unmount revoke the owned URLs exactly once. A consumer can display a URL but must not independently revoke it. Clear the file input value after processing so the same file can be picked again.

Commerce has **separate** scene/role-aware upload contracts and URL ownership in `CommerceEditor`; do not apply the four-file workspace limit there. `commerce-state.ts` defines each role's capacity, duplicate detection, MIME and size rules. Apparel requires five 3:4 JPEG main images, display photos, a PNG logo, and required fields. Aspect-ratio validation accepts a difference from `0.75` no greater than `0.015`. Changing these rules requires tests and copy updates.

Commerce queues file decoding, tracks created URLs, and clears timers/resources on teardown. On a failed batch, release new URLs and preserve existing valid references. A completed image decode or timeout must not update an unmounted editor. Image measurements belong in the image/fit components, not repeated render-time DOM queries.

### What persists

- Provider sessions, drafts, and reference objects are in-memory browser-tab state; reload is not a saved conversation feature.
- Sidebar collapse preference uses `zimage-sidebar-collapsed` in `localStorage`.
- An explicit commerce **Save draft** writes `zimage-commerce-draft:<scene-id>`. `draftConfiguration()` keeps the selected image `modelId` and strips references, results, progress/error/loading and other runtime-only state. `restoreDraftConfiguration()` accepts only current image-capable IDs, falling back to Seedream 5.0 Pro for old, unknown, malformed or chat-only IDs. Restoring a draft must never resurrect a `blob:` URL or in-progress job.
- Asset favorites/selections/collections and account display-name edits are local component state for the current visit; there is no server persistence.

Auth has an intentional reset boundary: leaving login unmounts `PhoneLoginForm`, clearing phone/code/challenge/feedback and aborting active work. It owns local +86 phone validation, a six-digit demonstration code, a wall-clock resend deadline and synchronous duplicate-request guards. A changed phone invalidates the old challenge; abort and request identity checks ignore stale responses. `phone-auth.ts` defines the typed request/verify boundary and a network-free demo adapter. It never returns a real session or token. See [phone login integration](docs/phone-login.md). Within a mode, validation retains input identity. Legacy recovery/verification/reset routes show unavailable information rather than collecting old credentials; account security links to the phone flow.

`src/lib/useHydrated.ts` uses `useSyncExternalStore` with server snapshot `false`, client snapshot `true` and a no-op subscription. Phone/code fields and submits stay disabled in server HTML until React handlers activate. Account no longer asks for a password. With JavaScript unavailable they remain disabled. `method="post"` is a secondary URL-leak defense, not a backend endpoint. Keep these guards when refactoring demo forms; hydrated actions remain local and report unavailability.

Storage access can fail or contain malformed JSON. Keep the page usable and show existing failure feedback where relevant. Do not silently add autosave, cross-tab syncing, browser credential storage, or persistent uploads.

## 5. React implementation rules

1. **Keep server/client boundaries small.** Route wrappers and static content remain server-rendered. State, effects, handlers and browser APIs live in client components. Pass rendered server children through a client wrapper instead of importing the entire page into that client boundary.
2. **Use the existing component before cloning it.** Shared shell, `Glass`, `SceneImage`, `AssetImage`, commerce `Select`/`Segments`/`TextField`/`UploadGroup`, and image dialogs already encode behavior. `ImagePreviewDialog` is the single full-image modal shared across commerce, assets and workspace; keep optional metadata at the call site and retain `imageOnly` for assets. Extract a focused common component only when responsibilities really match; do not build a speculative generic UI framework.
3. **Preserve identity.** Stable item IDs are keys. Do not key a card/form/gallery by search text, favorites, prompt value or ordinary display mode; the explicitly scoped auth credential reset above is intentional. Asset filters hide existing cards and sorting moves the same keyed nodes. Commerce retains its catalogue under the create layout with `hidden` and `inert` rather than recreating it on return.
4. **Keep state at its owner.** Derive filtered/count/selected views instead of copying them into effects. Use functional updates when deriving from current state. Existing memoized image/example components protect decoded image DOM; preserve this behavior and test it before changing memoization boundaries.
5. **Use effects for external synchronization.** Every listener, observer, timer, Web Animation, RAF chain, object URL and temporary style has a cleanup owner. Effects must survive Strict Mode setup/cleanup. Avoid a state update on every animation frame; use bounded DOM styles/refs where the existing motion controllers do. Keep render pure: commit changes to an animation controller's latest-settings ref in an effect, as StarBorder does, rather than mutating it during render.
6. **Defer optional UI, not essential content.** Module-scope `lazy`/`dynamic` declarations plus conditional rendering defer commerce results/dialogs, asset dialog content and the reference viewer. An unconditional dynamic component can still load immediately. Never erase first-render content with a loading placeholder solely to add animation.
7. **Keep interactions semantic.** Use `Link`/anchors for navigation, buttons for actions, labels for fields, `aria-pressed` for toggles, native dialogs for modal flows, and live regions for errors/status. Preserve Escape/outside-click behavior and trigger focus restoration. Avoid nested interactive elements inside a linked card.
   Scene-card navigation in the landing page, workspace carousel and commerce catalogue uses `IntentLink`. It starts with `prefetch={false}` and restores Next defaults only for the hovered/focused/touched destination. Preserve link refs and caller events; never wait for prefetch inside a click handler or eagerly preload every editor. Ordinary navigation links retain framework defaults.
8. **Keep text entry correct.** Workspace Enter sends only outside IME composition; Shift+Enter adds a newline. Preserve `isComposing` and key-code 229 guards. Focus uses fill/caret cues for inputs, with accessible forced-colors treatment; do not remove all keyboard indication.
9. **Optimize from evidence.** Use named Lucide imports, local effect imports, no global animation runtime. Compare the production analyzer before/after a bundle-sensitive change. Do not increase the budget to conceal a regression.
10. **Write for the next maintainer.** Clear component/function names, ordinary formatted TSX, small testable helpers and comments explaining constraints. Do not compress unrelated handlers into unreadable one-liners or add a comment that contradicts actual behavior.

## 6. Shared material and React Bits quick reference

This section is sufficient for ordinary usage changes. Read the implementation when changing effect internals, diagnosing a lifecycle/rendering bug, adding an unsupported option, or updating upstream code. Do not repeatedly audit the full canvas algorithm just to change card copy.

### Glass

```tsx
import { Glass } from '@/components/Glass';

<Glass as="section" className="feature-panel" aria-labelledby="feature-title">
  <h2 id="feature-title">Panel title</h2>
</Glass>;
```

`as` defaults to `div`; ordinary element props and an element ref are forwarded. `refract` defaults to `false`. Geometry (padding, radius, sizing, layout) belongs to the feature; material paint belongs to `liquid-glass.css`. The wrapper owns `data-liquid-glass` from its `refract` prop; passing `data-liquid-glass="off"` to `Glass` does not override that. Use `className="surface-white"` for a white wrapper exception; the raw `off` selector is for explicitly marked DOM surfaces. `refract` dynamically imports the engine in an effect and safely keeps CSS-only glass if it fails. Opt in sparingly on the existing navigation/topbar surfaces; do not add refraction to every thumbnail. The React Bits `GlassSurfaceEffect.js` controller retains the official SVG map/channel pipeline with shared, debounced resource ownership. It is static RGB backdrop refraction, **not** a per-frame animation. `Glass` re-exports the semantic `react-bits/GlassSurface` host. All surfaces use its frosted Bits paint; opt-in refraction adds no extra content wrapper.

[DESIGN.md](DESIGN.md#3-shared-liquid-glass) specifies the React Bits frosted material with app-specific 28%/40% tint, scoped light theme, white exceptions and fallbacks. Keep source/license notices when adapting material or effects.

### Exact React Bits imports

```tsx
import StarBorder from '@/components/react-bits/StarBorder';
import FadeContent, { FadeContentEffect } from '@/components/react-bits/FadeContent';
import GlideSelect from '@/components/react-bits/GlideSelect';
```

There is no `react-bits` package or barrel import. These are selected free-source adaptations under **MIT + Commons Clause**, not unrestricted MIT-only assets. Provenance, pinned upstream commit, license, API differences and modification history are in [docs/react-bits-selection.md](docs/react-bits-selection.md) and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). Keep `licenses/` and the identical exported notices under `public/licenses/` intact. Do not distribute the components as a separate library/pack or add Pro content.

### Value menus and model choices

All value-selection dropdowns reuse `react-bits/GlideSelect`: commerce fields/layouts,
asset filters/sorting and the workspace/commerce model selector. Command popovers and
multi-control parameter dialogs retain their own semantics. The shared model wrapper is
`models/ModelSelector.tsx`; `src/lib/model-catalog.ts` is the single typed 10-model registry
(6 chat, 4 image). See [model catalog and official references](docs/model-selectors.md).
Use `textValue` with rich option labels so accessible names/typeahead read the model name,
not its internal ID. Opening resets the typeahead buffer; values remain controlled.

Model rows contain a local decorative provider SVG then the model name, with the standard
selected check. Model controls and portaled menus are opaque white with dark text, even
inside a glass/dark surface. Do not add Glass, blur, remote icon URLs, provider packages or
an API call to this selector. Menus remain bounded and scrollable, portaling to the enclosing
native dialog when present. Active-option reveal adjusts only the menu scroll offset, never ancestor `scrollIntoView`; commerce dialogs use opacity-only transitions so viewport-fixed portal coordinates do not inherit a transformed containing block. The workspace uses only the relevant capability for its current
mode; all five commerce scenes use image models. Keep visible local-only provenance.

### BorderGlow: removed

BorderGlow's global controller, overlay, stylesheet and semantic wrapper were removed at the user's request. Commerce cards use IntentLink directly. Do not restore StarBorder on active routes. Homepage header, hero and final CTAs use PillNav independently; chat effects are unchanged. See [docs/border-glow.md](docs/border-glow.md).

### StarBorder contract (historical, not active)

A semantic polymorphic root (`as`, default `button`) with a decorative 2D canvas. Native props are forwarded; a default native button gets `type="button"`. It supports ref-forwarding Next `Link`. Do not put another button/link inside its linked card content.

| Prop                    | Default / units / supported values                                                                                               |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `duration`              | `4` **seconds**, minimum `0.3`; no `speed` prop                                                                                  |
| `thickness`, `radius`   | `1`, `12` CSS pixels; thickness minimum `0.5`; radius nonnegative                                                                |
| `trailLength`, `stars`  | `0.3` in `[0,1]`; `1`, rounded/clamped to 1–6                                                                                    |
| `glow`, `breath`        | `0.6`, `0.16`, each `[0,1]`; breath cycle is 4.8 seconds                                                                         |
| `direction`             | `'clockwise'` or `'counterclockwise'`                                                                                            |
| `hover`                 | Default `'reveal'`; also `'lap'`, `'brighten'`, `'none'`                                                                         |
| `sparkle`, `clickPulse` | `false`, `true`; commerce explicitly disables both                                                                               |
| `theme`                 | `'dark'` default or `'light'`; palette fallback only, not app theme detection                                                    |
| Colors                  | `color`, `trailColor`, `backgroundColor`, `textColor`, `borderColor`; pass app surface/text/track tokens explicitly where needed |

Historical use (no current runtime consumers): the five `CommerceCatalogue` links. Recipe: radius `23`, duration `3.8`, thickness `2`, trailLength `0.18`, breath `0.24`, glow `0.45`, brand-violet `#8b6fc1` head, pale-violet `#c4b2e2` trail, `hover="reveal"`, light palette, app panel/text/border tokens, no sparkle/pulse. See [DESIGN.md](DESIGN.md#4-motion-and-react-bits-recipes) for the copyable recipe.

Lifecycle guarantees to preserve: `hover="reveal"` plays exactly one lap per new hover/focus activation and stops RAF at its static endpoint; a real leave/re-enter or blur/refocus rearms it, while visibility/preference changes do not replay a completed lap; idle after hover/focus fades out; immediate RAF cancellation offscreen or in a hidden document; live reduced-motion handling; touch enter does not latch hover; observer fallbacks; cleanup of listeners/observers/RAF on unmount. Reduced motion produces static feedback. Canvas is `aria-hidden` and pointer-transparent; native focus/disabled semantics remain independent of the effect. Do not replace these with an always-running CSS/RAF loop.

### FadeContent and stable deferred enhancement

The default export renders a `div` with visible server-rendered children. It uses IntersectionObserver + Web Animations API, not GSAP. Named `FadeContentEffect` takes `targetRef: RefObject<HTMLDivElement | null>`, shares the same options, and renders `null`.

| Option                    | Default / contract                                                                 |
| ------------------------- | ---------------------------------------------------------------------------------- |
| `duration`, `delay`       | `600`, `0`, both **milliseconds**                                                  |
| `distance`, `blur`        | `12` pixels; `false` (when enabled, starts at 6 px blur)                           |
| `ease`                    | `'cubic-bezier(0.22, 1, 0.36, 1)'`; CSS easing, not a GSAP name                    |
| `threshold`, `rootMargin` | `0.12`, `'0px'`; native observer geometry                                          |
| `initialOpacity`          | `0`, clamped to `[0,1]`                                                            |
| `onComplete`              | Once for the mounted, stable-options reveal; callback identity does not restart it |

No disappearance props or custom container option are implemented. Keep visual options stable across unrelated renders. Keyboard focus or reduced motion cancels a pending reveal immediately; hidden tabs pause active Web Animations; missing APIs leave content readable. Cleanup disconnects/cancels everything.

Current uses: direct wrappers on auth/account content; landing's `Reveal` keeps a stable host and server children, waits until within `240px` of the viewport, then dynamically loads **only** `FadeContentEffect`. That controller uses `ssr: false` because it creates no markup. Do not generalize that exception into disabling SSR for visible content. Use the existing `Reveal` for normal landing sections rather than duplicating its loader.

### Focused checks after material/effect work

```sh
node --import tsx --test tests/glass.test.mjs tests/react-bits-lifecycle.test.mjs
npm run test:react
npm run typecheck
npm run build
npm run analyze
```

The deterministic effect harness verifies scheduling/cleanup, not canvas pixels. Also inspect hover, focus, clipping, coarse-pointer behavior, reduced motion, dark/scoped-light and forced-colors behavior in a real browser when browser testing is in scope.

### Workspace CSS orbs (2026-10-18)

`ComposerOrbs` is a memoized decorative sibling of the stable composer input. Three
independent radial gradients (violet, pale blue and pale pink) sit on responsive
tracks capped at 360×250, 250×200 and 270×210 px and 70%/65% of host width/height.
The inner visual uses a centered `scale(3)` after responsive sizing, making both
rendered dimensions 3× their previous size without changing track travel or input
geometry. Its fixed local 18 px blur scales with it; the rounded host clips overflow
and retains 28% opacity. Separate linear alternate x/y tracks rebound over
24/31/37 and 17/21/26 second one-way cycles. Oversized glow edges can be cropped;
rebounds follow the original track bounds, not enlarged-glow edge collisions.
Independent 6/7.5/9 second opacity
cycles shimmer gently between 55% and 100%, with staggered phases and no hard flashes.
Focus immediately pauses their CSS animations and fades the host out over 220 ms;
blur restores motion when visible. Hidden/offscreen and live reduced-motion/forced-colors
preferences pause motion; reduced-motion CSS keeps static spots while forced colors hides the decoration. Missing
observer/media APIs retain static spots. All observer and preference listeners clean up.
The original WebGL renderer and its exclusive license copies have been removed; other
React Bits sources and their notices remain. No canvas, animation runtime, RAF or timers
are used here. Tests cover lifecycle gates and CSS contracts, not measured GPU/frame cost.

### Initial CSS delivery experiment

`experimental.inlineCss: true` is enabled in the pinned Next version to remove the external stylesheet dependency exposed by the uploaded Edge baseline. Read `node_modules/next/dist/docs/01-app/03-api-reference/05-config/01-next-config-js/inlineCss.md` before changing it. It is production-only/global and duplicates CSS in the initial RSC payload; client navigation can still use external styles. Do not mistake zero initial CSS requests for zero CSS bytes: inline style bytes are included in the HTML budget. Keep the 0 stylesheet-link and 48 KiB gzip HTML gates, and remeasure actual FCP before claiming success. See `docs/first-paint-audit.md` for the baseline, limits and caching trade-off.

## 7. Verification and acceptance

### Pick the matching evidence

- `bootstrap.test.mjs`: framework versions, local routes/assets, fixture integrity, workspace upload boundaries, export configuration.
- `react-interactions.test.tsx`: real provider behavior, narrow subscriptions, URL ownership, stable Glass children.
- `workspace*.test.*`: independent drafts, references, first send, stable composer, session actions, popovers and carousel.
- `commerce*.test.*`: counts, A+ reorder/review, uploads, image fitting, drafts, isolated regeneration, dropdown/dialog behavior and stable example nodes.
- `assets-identity*.test.*`: stable asset nodes, filters, membership/undo, dialogs, form validation, truthful unavailable states and ledger pagination.
- `landing*.test.*`: motion geometry, gallery interruptions, nav/menu, FAQ and deferred reveal identity.
- `glass.test.mjs`, `react-bits-lifecycle.test.mjs`: lifecycle/material/effect contracts and notice retention.
- `performance-budget.test.mjs`: analyzer correctness and dependency/source constraints. This is distinct from measuring the current export with `npm run analyze`.

Run the full `npm run verify` against the final tree before reporting engineering completion. If another worker changes a dependency or shared file afterward, rerun the affected checks. Keep local unit/React coverage; do not recreate the old browser-automation suite or add Playwright/Puppeteer merely as a substitute for the permitted browser workflow.

### Acceptance checklist

- [ ] Changed only the requested project and owned files; no legacy HTML or production changes.
- [ ] Kept route/server-client structure, honest demo boundaries and current state semantics.
- [ ] Reused common components and narrow subscriptions; stable images/forms did not remount.
- [ ] Verified cleanup, failure paths, repeated clicks, cancel/Escape, return navigation, and relevant upload/storage errors.
- [ ] Preserved keyboard labels, focus cues/restoration, live status, IME behavior, reduced motion and fallbacks.
- [ ] Updated relevant tests and documentation, then ran lint, format, types, unit tests, React tests, build and export budget.
- [ ] Compared new output against `performance-budget.json` and [docs/performance-review.md](docs/performance-review.md); explained any intentional increase.
- [ ] If visual work was requested, recorded exactly which routes, viewport sizes, browsers and states were actually inspected, plus any remaining gaps.
- [ ] Ran `npm run audit:prod` (`npm audit --omit=dev --audit-level=high`) before an authorized publish; reviewed findings and accurately reported audit/network limitations.
- [ ] Confirmed exported local resources and public license notices exist; did not label an unrun check as passed.

Tests and static exports do not prove visual parity, Safari rendering, smooth animation, mobile keyboard behavior, contrast compliance, Core Web Vitals, or backend readiness. A source scan is not a screenshot. State “not browser-verified” when that is the evidence boundary; never manufacture screenshots, timings or pass counts.

## 8. Failure recovery, Git, and publication

- Inspect the workspace and existing changes before editing. If this copy has no Git repository, do not claim a branch, commit, diff or push exists. Initialize/publish only within the user's actual authorization.
- Coordinate shared files and formatting. Do not discard another worker's changes or run broad reset/clean commands. Revert only your identified change when safe; preserve an isolated patch/copy if recovery is needed.
- Diagnose failed commands from their real output. Repair the underlying issue instead of removing tests or raising limits. Missing packages use the pinned lockfile; a stale export needs a successful rebuild before analysis.
- Stop task-owned servers/processes when finished, and release runtime resources. Remove only confirmed task-owned temporary/generated artifacts when appropriate; never delete a user source directory to “clean up.”
- Keep `.next/`, `out/`, `node_modules/`, build metadata, logs, runtime dumps, browser artifacts, temporary screenshots and secrets out of commits. `.gitignore` is a baseline, not proof that every new artifact is safe. Never log passwords, tokens, full private prompts or uploaded image contents.
- Commit only the scoped source, tests, docs, config, lockfile, intended public assets and required notices. Review the final file list and diff for unrelated edits or generated output.
- The designated independent site, when configured, is recorded in `.openai/hosting.json`; that file is destination metadata, not proof of a completed deployment. Reuse only the task-authorized target rather than guessing a URL or touching an old site.
- The deployable artifact is **only `out/`**. Source, tests, local docs, dependencies and caches are not the site upload. Retain `out/licenses/` in an exported distribution.
- Building is not publishing. Publishing, pushing or replacing a site requires the existing task's authorization and the designated destination; never overwrite the old HTML preview or real ZImage site. Verify an authorized publish/remote commit before reporting it successful. Do not infer deployment permission from a request to edit documentation.

### User delivery preference

Deliver the verified online preview link. Do not send a source ZIP unless the user asks.

Homepage Start CTA uses the selected PillNav adaptation; see [docs/pill-nav-cta.md](docs/pill-nav-cta.md) for its scoped recipe and provenance.

Sidebar category filters use the selected bounds-tracking adaptation of React Bits
GooeyNav in `workspace/CategoryFilters.tsx`; see [provenance and lifecycle](docs/gooey-nav-filters.md).
Only the 200 ms selected background moves. Keep native pressed buttons and stable,
hidden session rows; do not add particles, label effects or list-wide reveals.
