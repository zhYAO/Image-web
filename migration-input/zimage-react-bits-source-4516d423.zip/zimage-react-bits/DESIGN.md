# ZImage preview design and interaction guide

This guide describes the **implemented** React preview and the constraints that keep it coherent. Use it when adjusting a page, extending an existing component, or reviewing a regression. [AGENTS.md](AGENTS.md) covers architecture, commands, state ownership and delivery boundaries.

The visual/source reference used Next.js 16.3.0; this independent React preview uses the security-patched Next.js 16.3.8 with matching eslint-config-next. The patch preserves the existing design contract and does not authorize redesigning routes or changing the original preview. See [AGENTS.md](AGENTS.md#reference-versions-versus-security-patches) for version provenance and the pre-publication dependency-security check.

The product direction is a quiet Chinese-language creative workspace: pale editorial surfaces, restrained violet accents, soft glass, useful local image examples, and motion that explains a transition. Preserve the homepage's generous brand composition and the workspace's compact working density. A visual cleanup is not permission to add product features or replace the established layouts with a generic dashboard.

## Contents

1. [Page map and composition](#1-page-map-and-composition)
2. [Tokens, typography, and themes](#2-tokens-typography-and-themes)
3. [Shared liquid glass](#3-shared-liquid-glass)
4. [Motion and React Bits recipes](#4-motion-and-react-bits-recipes)
5. [Interaction states and accessibility](#5-interaction-states-and-accessibility)
6. [Responsive geometry and scrolling](#6-responsive-geometry-and-scrolling)
7. [Images, framing, and stable DOM](#7-images-framing-and-stable-dom)
8. [Extension examples and review](#8-extension-examples-and-review)

## 1. Page map and composition

| Route                                  | Composition and intent                                                                                                                                 |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `/`                                    | Independent brand homepage: floating navigation → headline/CTA/gallery → statement → three-step workflow reel → five scenes → FAQ → final CTA → footer |
| `/workspace/`                          | The **one** chat/image workspace: shared sidebar/topbar, welcome carousel or session timeline, one stable composer                                     |
| `/create/`                             | Five-card commerce catalogue retained by the persistent create layout; its Page renders a nonzero route-scroll anchor before the cache                 |
| `/create/product-set/`                 | 商品套图: product uploads, output settings, grouped image counts and optional listing copy                                                             |
| `/create/detail/`                      | A+ 详情页: configure modules → review/edit/reorder strategy and copy → local example results                                                           |
| `/create/clone/`                       | 爆款图复刻: reference images and per-image instructions; external link import explicitly unavailable                                                   |
| `/create/product-main/`                | AI 商品图: product image, scene template/custom/reference choice and candidate count                                                                   |
| `/create/apparel-catalog/`             | 服装商品图片: five main photos, display photos, logo and product fields; fixed-layout example set                                                      |
| `/assets/`                             | Curated library inside the shared sidebar/topbar shell; collection cards, Bits filters, stable thumbnails, image-only viewer and collection dialogs    |
| `/login/`, `/auth/`                    | Fullscreen +86 phone/code login demonstration, with clear unconnected status                                                                           |
| `/register/`, `/auth/register/`        | Same auth shell, registration visibly closed                                                                                                           |
| `/forgot-password/`, `/auth/recovery/` | Legacy recovery information with a link to phone login; no credential fields                                                                           |
| `/auth/verify/`, `/auth/reset/`        | Legacy unavailable information; no old email/password/code collection                                                                                  |
| `/account/`                            | Account content in the workspace shell; unavailable balance, ledger, local profile and security controls                                               |
| `/terms/`, `/privacy/`                 | Readable, explicitly unapproved draft pages; no implication of accepted legal terms                                                                    |

Keep `/` a brand page rather than replacing it with the composer. Do not create parallel chat/image workspaces. Navigation uses Next `Link`; section navigation uses `SectionJump` so scroll/reduced-motion behavior and focus remain consistent.

All generated-looking visuals are local examples. Account/service unavailability and draft legal status are part of the UI's meaning, not temporary copy to remove for a cleaner screenshot.

## 2. Tokens, typography, and themes

### Application palette

`src/app/globals.css` owns the application tokens. Reuse them instead of approximating similar hex values in each component.

| Token              | Light                   | Dark OS preference      |
| ------------------ | ----------------------- | ----------------------- |
| `--bg`             | `#f5f4f8`               | `#17141e`               |
| `--panel`          | `#fff`                  | `#25212d`               |
| `--text`           | `#292630`               | `#f2edf7`               |
| `--muted`          | `#736d7d`               | `#bdb2cb`               |
| `--subtle`         | `#8c8594`               | `#a79aae`               |
| `--primary`        | `#7050b5`               | `#b99ae9`               |
| `--primary-hover`  | `#6243a3`               | `#cab1ed`               |
| `--soft`           | `#eee8f6`               | `#392d49`               |
| `--border`         | `#e1dce8`               | `#453a51`               |
| `--control-border` | `#aaa0b7`               | `#8d7e9e`               |
| `--overlay-glass`  | `rgba(255,255,255,.95)` | `rgba(41,35,51,.97)`    |
| `--rim`            | `rgba(255,255,255,.95)` | `rgba(239,222,255,.15)` |

- Font stack: `-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif`. No network font dependency is needed.
- Global body size: `14px`; each feature sets its own readable working hierarchy. Do not shrink functional copy to match an old decorative caption.
- Shared easing `--ease`: `cubic-bezier(.22,1,.36,1)`.
- Light `--shadow`: `0 10px 40px rgba(40,27,62,.045), 0 2px 8px rgba(40,27,62,.025)`.
- Dark `--shadow`: `0 10px 40px #05020924, 0 2px 8px #05020914`.
- `--nav-glass`, `--sidebar-glass`, `--bubble-glass`, `--bubble-sheen`, `--bubble-border`, `--bubble-shadow`, and `--liquid-shadow` alias the shared material rather than defining new recipes.

### Homepage is intentionally light

`.zl-root` in `landing.css` defines `--zl-paper: #f8f8fb`, `--zl-ink: #24232c`, `--zl-muted: #74717f`, `--zl-violet: #7752b8`, `--zl-line: #e5e3eb`, and overrides `--primary` to `#7752b8`. It sets `color-scheme: light`; the root markup also has `data-glass-theme="light"`. Keep those two scopes together so a dark OS does not produce dark text/glass combinations on the light page.

The main headline uses `clamp(44px,5.5vw,78px)`, weight `620`, line height `1.22` and `-.065em` tracking on desktop; the accent is a violet-to-blue text gradient. Section headings use `clamp(30px,3.3vw,47px)`, weight `600`, line height `1.35`. Preserve the line breaks and balanced hierarchy, with responsive rules below.

Assets use application colors through their `--za-*` aliases, with `--za-purple: #7552ba`. Identity and workspace inherit application light/dark tokens. There is no user-facing theme toggle; the glass stylesheet's root `data-theme` selectors do not by themselves implement a complete application theme switch.

## 3. Shared liquid glass

### One owner for material, local owners for geometry

Use `src/components/Glass.tsx` (the compatibility export of `react-bits/GlassSurface.tsx`) and `src/styles/liquid-glass.css`. The shared paint and SVG map/channel pipeline are an adaptation of the official free React Bits GlassSurface, pinned in the selection notes. A panel's CSS may choose size, padding, border radius and position. It should not recreate the material with unrelated gradients, duplicate blur layers or a new “glass” component.

The global layout imports the material stylesheet. Review the final CSS cascade when changing feature styles; feature files contain some older rules and later corrections. The last applicable rule, not the first matching declaration, is the implemented geometry. New changes should consolidate the relevant rule where safe rather than accumulating another unexplained override.

### Exact shared recipe

| Material property                | Light                                       | Dark                    |
| -------------------------------- | ------------------------------------------- | ----------------------- |
| Surface                          | `rgba(255,255,255,.28)`                     | `rgba(37,32,48,.40)`    |
| Border                           | `rgba(21,20,15,.08)`                        | `rgba(232,214,255,.20)` |
| Fallback                         | `#fff`                                      | `#25212d`               |
| Standard backdrop                | `blur(12px) saturate(1.4) brightness(1.04)` | Same                    |
| Optional refracted backdrop blur | `7px` after the SVG filter                  | Same                    |

The **28/40** shorthand means light/dark surface opacity, not blur radius or animation duration.

The frosted recipe uses React Bits' inset top/bottom highlights (85%/35% white in light mode, 30%/8% in dark), a soft inset edge/glow, and three outer shadows at 4/8/16 px offsets. All three outer layers use `rgb(70 70 86 / 3%)` in light/scoped-light mode and `rgb(24 22 30 / 6%)` in automatic/explicit dark mode: 50% lower alpha and a lighter tint than the previous 6% near-black / 12% black shadows. Their offsets and blur radii remain `0 4px 16px`, `0 8px 24px`, and `0 16px 56px`. SVG-enhanced and CSS fallback surfaces inherit the same shared shadow; accessibility modes still remove it. The application retains its restrained sheen and tinted 28%/40% surfaces for readable surrounding UI. See `liquid-glass.css` for the exact shared tokens; feature styles must not duplicate these shadows.

`[data-glass-theme="light"]` or `.liquid-glass-theme-light` restores the light material, `--glass-text: #292630`, and `--glass-focus-border: #7050b5` in a scoped light area. The normal material text/focus colors follow `--text` / `--primary`.

### Optional refraction

`<Glass refract>` lazy-loads `src/components/react-bits/GlassSurfaceEffect.js`. The engine derives the element's actual local border-box dimensions and all four corner radii; it adds static RGB backdrop displacement through an owned SVG filter. The transparent red/blue displacement gradients, explicit soft-center SVG blur, RGB channel separation and screen blending come from React Bits. Displacement is reduced to -50/-47/-44 px for small application controls. Safari and Firefox retain CSS frosting, matching upstream’s conservative browser gate. WebGL/backdrop capture and arbitrary image-shaped surfaces are intentionally not included. It has no continuous animation loop. Resize work is settled/debounced; resource cleanup restores preexisting inline state.

Use it only where the existing design benefits, currently navigation/topbar surfaces. Commerce panels deliberately use CSS glass without refraction. Text/icons never pass through the filter: only the backdrop does. A failed import or unsupported browser must leave the normal CSS material usable.

### White and opaque exceptions are intentional

- `.surface-white` explicitly uses white background, no sheen and no backdrop filter. `data-liquid-glass="off"` on a directly marked DOM surface opts out of the shared recipe/engine; that component then owns its paint. The `Glass` wrapper itself owns that data attribute from `refract`, so use `.surface-white` rather than trying to override its attribute prop.
- Commerce `Select` triggers and portal listboxes are explicitly white `#fff` with text `#302735`, even in dark mode. Preserve their clean menu geometry and independent scrolling instead of applying glass to them.
- Asset native select options use the same white/dark-text treatment.
- The homepage mobile menu uses the shared `surface-white` exception when open. Its solid panel prevents hero text bleeding through the menu; the main navigation retains its existing glass.
- Image canvases, ordinary solid panels and primary buttons are not all supposed to become glass. Do not apply backdrop blur to the image pixels themselves.

No-backdrop-filter support uses an opaque fallback. Reduced transparency or increased contrast removes sheen/shadow/filter and strengthens the border. Forced-colors uses `Canvas`, `CanvasText`, and system borders. Reduced motion disables refraction and interactive material transitions. Maintain these branches when changing the default material.

## 4. Motion and React Bits recipes

### Reference relationship

The motion geometry was adapted from the supplied `open-design-home-clone` snapshot `05c9c01`, whose local reference includes `glass/source.css` and `glass/source.html`. The reference has blur-text keyframes, 35 ms word offsets, a 68 vh-per-step sticky track, 96 px rail, 10-second gallery interval and the statement's 82%–22% viewport band. This preview applies those ideas to the ZImage composition; it does not inject or execute the reference page.

Current source of truth: `landing/motion.ts`, `LandingNav.tsx`, `HeroGallery.tsx`, `Statement.tsx`, `WorkflowReel.tsx`, `Reveal.tsx` and `landing.css`. Do not replace their coordinated timing with arbitrary library presets.

### Implemented motion values

| Interaction              | Current contract                                                                                                                                                |
| ------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Nav condensation         | Enter condensed when scroll Y is **greater than 64 px**; remain condensed at **24 px or above**; 420 ms geometry transitions with `cubic-bezier(.22,.61,.36,1)` |
| Hero copy                | 900 ms / 28 px entry using `--ease`; description delay 160 ms, CTA delay 240 ms                                                                                 |
| Hero title               | 380 ms `cubic-bezier(.23,1,.32,1)`; first line 80 ms, second 115 ms; fully visible transform-only entry, Y -50 → 5 → 0 px                                       |
| Gallery                  | 10,000 ms automatic interval; 560 ms opacity/visibility crossfade                                                                                               |
| Statement                | Word opacity progresses from `.18` to `1` across viewport top positions `82%` to `22%`; the helper clamps both ends                                             |
| Desktop workflow         | Three-step `204vh` track, 96 px sticky top; continuous frame offsets rather than abrupt index swaps                                                             |
| Compact workflow         | Manual/click-driven frame selection; 550 ms slide; used at width ≤ 880 px, height ≤ 680 px, or reduced motion                                                   |
| Landing `Reveal`         | Near-viewport controller loaded at `240px`; 900 ms, 28 px, threshold `.12`, root margin `0px 0px -8% 0px`; scene stagger 0/80/160/160/160 ms                    |
| Workspace shell          | Single layout commit for sidebar/dock geometry; opacity/transform label feedback; welcome exit 190 ms; timeline entry 380 ms                                    |
| Workspace carousel       | 520 ms slide; no slide transition while dragging                                                                                                                |
| Buttons / popovers       | Generally 150–220 ms feedback; preserve the owning component's exact values                                                                                     |
| Auth panels              | Direct FadeContent: story 700 ms / 14 px; form 600 ms / 12 px                                                                                                   |
| Commerce mock generation | Progress updates at 450 and 900 ms, example results at 1,350 ms; card regeneration 850 ms. These are simulated state timing, not network performance            |

Gallery autoplay pauses for hover, keyboard focus, explicit pause, manual selection, document hiding, offscreen state and reduced motion. Keep controls useful while animation is paused. Reduced motion must also avoid smooth scrolling and nonessential translation/scale. “Paused offscreen” should mean no pending continuous RAF work, not merely invisible pixels.

### BorderGlow: removed

The global BorderGlow hover/focus overlay has been removed. Commerce cards retain their ordinary IntentLink styling; do not restore StarBorder. All three homepage Start CTAs, including the compact header link, use the independent PillNav fill and rolling labels. Chat component effects are unchanged. See [removal record](docs/border-glow.md).

### StarBorder: historical commerce recipe (superseded)

```tsx
import Link from 'next/link';
import StarBorder from '@/components/react-bits/StarBorder';

<StarBorder
  as={Link}
  href={`/create/${scene.id}`}
  className="cm-tool-card"
  theme="light"
  radius={23}
  thickness={2}
  duration={3.8}
  trailLength={0.18}
  color="#8b6fc1"
  trailColor="#c4b2e2"
  glow={0.45}
  breath={0.24}
  hover="reveal"
  sparkle={false}
  clickPulse={false}
  backgroundColor="var(--panel)"
  borderColor="var(--border)"
  textColor="var(--text)"
>
  {/* Existing cover and non-interactive card copy. */}
</StarBorder>;
```

In `hover="reveal"` mode, each new hover or keyboard-focus activation plays one full lap, then holds a static highlight with no animation frame loop. Leaving and re-entering replays the lap; hidden/offscreen time does not advance it. Breathing runs only during that lap. The violet edge is decorative emphasis on hover or keyboard focus. It is not a progress/status indicator and never substitutes for a visible focus cue or link semantics. `duration` is **seconds**; radius/thickness are CSS pixels. `breath` is amplitude `[0,1]`, with a 4.8-second luminance cycle. The catalogue explicitly uses `.24` breath amplitude and `.18` trail length. A pale-violet under-stroke separates the visible violet core from image content; the static track is behind the canvas. Padding-box measurement (`clientWidth`/`clientHeight`) keeps the perimeter inside the rounded card.

This is a 2D canvas, not a CSS gradient border. Its bitmap includes 48 px bleed on each side and caps device pixel ratio at 2. The local component clamps stars to 1–6, glow/breath/trailLength to 0–1, and duration to at least .3 seconds. Those are safety bounds, not an invitation to use the maximum. Keep the existing single star, modest glow, no sparkle and no pulse on catalogue cards.

The default component has button padding/inline-flex; `.cm-tool-card` resets it to a block card with zero padding and gap. Match `radius` to the actual 23 px outer corner. Its canvas/track z-index overrides and `overflow:hidden` keep the effect aligned to the card; verify edge clipping visually after changing radius or layout.

The current first-screen card implementation is directly imported. Do not lazy-load and swap the card's DOM just to delay the decoration. New below-fold optional effects can defer only their enhancement, keeping the semantic surface/content mounted.

### FadeContent: reveal without content churn

Ordinary landing changes should use the existing `Reveal` component. It already separates a stable server-rendered host from deferred motion. For a small client feature needing an immediate wrapper:

```tsx
import FadeContent from '@/components/react-bits/FadeContent';

<FadeContent duration={600} delay={0} distance={12} blur={false}>
  <section aria-labelledby="section-title">{/* Real content. */}</section>
</FadeContent>;
```

`duration` and `delay` are **milliseconds**. The implementation uses CSS easing, Web Animations and IntersectionObserver; it does not load GSAP. The named `FadeContentEffect` accepts a stable `targetRef` and renders no DOM. Preserve that contract when deferring the effect: do not replace a host wrapper after load, change keys, remount child forms, or hide server HTML until JavaScript arrives.

Keyboard focus and live reduced-motion changes immediately reveal content; hidden documents pause active animation. Keep these behavior guarantees and cleanup intact. For API defaults, lifecycle modification boundaries and focused tests, use [AGENTS.md](AGENTS.md#6-shared-material-and-react-bits-quick-reference). Full provenance/license/adaptation details are in [docs/react-bits-selection.md](docs/react-bits-selection.md).

## 5. Interaction states and accessibility

### Controls and fields

- Resting controls use the existing panel/soft/border hierarchy. Hover is a modest fill, color, border or 1–3 px lift; pressed state must not depend on hover or animation.
- Active navigation/toggle state is represented by semantic attributes (`aria-current`, `aria-pressed`, `aria-selected`) plus visible fill/text/border cues. Keep these attributes and visual styles synchronized.
- Disabled controls remain understandable: reduced emphasis, correct cursor and no action. Loading controls use actual `disabled`/`aria-busy` or status semantics, not an animated overlay alone.
- Inputs/textareas/selects deliberately avoid an extra outline, ring or changed border geometry. Global focus uses a 13% primary/panel mix and primary caret; commerce and identity fields use their local 8% mix; asset search/select groups use soft fill and icon color. Preserve each scoped treatment.
- The workspace composer is a scoped exception: its textarea remains transparent on focus and uses the primary caret. Do not claim the global fill appears there; check the actual cascade and preserve a perceivable keyboard cue without introducing an input ring.
- Non-input focus remains visible. Landing/asset controls use outlines; workspace controls have scoped fill/text feedback; the StarBorder component also defines an independent native focus treatment. Do not apply a blanket `outline:none` to the whole application.
- Forced-colors fields use `Highlight` / `HighlightText`, with native/system borders and readable caret. Focus cannot disappear because the normal light-theme fill is unavailable.

### Feedback and overlays

Use short, accurate Chinese copy. Preserve text labels on icon-only buttons through `aria-label`, explicit field labels, status live regions and `role="alert"` validation feedback. A spinner or decorative star is not an accessible announcement.

All value dropdowns use the shared React Bits GlideSelect, including model choices. Model
triggers and menus are opaque white (`#fff`) with dark text (`#292633`), never glass or blur.
Each 40 px model row shows a lightweight local provider glyph followed by its readable name
and the standard selection check. Keep icons decorative and use the model name for accessible
labels/typeahead. The composer wraps its tool row on narrow screens; the model trigger truncates
long names within 240 px, while the menu is viewport-clamped. A small local-only notice remains
visible. Chat mode offers 6 chat choices; create-image mode and all commerce scenes offer 4 image
choices from the same 10-entry registry. Seedream 5.0 Pro remains the default image choice.
See [model selectors](docs/model-selectors.md) for references and state ownership.

Native dialogs retain Escape/cancel, close buttons, click-outside behavior and focus return to their trigger. Commerce dropdowns are white listboxes with keyboard navigation and their own scroll area. Active-option reveal scrolls only that listbox; dialog entrance/exit fades do not transform the fixed-position portal coordinate system. Scrolling inside one must not dismiss it; Escape should dismiss the inner dropdown before the surrounding dialog. Anchored popovers need viewport clamping and correct placement after scroll/resize.

First send changes the welcome area to the timeline while retaining the composer node. Chat/image switching retains two independent drafts and references. Asset selection/favorite changes retain decoded images and support membership undo without discarding unrelated later edits. These state semantics are part of the design, not implementation details to remove during styling.

## 6. Responsive geometry and scrolling

The CSS uses feature-specific breakpoints, not a single universal grid. Preserve their purpose. Always inspect narrow **and** short viewports; width alone misses composer/editor/auth overflow.

### Brand homepage

- Desktop container: max `1320px`, inline padding `64px`; `40px` at ≤1100, `28px` at ≤880, `22px` at ≤620, `18px` at ≤360.
- Navigation: expanded max `1320px`, width `calc(100% - 96px)`, min-height `68px`; condensed max `1080px`, width `calc(100% - 32px)`, min-height `60px`. The ≤620 rule uses width minus 24 px and min-height 56 px.
- At ≤880, navigation becomes a menu; workflow stops being scroll-pinned. At ≤620, workflow copy/preview stack vertically, scene cards form a two-column composition with the first card spanning both columns, and FAQ/footer stack.
- Desktop hero gallery is a `650 × 410px` window. The mobile window is width minus `48px`, with a `205px` image stage. Floating decorative side cards may crop at the viewport; primary controls/content may not.
- Width >880 with height ≤680 uses the manual workflow fallback too. Coarse-pointer rules enlarge navigation/tabs and keep scene-open affordances visible.

### Shared workspace

| Width           | Shell padding / gap | Expanded sidebar   | Topbar |
| --------------- | ------------------- | ------------------ | ------ |
| Default desktop | `24px` / `24px`     | `244px`            | `58px` |
| ≥1600           | `28px` / `30px`     | `256px`            | `58px` |
| 768–1199        | `18px` / `20px`     | `224px`            | `55px` |
| ≤767            | `12px` / `0`        | Off-canvas `268px` | `51px` |

Match the original HTML scroll model: the workbench has natural document height (`min-height:100svh`), a sticky translucent topbar at `var(--shell-pad)`, a sticky sidebar and a fixed composer. Content on the workspace, catalogue, assets and account routes intentionally scrolls **behind** the glass topbar; do not clip it into a separate region below navigation. Commerce editors retain viewport-bounded panels with independent internal scrolling, except the mobile apparel form described below. Initial content remains below the header in normal flow. Chat auto-scroll uses the document flow and follows only near the bottom; reading above must not be interrupted by growing output. Collapsing commits grid/control/composer geometry once, avoiding per-frame layout of the whole page; only labels and feedback animate. The sidebar includes a static 28-message “长对话滚动示例” for scrolling checks.

Collapsed desktop sidebar is `76px`. Below 768 px, it becomes a modal-like drawer with shade and explicit close control; do not squeeze the desktop rail into the content. The carousel shows three cards on desktop and one full-width card on mobile.

The approved chat demonstration uses a small “模拟 AI · 本地演示，未连接模型” provenance label on every simulated assistant reply. ThoughtLine exposes expandable, preset demonstration steps; LatticeLoader plus ShinyText show the thinking phase; TextType reveals the multi-paragraph sample answer once. Completed/stopped text remains static when revisiting a session. User messages enter with the existing short FadeContent effect. Keep the purple/light-glass palette and shared panel tokens, quiet 11–13 px metadata and readable answer line height. Stop replaces Send while a run is active, preserving the textarea and drafts. A separate polite phase status avoids announcing each typed character. Image mode remains explicitly unavailable and does not simulate successful generation.

The workspace composer uses three separate CSS gradient light spots: dominant
violet, pale blue and pale pink, with restrained 28% host opacity. Their responsive
motion tracks retain maximum dimensions of 360×250, 250×200 and 270×210 px,
limited proportionally to 70% of composer width and 65% of composer height.
Each inner visual is then scaled to **3× its previous rendered width and height**
around its center, including its fixed local 18 px blur. This post-sizing scale
avoids the responsive caps cancelling the enlargement on short/mobile composers.
The enlarged glow overlaps and is clipped by the rounded decorative host; it does
not resize the composer or cover its input/control hit targets. Separate horizontal
and vertical transform tracks still travel from zero to container size minus track
size, then reverse linearly. These are track-bound rebounds, not collisions of the
oversized glow edges with the composer (and no orb-to-orb collisions). Independent
one-way durations of 24/31/37 seconds horizontally and 17/21/26 seconds vertically
retain their staggered phases. Container query units follow composer resizing
without a measurement loop. Independent
6/7.5/9 second opacity cycles shimmer smoothly between 55% and 100% with staggered
phases, without hard flashes or animated blur/layout. Focus pauses motion immediately and fades the host out
in 220 ms; blur resumes eligible motion. Preserve input/attachment DOM, IME guards and
control hit targets. Hidden pages/offscreen state pause the effect; forced colors hide it; reduced motion retains static spots. Missing observer/media APIs leave static spots. No WebGL, canvas,
animation dependency or continuous JavaScript frame loop is involved.

Composer: desktop max `984px`, 28 px radius, fixed 24 px from the bottom; ≥1600 max `1044px` and 30 px bottom. Mobile radius is 23 px, bottom `max(12px, env(safe-area-inset-bottom))`. A ResizeObserver writes `--composer-obstruction` as dock height + 80 px; timeline/content padding uses that measurement. Do not hardcode a fixed spacer that fails when reference images or text increase its height.

Height-specific desktop rules at ≤760 px and 761–940 px compact the welcome/card area. Keep those when simplifying CSS.

### Commerce

Catalogue grid shares asset-library sizing: max 1200 px container, four columns by default, three at ≤850 and two at ≤640, with square covers and compact captions. At ≤640 px, descriptions use two readable lines instead of a single ellipsis. Cards retain 23 px outer radius, 22 px cover top corners. The catalogue and its persistent cache have natural document height so cards pass behind sticky glass navigation; only the editor outlet is bounded by `calc(100svh - var(--shell-pad)*2 - var(--topbar-height))`.

Editor columns: `minmax(300px,365px) minmax(0,1fr)`, gap 18 px. At ≥1600 the form is `minmax(340px,400px)` with 24 px gap. At 768–1100 it is `minmax(270px,320px)` with 12 px gap. At ≤767 the editor becomes one column with bounded rows `minmax(0,1.35fr) minmax(0,1fr)` and 10 px gap.

The configuration body scrolls independently, while its action bar remains visible. Preview/result content owns its own overflow. Preserve `min-width:0`, `min-height:0` and parent bounds; replacing them with only `max-height` can grow the document and hide the primary action. Mobile text inputs use 16 px to avoid unwanted input zoom.

The long apparel form is the deliberate exception at ≤767 px: outlet/panels grow with their content, the form has no nested scrollbar, actions follow the last field, and examples follow below. Desktop apparel and other scene editors keep bounded panels.

A+ output format uses its full descriptive selector width. Ordinary A+ shows 970 × 600 px per module; advanced A+ shows configured desktop 16:9 / mobile 4:3 ratios with pixel dimensions unconfirmed until a service is connected. Fixed example thumbnails do not promise actual output dimensions.

### Assets and identity

Assets reuse WorkspaceShell and its canonical sidebar brand, with no duplicate header or logo. Main width is `min(1200px, calc(100% - 48px))`; grid is four columns, three at ≤850 and two at ≤640. Narrow layouts stack filter controls. All full-image entry points reuse `ImagePreviewDialog`, extracted from the product-set viewer: commerce examples/uploads/results, workspace references/chat images, and assets. Assets enable `imageOnly`, showing only the full image and close/navigation controls without metadata; collection dialogs remain separate. The viewer owns native modal opening/cleanup, Escape/backdrop close, arrow-key paging and trigger focus restoration. Filtering/sorting use the shared React Bits GlideSelect.

Auth routes share `src/app/(identity-auth)/layout.tsx`. `AuthRoute` derives the mode from the pathname while preserving the fullscreen shell, Glass card and reveal hosts. Only the keyed phone-login form resets on mode changes. Login shows +86 phone/code fields, request/countdown states and truthful demo success (not authenticated). Legacy auth URLs show information without credential inputs. The card stays 680 px tall or viewport-bounded, with stable scrollbar space and internal scrolling. Form entry uses a readable 160 ms transition, disabled for reduced motion. Do not move the shell back into individual auth pages; that restarts full-screen reveals during tab navigation.

Auth owns the entire viewport; only `.zi-auth-scroll` scrolls. `visualViewport` height/offset updates `--zi-viewport-height` and `--zi-viewport-top` so the keyboard does not push the whole document around. Safe-area insets are respected. Desktop columns are `1.05fr / 1fr`; the visual pane hides at ≤1000. Form reveal width is at most 460 px. At ≤767, inputs are 16 px and padding reduces; height ≤620 uses a tighter form rhythm.

Auth credentials and submits remain disabled in server HTML/no-JavaScript mode until `src/lib/useHydrated.ts` confirms client hydration. The keyed phone-login form resets phone, code and request state on a real mode change; ordinary validation within a mode retains the same fields. Keep that safety boundary and do not interpret the disabled initial state as a styling bug.

Do not replace auth's fixed shell with a tall body-scrolling card. Preserve the CSS `:has(.zi-auth-screen)` route-scoped body lock and its automatic release after leaving the route. Account uses a separate reading layout: max 1120 px, two columns until ≤1000, then responsive settings and a single column on mobile.

## 7. Images, framing, and stable DOM

### Local image ownership

Use existing files under `public/assets/`. Commerce resolves `meitu-v1` / `apparel-v2` paths through `imageSource()` in `commerce-data.ts`; `SceneImage` implements one bounded fallback rather than an infinite error loop. Asset metadata, intrinsic dimensions and IDs live in `assets/library.ts`.

Keep image purpose explicit:

- **Cover thumbnails** may use `object-fit: cover`: landing scenes/gallery, workspace scene cards, commerce catalogue covers and square asset-library cards. Existing commerce/workspace covers favor `object-position: center 35%`.
- **Full-image inspection and product examples** use `contain` or natural-ratio fitting: full-image dialogs, reference viewer, commerce fit slots and asset detail view. Never crop required product text, complete apparel layouts or a reference simply to fill space.
- **Decorative montage** may rotate/crop surrounding cards; this does not authorize rotating the actual upload/result data or hiding meaningful content.

### Commerce rotation-aware fit

`CommerceExamples` measures available slots and natural image sizes; `fitExampleContent()` includes borders, padding and captions in the rotated bounding box. Product-set/main hero uses `-2deg`; long A+ stack uses `-1.5deg`. Scale is capped at 1, preserving aspect ratio and fitting both available axes. Images appear only after the slot receives `is-sized` with valid dimensions.

If changing rotation, caption height, padding or panel bounds, change the measurement inputs together and rerun fitting tests. A rotated frame can clip even when its unrotated width fits. Do not replace this helper with `width:100%; height:100%; object-fit:cover`.

### Avoid reloads and flicker

- Asset cards map the full stable ID list; filters toggle `hidden`, and sorting reorders existing keyed nodes. Favorites, selection and collection edits do not recreate `<img>` elements.
- `AssetImage` distinguishes loading/loaded/error; its cached-image check reads `complete` and `naturalWidth`. Keep the fallback meaningful and remove repeated entry shimmer once decoded/error state is known.
- The commerce catalogue stays mounted under `CommerceLayout` while an editor is active, with `hidden` plus `inert`. Its decorations pause while invisible.
- Memoized examples/image components and stable callback/options boundaries keep text entry from reinitializing measurements or replacing images. Confirm with React tests, not just a source comment.
- Lazy-load below-fold/optional images; keep explicit dimensions where known. Only genuinely important first-view images should be eager/high priority. The landing gallery loads active imagery intentionally; do not preload every slide by default.

## 8. Extension examples and review

### A shared glass surface

For an already requested panel, reuse the material and define only its local geometry:

```tsx
import { Glass } from '@/components/Glass';

<Glass as="section" className="cm-supplement" aria-labelledby="supplement-title">
  <h2 id="supplement-title">补充说明</h2>
</Glass>;
```

```css
.cm-supplement {
  min-width: 0;
  padding: 22px;
  border-radius: 23px;
}
```

This is an integration pattern, not a request to add this example feature. Keep the correct feature namespace and avoid a new background/blur recipe.

### An existing landing section reveal

```tsx
import { Reveal } from '@/components/landing/Reveal';

<Reveal delay={80}>
  <section aria-labelledby="existing-section-title">
    {/* Existing server-rendered content stays mounted. */}
  </section>
</Reveal>;
```

Use one stable section boundary; do not wrap individual filtered asset tiles with reveal effects that replay on every interaction.

### Review checklist

- [ ] Route purpose, copy hierarchy and local-demo meaning remain intact.
- [ ] Theme tokens and scoped-light glass agree; intentional white menus remain white.
- [ ] Shared material still has no-filter, reduced-transparency, increased-contrast and forced-colors fallbacks.
- [ ] Keyboard, pointer and touch can reach the same actions; focus and state cues do not rely on animation.
- [ ] Narrow and short viewports preserve visible actions, independent scroll regions and unclipped full images.
- [ ] Typing/filtering/favoriting does not remount decoded images, forms or motion hosts.
- [ ] Reduced motion, hidden tabs and offscreen components stop nonessential motion and release resources.
- [ ] Relevant unit/React tests, static export and size budget were rerun after the final change; an authorized publish also has a current `npm run audit:prod` result (the registry-dependent `npm audit --omit=dev --audit-level=high` gate).
- [ ] Browser evidence is described accurately; uninspected Safari, touch, keyboard/OS preference or contrast behavior is still unverified.

### Performance and evidence limits

`performance-budget.json` is the machine-readable limit; [docs/performance-review.md](docs/performance-review.md) explains the reviewed export and deferred boundaries. `scripts/analyze-bundle.mjs` measures emitted HTML/script/style/image files, per-file gzip sizes, missing resources and duplicate image hashes. It separates modern initial JS from `noModule` legacy polyfills and records emitted async chunk edges.

“Not present in initial HTML” does **not** automatically mean a chunk is truly deferred until interaction. Route prefetching and runtime loads need source/browser inspection. File-size checks do not measure frame rate, layout stability, hydration latency, Safari performance or Core Web Vitals. Do not write “smooth,” “pixel-perfect,” “WCAG compliant,” or performance scores as verified conclusions without the corresponding evidence.

Preserve the small runtime dependency set, component-level splitting and on-demand decoration. Avoid whole-library animation imports, GSAP/3D or WebGL effects, a second glass engine, global pointer effects, always-running background motion, duplicated assets or speculative abstractions. A change to performance limits needs a measured reason, not a larger number to make a failing check green.

Homepage Start CTA uses the selected PillNav adaptation; see [docs/pill-nav-cta.md](docs/pill-nav-cta.md) for its scoped recipe and provenance.

Sidebar categories use a 200 ms sliding violet `--soft` background beneath stationary
labels, adapted from React Bits GooeyNav selected-item bounds tracking. Keep the
compact 8 px indicator radius, native pressed state, SSR background fallback,
instant reduced-motion feedback and stable filtered rows. See
[scope and provenance](docs/gooey-nav-filters.md); no particles or gooey morphs.
